"""Prepare-only by default; root-reviewed --execute-assembly builds/runs one CPU exporter.

No mode invokes a GPU runtime, native solver, QOCO, factorization, or optimizer.
The shared GPU lock avoids compiler contention with another actor's timed work.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

import process_guard as PG
from validate_saved import validate

HERE = Path(__file__).resolve().parent


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def preflight():
    ready = json.loads((HERE / "ready.json").read_text())
    for name, expected in ready["files"].items():
        path = (HERE / name).resolve()
        require(path.is_relative_to(HERE) and path.is_file(), "unsafe or missing source")
        require(path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"], "source mismatch: " + name)
    pins = json.loads((HERE / "runtime-pins.json").read_text())
    checked = {}
    for name, expected in pins["artifacts"].items():
        path = Path(expected["path"])
        require(path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"], "runtime mismatch: " + name)
        checked[name] = expected
    return ready, checked


def main():
    if not __debug__:
        raise RuntimeError("optimized Python is forbidden")
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--prepare-only", action="store_true")
    mode.add_argument("--execute-assembly", action="store_true")
    args = parser.parse_args()
    ready, runtime = preflight()
    report = {"complete": False, "passed": False, "status": "preparing",
              "ready_sha256": sha(HERE / "ready.json"), "runner_sha256": sha(Path(__file__)),
              "source_manifest_sha256": sha(HERE / "source-manifest.json"), "runtime_artifacts_rehashed": runtime,
              "supervisor_pid": os.getpid(), "processes": [], "compiler_process_cap": 1,
              "export_process_cap": 1, "compile_hard_seconds": 60, "export_hard_seconds": 10,
              "terminate_grace_seconds": 2, "kill_reap_seconds": 5, "retries": 0,
              "assembly_attempts": 0, "assembly_calls": 0, "reference_rollout_intervals": 0,
              "gpu_calls": 0, "optimizer_calls": 0, "python": sys.version,
              "platform": list(os.uname())}
    if not args.execute_assembly:
        report.update(complete=True, passed=True, status="ready_no_children", children_started=0)
        print(json.dumps(report, sort_keys=True), flush=True)
        return 0
    output = HERE / "execution-a"
    output.mkdir(exist_ok=False)
    child = None
    PG.enable_subreaper()
    report["subreaper_enabled"] = True

    def interrupted(signum, _frame):
        raise InterruptedError(str(signum))

    def handlers():
        for kind in (signal.SIGHUP, signal.SIGTERM, signal.SIGINT):
            signal.signal(kind, interrupted)

    def persist():
        save(output / "report.json", report)

    handlers()
    persist()
    try:
        with open("/home/angus/.spacepdhcg-gpu.lock", "a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            report["lock_acquired"] = True
            try:
                # Pin sources again while holding the owner lock, before any compiler child.
                preflight()
                compiler = Path("/usr/bin/g++").resolve(strict=True)
                report["compiler"] = {"path": str(compiler), "sha256": sha(compiler)}
                report["host_math_runtimes"] = {str(p): sha(p) for p in (
                    Path("/lib/x86_64-linux-gnu/libm.so.6"), Path("/lib/x86_64-linux-gnu/libc.so.6"),
                    Path("/usr/lib/x86_64-linux-gnu/libstdc++.so.6"))}
                executable = output / "export_hcw"
                env = {"PATH": "/usr/bin:/bin", "HOME": os.environ["HOME"], "LANG": "C", "LC_ALL": "C",
                       "CUDA_VISIBLE_DEVICES": "", "NVIDIA_VISIBLE_DEVICES": "void", "PYTHONDONTWRITEBYTECODE": "1",
                       "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
                report["environment"] = env
                compile_cmd = [str(compiler), "-std=c++20", "-O2", "-fno-fast-math", "-ffp-contract=off",
                               "-I", str(HERE / "source/include"),
                               '-DCAPTURE_SOURCE_SHA256="' + sha(HERE / "export_hcw.cpp") + '"',
                               '-DCAPTURE_HEADER_MAP_SHA256="' + sha(HERE / "source-manifest.json") + '"',
                               str(HERE / "export_hcw.cpp"), "-o", str(executable)]
                for stage, command, cap in (("compile", compile_cmd, 60),
                                             ("capture", [str(executable), str(output / "capture")], 10)):
                    handlers()
                    entry = {"stage": stage, "argv": command, "hard_seconds": cap, "exit_code": None}
                    report["processes"].append(entry)
                    persist()
                    started = time.perf_counter()
                    try:
                        with open(output / (stage + ".stdout.log"), "xb") as stdout, open(output / (stage + ".stderr.log"), "xb") as stderr:
                            child = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=env,
                                                     cwd=HERE, start_new_session=True, pass_fds=(lock.fileno(),))
                            entry["pid"] = child.pid
                            if stage == "capture":
                                report.update(assembly_attempts=1, assembly_calls=None, reference_rollout_intervals=None)
                            persist()
                            entry["exit_code"] = child.wait(timeout=cap)
                    finally:
                        entry["wall_seconds"] = time.perf_counter() - started
                        entry["cleanup"] = PG.cleanup(child, term_seconds=2, kill_seconds=5)
                        persist()
                    require(entry["cleanup"]["verified_empty"], "owned descendants remain")
                    require(entry["exit_code"] == 0, stage + " failed; no retry")
                    child = None
                    if stage == "compile":
                        report["exporter"] = {"path": str(executable), "bytes": executable.stat().st_size, "sha256": sha(executable)}
                handlers()
                actual = json.loads((output / "capture/capture-report.json").read_text())
                require(actual["source_sha256"] == sha(HERE / "export_hcw.cpp") and
                        actual["header_map_sha256"] == sha(HERE / "source-manifest.json"), "compiled source macro mismatch")
                report["assembly_calls"] = actual["assembly_calls"]
                report["reference_rollout_intervals"] = actual["reference_rollout_intervals"]
                checked = validate(output / "capture")
                save(output / "capture-validation.json", checked)
                report["validation_sha256"] = sha(output / "capture-validation.json")
                report.update(passed=True, status="captured_not_solved")
            finally:
                report["cleanup"] = PG.cleanup(child, term_seconds=2, kill_seconds=5)
                persist()
                require(report["cleanup"]["verified_empty"], "final descendant cleanup failed")
    except BaseException as exc:
        report.update(passed=False, status="failed_preserved", error_type=type(exc).__name__, error=str(exc),
                      traceback=traceback.format_exc())
        if isinstance(exc, BlockingIOError):
            report["status"] = "shared_lock_busy_zero_children"
    finally:
        report["complete"] = True
        report["children_started"] = sum("pid" in x for x in report["processes"])
        report["log_files"] = {p.name: {"bytes": p.stat().st_size, "sha256": sha(p)}
                               for p in sorted(output.glob("*.log"))}
        persist()
        print(json.dumps(report, sort_keys=True), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
