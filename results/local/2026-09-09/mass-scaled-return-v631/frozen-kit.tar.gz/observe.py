"""Retain native pre-clamp results and every independent GPU propagation readback."""

from __future__ import annotations

import ctypes as ct
import time
from contextlib import contextmanager

import common as C
import numpy as np


def save_solution(solution, directory, name):
    np.savez_compressed(
        directory / (name + ".npz"),
        epochs=solution.node_epochs_mjd,
        states_scaled=solution.states_scaled,
        thrust_n=solution.thrust_n,
        departure_vinf=solution.departure_vinf_km_s,
        arrival_vinf=solution.arrival_vinf_km_s,
    )
    C.write(
        directory / (name + ".json"),
        {
            key: getattr(solution, key)
            for key in (
                "status",
                "iterations",
                "accepted_iterations",
                "max_defect",
                "virtual_inf",
                "final_mass_kg",
                "propellant_kg",
                "solve_seconds",
                "diagnostic",
                "seed_backend",
                "outer_transfer_bytes",
                "history",
                "solver_reports",
            )
        },
    )


def copied(pointer, count, dtype):
    return np.frombuffer(ct.string_at(pointer, count * dtype.itemsize), dtype=dtype).copy()


class Observer:
    def __init__(self, output, report, save, *, max_flights, max_waits):
        self.output, self.report, self.save = output, report, save
        self.max_flights, self.max_waits = max_flights, max_waits
        self.index = None
        self.kind = "flight"
        self.wait_id = None
        self.raw = {}
        self.seen_native = set()
        self.seen_certificates = set()

    @contextmanager
    def wait_scope(self, name):
        previous = self.kind, self.wait_id
        self.kind, self.wait_id = "wait", name
        try:
            yield
        finally:
            self.kind, self.wait_id = previous

    def __enter__(self):
        from spacepdhcg.gtoc12 import gpu_scvx, gpu_verifier

        original_solve, original_init = gpu_scvx.solve_native, gpu_verifier.GpuVerifier.__init__
        self.originals = original_solve, original_init

        def solve(*args, **kwargs):
            index = self.index
            if index not in range(self.max_flights) or index in self.seen_native:
                raise RuntimeError(
                    "one native solve per candidate flown leg; finite prescribed route"
                )
            self.seen_native.add(index)
            self.report["native_solves_started"] += 1
            counter = "seeded_calls_started"
            self.report[counter] += 1
            self.save()
            directory = self.output / "legs" / f"{index:02d}"
            started = time.perf_counter()
            row = {"leg": index, "initial_mass_kg": args[0].initial_mass}
            C.write(directory / "native-start.json", row)
            try:
                result = original_solve(*args, **kwargs)
                row["native_call_seconds"] = time.perf_counter() - started
                save_solution(result, directory, "native-raw")
                row.update(status=result.status, iterations=result.iterations)
                self.report["native_solves_returned"] += 1
                self.report["native_iterations"] += result.iterations
                assert result.iterations <= 44
                assert result.seed_backend == "cuda_zoh_mass_scaled_replay"
                assert (
                    result.outer_transfer_bytes["trajectory_upload_bytes"]
                    == (7 + 3 * len(result.node_epochs_mjd)) * 8
                )
                return result
            except BaseException as error:
                row["error"] = repr(error)
                raise
            finally:
                row["including_retention_seconds"] = time.perf_counter() - started
                C.write(directory / "native-finish.json", row)
                self.save()

        def initialize(instance, *args, **kwargs):
            original_init(instance, *args, **kwargs)
            native_run = instance._run

            def run(handle, legs, n, arcs, na, samples, ns, max_steps, results):
                key = (self.kind, self.index if self.kind == "flight" else self.wait_id)
                if key in self.seen_certificates or n != 1:
                    raise RuntimeError("duplicate or batched certificate exceeds finite protocol")
                self.seen_certificates.add(key)
                counter, maximum = (
                    ("flight_certificate_calls", self.max_flights)
                    if self.kind == "flight"
                    else ("wait_certificate_calls", self.max_waits)
                )
                self.report[counter] += 1
                if self.report[counter] > maximum:
                    raise RuntimeError("certificate budget exhausted")
                directory = self.output / "propagation"
                directory.mkdir(exist_ok=True)
                stem = f"{key[0]}-{key[1]}"
                inputs = {
                    "legs": copied(legs, n, gpu_verifier.LEG),
                    "arcs": copied(arcs, na, gpu_verifier.ARC),
                    "samples": copied(samples, ns, gpu_verifier.SAMPLE),
                }
                self.save()
                status, started = None, time.perf_counter()
                try:
                    status = native_run(handle, legs, n, arcs, na, samples, ns, max_steps, results)
                    return status
                finally:
                    raw = copied(results, n, gpu_verifier.RESULT)
                    np.savez_compressed(directory / (stem + ".npz"), **inputs, results=raw)
                    C.write(
                        directory / (stem + ".json"),
                        {
                            "scope": key,
                            "API_status": status,
                            "max_steps": max_steps,
                            "seconds": time.perf_counter() - started,
                            "valid_only_if_API_and_result_status_zero": True,
                        },
                    )
                    self.raw[key] = {
                        "status": status,
                        "rows": raw,
                        "sha256": C.sha(directory / (stem + ".npz")),
                    }
                    self.save()

            instance._run = run

        gpu_scvx.solve_native = solve
        gpu_verifier.GpuVerifier.__init__ = initialize
        return self

    def __exit__(self, *args):
        from spacepdhcg.gtoc12 import gpu_scvx, gpu_verifier

        gpu_scvx.solve_native, gpu_verifier.GpuVerifier.__init__ = self.originals
