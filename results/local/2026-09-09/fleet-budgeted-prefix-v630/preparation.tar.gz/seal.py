"""Bind a reviewed, CPU-tested finite runner; no GPU execution."""
import hashlib
import json
import os
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    profile_path = KIT / "profile.json"
    profile = read(profile_path)
    prerequisites = [
        ROOT / "build/performance/gpu-route-ephemeris-v630/gpu-tests-a/report.json",
        ROOT / "build/performance/route-ephemeris-audit-v630/execution-a/worker/report.json",
    ]
    assert sha(prerequisites[1]) == "e4fecfe0a333a8ee52a313657a032fe6860d606bf41977eb05d03bc7f9d62d28"
    for path in prerequisites:
        report = read(path)
        assert report["complete"] and report["passed"]
    assert sha(profile["library"]["path"]) == profile["library"]["sha256"]
    assert sha(profile["qoco"]["path"]) == profile["qoco"]["sha256"]
    profile["GPU_qualification"] = [{"path": str(p.relative_to(ROOT)), "sha256": sha(p)} for p in prerequisites]
    profile_path.write_text(json.dumps(profile, indent=2) + "\n")
    protocol_path = KIT / "protocol.json"
    protocol = read(protocol_path)
    protocol["stage"] = "prepared_CPU_validated_GPU_prerequisites_passed_not_launched"
    protocol["runtime_profile"] = {"path": "profile.json", "sha256": sha(profile_path)}
    protocol_path.write_text(json.dumps(protocol, indent=2, sort_keys=True) + "\n")
    for name, digest in read(KIT / "host-index.json").items():
        assert sha(KIT / "host" / name) == digest
    external = prerequisites + [
        ROOT / profile["native_manifest"]["path"],
        (ROOT / profile["native_manifest"]["path"]).parent / "source.tar.gz",
        ROOT / "build/performance/seeded-route-v625/runtime.py",
        Path(profile["library"]["path"]), Path(profile["qoco"]["path"]), Path(profile["python"]),
    ]
    assert sha(external[2]) == profile["native_manifest"]["sha256"]
    selected = [p for p in sorted(KIT.rglob("*")) if p.is_file()
                and not any(x in p.parts for x in ("__pycache__", ".pytest_cache", ".ruff_cache"))
                and p.name != "ready.json"]
    ready = {"files": {str(p.relative_to(KIT)): sha(p) for p in selected},
             "external_files": {os.path.relpath(p, KIT): sha(p) for p in external},
             "file_count": len(selected), "bytes": sum(p.stat().st_size for p in selected),
             "source_overlays": read(KIT / "policy-overlays.json"),
             "CPU_validation": read(KIT / "validation-sealed/report.json"),
             "launch_authority": "Root review required; this script launches nothing"}
    assert ready["CPU_validation"]["passed"]
    with (KIT / "ready.json").open("x") as stream:
        json.dump(ready, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"ready_sha256": sha(KIT / "ready.json"), "files": len(selected),
                      "bytes": ready["bytes"], "externals": len(external),
                      "supervisor_sha256": sha(KIT / "supervise.py")}))


if __name__ == "__main__":
    main()
