/**
 * @file cuda_linalg.cu
 * @author Govind M. Chari <govindchari1@gmail.com>
 *
 * @section LICENSE
 *
 * Copyright (c) 2025, Govind M. Chari
 * This source code is licensed under the BSD 3-Clause License
 */

#include "cuda_types.h"
#include <cublas_v2.h>
#include <cuda_runtime.h>
#include <cusparse.h>
#include "common_linalg.h"
#include "cudss_backend.h"
#include "qoco_device_solution.cuh"
#include "qoco_device_io.cuh"
#define SPACEPDHCG_QOCO_QUEUED_OPERATORS 1
#define SPACEPDHCG_QOCO_DEVICE_CONE_REDUCTIONS 1
#define SPACEPDHCG_QOCO_METRIC_GRAPHS 1
#include "qoco_reduction_scope.cuh"

#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t err = call;                                                    \
    if (err != cudaSuccess) {                                                  \
      fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__,         \
              cudaGetErrorString(err));                                        \
      exit(1);                                                                 \
    }                                                                          \
  } while (0)

#include "qoco_gather.cuh"
static void qoco_materialize_device_transpose(const QOCOMatrix*);
#include "qoco_lazy_host_mirror.cuh"
#include "qoco_gpu_transpose.cuh"
#include "qoco_deferred_transpose.cuh"

static inline bool is_device_pointer(const void* ptr)
{
  cudaPointerAttributes attr;
  cudaError_t err = cudaPointerGetAttributes(&attr, ptr);

  if (err != cudaSuccess) {
    cudaGetLastError(); // clear error
    return false;
  }

#if CUDART_VERSION >= 10000
  return (attr.type == cudaMemoryTypeDevice);
#else
  return (attr.memoryType == cudaMemoryTypeDevice);
#endif
}

// CUDA kernels
__global__ void copy_arrayf_kernel(const QOCOFloat* x, QOCOFloat* y, QOCOInt n)
{
  QOCOInt idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < n) {
    y[idx] = x[idx];
  }
}

__global__ void copy_and_negate_arrayf_kernel(const QOCOFloat* x, QOCOFloat* y,
                                              QOCOInt n)
{
  QOCOInt idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < n) {
    y[idx] = -x[idx];
  }
}

__global__ void copy_arrayi_kernel(const QOCOInt* x, QOCOInt* y, QOCOInt n)
{
  QOCOInt idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < n) {
    y[idx] = x[idx];
  }
}

__global__ void scale_arrayf_kernel(const QOCOFloat* x, QOCOFloat* y,
                                    QOCOFloat s, QOCOInt n)
{
  QOCOInt idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < n) {
    y[idx] = s * x[idx];
  }
}

__global__ void axpy_kernel(const QOCOFloat* x, const QOCOFloat* y,
                            QOCOFloat* z, QOCOFloat a, QOCOInt n)
{
  QOCOInt idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < n) {
    z[idx] = a * x[idx] + y[idx];
  }
}

__global__ void ew_product_kernel(const QOCOFloat* x, const QOCOFloat* y,
                                  QOCOFloat* z, QOCOInt n)
{
  QOCOInt i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i < n) {
    z[i] = x[i] * y[i];
  }
}

__global__ void USpMv_kernel(const QOCOCscMatrix* M, const QOCOFloat* v,
                             QOCOFloat* r)
{
  QOCOInt i = blockIdx.x;
  if (i >= M->n)
    return;

  // Process all nonzeros in column i
  for (QOCOInt j = M->p[i]; j < M->p[i + 1]; j++) {
    int row = M->i[j];
    QOCOFloat val = M->x[j] * v[i];

    // Add to r[row] using atomic (multiple columns can write to same row)
    atomicAdd(&r[row], val);

    // If off-diagonal, also add to r[i] (symmetric part)
    // Note: r[i] is only written by thread i, but we use atomic for safety
    if (row != i) {
      atomicAdd(&r[i], M->x[j] * v[row]);
    }
  }
}

__global__ void SpMtv_kernel(const QOCOCscMatrix* M, const QOCOFloat* v,
                             QOCOFloat* r)
{
  QOCOInt col = blockIdx.x * blockDim.x + threadIdx.x;
  if (col >= M->n)
    return;

  QOCOFloat sum = 0.0;

  // Process all nonzeros in column col
  for (QOCOInt idx = M->p[col]; idx < M->p[col + 1]; idx++) {
    QOCOInt row = M->i[idx];
    sum += M->x[idx] * v[row];
  }

  r[col] = sum;
}

__global__ void SpMv_kernel(const QOCOCscMatrix* M, const QOCOFloat* v,
                            QOCOFloat* r)
{
  QOCOInt col = blockIdx.x * blockDim.x + threadIdx.x;
  if (col >= M->n)
    return;

  // Process all nonzeros in column col
  for (QOCOInt idx = M->p[col]; idx < M->p[col + 1]; idx++) {
    QOCOInt row = M->i[idx];
    QOCOFloat val = M->x[idx] * v[col];

    // Add to r[row] using atomic (multiple columns can write to same row)
    atomicAdd(&r[row], val);
  }
}

// Construct A on CPU and create device copy.
QOCOMatrix* new_qoco_matrix(const QOCOCscMatrix* A)
{
  QOCOMatrix* M = (QOCOMatrix*)qoco_malloc(sizeof(QOCOMatrix));
  M->gather = nullptr;
  M->lazy_host_mirror = 0;
  M->host_values_pending = 0;
  M->reference_count = 1;
  M->transpose_source = nullptr;
  M->transpose_map = nullptr;
  M->transpose_values_pending = 0;

  if (A) {
    QOCOInt m = A->m;
    QOCOInt n = A->n;
    QOCOInt nnz = A->nnz;

    // Allocate host CSC matrix
    QOCOCscMatrix* Mcsc = (QOCOCscMatrix*)qoco_malloc(sizeof(QOCOCscMatrix));
    QOCOFloat* x = (QOCOFloat*)qoco_malloc(nnz * sizeof(QOCOFloat));
    QOCOInt* p = (QOCOInt*)qoco_malloc((n + 1) * sizeof(QOCOInt));
    QOCOInt* i = (QOCOInt*)qoco_malloc(nnz * sizeof(QOCOInt));

    copy_arrayf(A->x, x, nnz);
    copy_arrayi(A->i, i, nnz);
    copy_arrayi(A->p, p, n + 1);

    Mcsc->m = m;
    Mcsc->n = n;
    Mcsc->nnz = nnz;
    Mcsc->x = x;
    Mcsc->i = i;
    Mcsc->p = p;
    M->csc = Mcsc;

    // Allocate device CSC matrix (host copy for freeing)
    M->d_csc_host = (QOCOCscMatrix*)qoco_malloc(sizeof(QOCOCscMatrix));

    QOCOCscMatrix* d = M->d_csc_host;
    d->m = m;
    d->n = n;
    d->nnz = nnz;

    CUDA_CHECK(cudaMalloc(&d->x, nnz * sizeof(QOCOFloat)));
    CUDA_CHECK(cudaMalloc(&d->i, nnz * sizeof(QOCOInt)));
    CUDA_CHECK(cudaMalloc(&d->p, (n + 1) * sizeof(QOCOInt)));

    CUDA_CHECK(
        cudaMemcpy(d->x, x, nnz * sizeof(QOCOFloat), cudaMemcpyHostToDevice));
    CUDA_CHECK(
        cudaMemcpy(d->i, i, nnz * sizeof(QOCOInt), cudaMemcpyHostToDevice));
    CUDA_CHECK(
        cudaMemcpy(d->p, p, (n + 1) * sizeof(QOCOInt), cudaMemcpyHostToDevice));

    // Allocate device struct itself and copy host struct into device
    CUDA_CHECK(cudaMalloc(&M->d_csc, sizeof(QOCOCscMatrix)));
    CUDA_CHECK(
        cudaMemcpy(M->d_csc, d, sizeof(QOCOCscMatrix), cudaMemcpyHostToDevice));
  }
  else {
    M->csc = (QOCOCscMatrix*)qoco_malloc(sizeof(QOCOCscMatrix));
    M->d_csc_host = (QOCOCscMatrix*)qoco_malloc(sizeof(QOCOCscMatrix));
    CUDA_CHECK(cudaMalloc(&M->d_csc, sizeof(QOCOCscMatrix)));

    M->csc->m = 0;
    M->csc->n = 0;
    M->csc->nnz = 0;
    M->csc->x = NULL;
    M->csc->i = NULL;
    M->csc->p = NULL;

    M->d_csc_host->m = 0;
    M->d_csc_host->n = 0;
    M->d_csc_host->nnz = 0;
    M->d_csc_host->x = NULL;
    M->d_csc_host->i = NULL;
    M->d_csc_host->p = NULL;
  }
  CUDA_CHECK(cudaGetLastError());

  qoco_gpu_create_gather(M);
  return M;
}

// Construct x on CPU copy vector to GPU.
QOCOVectorf* new_qoco_vectorf(const QOCOFloat* x, QOCOInt n)
{
  QOCOVectorf* v = (QOCOVectorf*)qoco_malloc(sizeof(QOCOVectorf));
  QOCOFloat* vdata = (QOCOFloat*)qoco_malloc(sizeof(QOCOFloat) * n);

  if (x) {
    copy_arrayf(x, vdata, n);
  }
  else {
    for (QOCOInt i = 0; i < n; ++i) {
      vdata[i] = 0.0;
    }
  }

  QOCOFloat* d_vdata;
  CUDA_CHECK(cudaMalloc(&d_vdata, sizeof(QOCOFloat) * n));
  CUDA_CHECK(cudaMemcpy(d_vdata, vdata, sizeof(QOCOFloat) * n,
                        cudaMemcpyHostToDevice));

  v->len = n;
  v->data = vdata;
  v->d_data = d_vdata;

  return v;
}

// Construct x on CPU copy vector to GPU.
QOCOVectori* new_qoco_vectori(const QOCOInt* x, QOCOInt n)
{
  QOCOVectori* v = (QOCOVectori*)qoco_malloc(sizeof(QOCOVectori));
  QOCOInt* vdata = (QOCOInt*)qoco_malloc(sizeof(QOCOInt) * n);

  if (x) {
    copy_arrayi(x, vdata, n);
  }
  else {
    for (QOCOInt i = 0; i < n; ++i) {
      vdata[i] = 0;
    }
  }

  QOCOInt* d_vdata;
  CUDA_CHECK(cudaMalloc(&d_vdata, sizeof(QOCOInt) * n));
  CUDA_CHECK(
      cudaMemcpy(d_vdata, vdata, sizeof(QOCOInt) * n, cudaMemcpyHostToDevice));

  v->len = n;
  v->data = vdata;
  v->d_data = d_vdata;

  return v;
}

void free_qoco_matrix(QOCOMatrix* A)
{
  if (!A)
    return;

  if (--A->reference_count) return;
  auto* retained_source = A->transpose_source;
  qoco_gpu_free_gather(A);
  // Free host CSC
  free_qoco_csc_matrix(A->csc);

  // Free device CSC
  if (A->d_csc_host) {
    CUDA_CHECK(cudaFree(A->d_csc_host->x));
    CUDA_CHECK(cudaFree(A->d_csc_host->i));
    CUDA_CHECK(cudaFree(A->d_csc_host->p));
    qoco_free(A->d_csc_host);
  }

  if (A->d_csc) {
    CUDA_CHECK(cudaFree(A->d_csc));
  }

  qoco_free(A);
  free_qoco_matrix(retained_source);
  CUDA_CHECK(cudaGetLastError());
}

void free_qoco_vectorf(QOCOVectorf* x)
{
  if (x) {
    if (x->data)
      qoco_free(x->data);
    if (x->d_data)
      cudaFree(x->d_data);
    qoco_free(x);
  }
}

void free_qoco_vectori(QOCOVectori* x)
{
  if (x) {
    if (x->data)
      qoco_free(x->data);
    if (x->d_data)
      cudaFree(x->d_data);
    qoco_free(x);
  }
}

QOCOInt get_nnz(const QOCOMatrix* A) { return A->csc->nnz; }

QOCOInt get_length_vectorf(const QOCOVectorf* x) { return x->len; }

void sync_vector_to_host(QOCOVectorf* v)
{
  if (v && v->data && v->d_data) {
    CUDA_CHECK(cudaMemcpy(v->data, v->d_data, v->len * sizeof(QOCOFloat),
                          cudaMemcpyDeviceToHost));
  }
}

void sync_vector_to_device(QOCOVectorf* v)
{
  if (v && v->data && v->d_data) {
    CUDA_CHECK(cudaMemcpy(v->d_data, v->data, v->len * sizeof(QOCOFloat),
                          cudaMemcpyHostToDevice));
  }
}

void sync_matrix_to_device(QOCOMatrix* M)
{
  if (qoco_device_mirror_current(M)) return;
  if (M->csc && M->d_csc) {
    CUDA_CHECK(cudaMemcpy(M->d_csc_host->x, M->csc->x,
                          M->csc->nnz * sizeof(QOCOFloat),
                          cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(M->d_csc_host->i, M->csc->i,
                          M->csc->nnz * sizeof(QOCOInt),
                          cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(M->d_csc_host->p, M->csc->p,
                          (M->csc->n + 1) * sizeof(QOCOInt),
                          cudaMemcpyHostToDevice));
    qoco_gpu_refresh_gather(M);
  }
}

static int in_cpu_mode = 0;

void set_cpu_mode(int active) { in_cpu_mode = active; }

QOCOFloat* get_data_vectorf(const QOCOVectorf* x)
{
  if (in_cpu_mode) {
    return x->data;
  }
  else {
    return x->d_data;
  }
}

QOCOFloat get_element_vectorf(const QOCOVectorf* x, QOCOInt idx)
{
  if (in_cpu_mode) {
    return x->data[idx];
  }
  else {
    return x->d_data[idx];
  }
}

QOCOFloat* get_pointer_vectorf(const QOCOVectorf* x, QOCOInt idx)
{
  if (in_cpu_mode) {
    return &x->data[idx];
  }
  else {
    return &x->d_data[idx];
  }
}

QOCOInt* get_data_vectori(const QOCOVectori* x)
{
  if (in_cpu_mode) {
    return x->data;
  }
  else {
    return x->d_data;
  }
}

QOCOInt get_element_vectori(const QOCOVectori* x, QOCOInt idx)
{
  if (in_cpu_mode) {
    return x->data[idx];
  }
  else {
    return x->d_data[idx];
  }
}

QOCOCscMatrix* get_csc_matrix(const QOCOMatrix* M)
{
  qoco_materialize_device_transpose(M);
  if (in_cpu_mode) {
    qoco_materialize_host_mirror(M);
    return M->csc;
  }
  else {
    return M->d_csc_host;
  }
}

void col_inf_norm_USymm_matrix(const QOCOMatrix* M, QOCOFloat* norm)
{
  // Called during equilibration on CPU
  col_inf_norm_USymm(get_csc_matrix(M), norm);
}

void col_inf_norm_matrix(const QOCOMatrix* M, QOCOFloat* norm)
{
  // Called during equilibration on CPU
  col_inf_norm(get_csc_matrix(M), norm);
}

void row_inf_norm_matrix(const QOCOMatrix* M, QOCOFloat* norm)
{
  // Called during equilibration on CPU
  row_inf_norm(get_csc_matrix(M), norm);
}

void row_col_scale_matrix(QOCOMatrix* M, const QOCOFloat* E, const QOCOFloat* D)
{
  // Called during equilibration on CPU
  row_col_scale(get_csc_matrix(M), (QOCOFloat*)E, (QOCOFloat*)D);
}

void set_element_vectorf(QOCOVectorf* x, QOCOInt idx, QOCOFloat data)
{
  // Called during equilibration on CPU
  x->data[idx] = data;
}

void reciprocal_vectorf(const QOCOVectorf* input, QOCOVectorf* output)
{
  // Called during equilibration on CPU
  for (QOCOInt i = 0; i < input->len; ++i) {
    output->data[i] = safe_div(1.0, input->data[i]);
  }
}

QOCOCscMatrix* new_qoco_csc_matrix(const QOCOCscMatrix* A)
{
  QOCOCscMatrix* M = (QOCOCscMatrix*)qoco_malloc(sizeof(QOCOCscMatrix));

  if (A) {
    QOCOInt m = A->m;
    QOCOInt n = A->n;
    QOCOInt nnz = A->nnz;

    QOCOFloat* x = (QOCOFloat*)qoco_malloc(nnz * sizeof(QOCOFloat));
    QOCOInt* p = (QOCOInt*)qoco_malloc((n + 1) * sizeof(QOCOInt));
    QOCOInt* i = (QOCOInt*)qoco_malloc(nnz * sizeof(QOCOInt));

    copy_arrayf(A->x, x, nnz);
    copy_arrayi(A->i, i, nnz);
    copy_arrayi(A->p, p, n + 1);

    M->m = m;
    M->n = n;
    M->nnz = nnz;
    M->x = x;
    M->i = i;
    M->p = p;
  }
  else {
    M->m = 0;
    M->n = 0;
    M->nnz = 0;
    M->x = NULL;
    M->i = NULL;
    M->p = NULL;
  }

  return M;
}

void free_qoco_csc_matrix(QOCOCscMatrix* A)
{
  if (A) {
    free(A->x);
    free(A->i);
    free(A->p);
    free(A);
  }
}

void copy_arrayf(const QOCOFloat* x, QOCOFloat* y, QOCOInt n)
{
  qoco_assert(x || n == 0);
  qoco_assert(y || n == 0);

  // If either pointer check succeeds and one is on device, use CUDA kernel.
  if (is_device_pointer(x) && is_device_pointer(y)) {
    const QOCOInt blockSize = 256;
    const QOCOInt numBlocks = (n + blockSize - 1) / blockSize;
    copy_arrayf_kernel<<<numBlocks, blockSize>>>(x, (QOCOFloat*)y, n);
    CUDA_CHECK(qoco_complete_vector_operation());
    CUDA_CHECK(cudaGetLastError());
  }
  else {
    // If both pointers are on host, use CPU.
    for (QOCOInt i = 0; i < n; ++i) {
      y[i] = x[i];
    }
  }
}

void copy_and_negate_arrayf(const QOCOFloat* x, QOCOFloat* y, QOCOInt n)
{
  qoco_assert(x || n == 0);
  qoco_assert(y || n == 0);

  if (n == 0)
    return;

  const QOCOInt blockSize = 256;
  const QOCOInt numBlocks = (n + blockSize - 1) / blockSize;
  copy_and_negate_arrayf_kernel<<<numBlocks, blockSize>>>(x, (QOCOFloat*)y, n);
  CUDA_CHECK(qoco_complete_vector_operation());
  CUDA_CHECK(cudaGetLastError());
}

// Only called by CPU during setup.
void copy_arrayi(const QOCOInt* x, QOCOInt* y, QOCOInt n)
{
  for (QOCOInt i = 0; i < n; ++i) {
    y[i] = x[i];
  }
}

void ew_product(QOCOFloat* x, const QOCOFloat* y, QOCOFloat* z, QOCOInt n)
{
  if (is_device_pointer(x) && is_device_pointer(y) && is_device_pointer(z)) {
    const int threads = 256;
    const int blocks = (n + threads - 1) / threads;
    ew_product_kernel<<<blocks, threads, 0, qoco_metric_stream>>>(x, y, z, n);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(qoco_complete_vector_operation());
  }
  else {
    for (QOCOInt i = 0; i < n; ++i) {
      z[i] = x[i] * y[i];
    }
  }
}

// TODO: Don't create and destroy cublas handle for each dot product. One way
// around this is to create a custom kernel for the dot product.
QOCOFloat qoco_dot(const QOCOFloat* u, const QOCOFloat* v, QOCOInt n)
{
  qoco_assert(u || n == 0);
  qoco_assert(v || n == 0);

  if (n == 0)
    return 0.0;

  if (is_device_pointer(u) && is_device_pointer(v)) {

    CudaLibFuncs* funcs = get_cuda_funcs();
    bool temporary_handle;
    cublasHandle_t handle = qoco_acquire_reduction_handle(&temporary_handle);
    QOCOFloat result;
    funcs->cublasDdot(handle, n, (const double*)u, 1, (const double*)v, 1,
                      (double*)&result);
    if (temporary_handle) funcs->cublasDestroy(handle);
    return result;
  }
  else {
    QOCOFloat x = 0.0;
    for (QOCOInt i = 0; i < n; ++i) {
      x += u[i] * v[i];
    }
    return x;
  }
}

QOCOInt max_arrayi(const QOCOInt* x, QOCOInt n)
{
  QOCOInt max = -QOCOInt_MAX;
  for (QOCOInt i = 0; i < n; ++i) {
    max = qoco_max(max, x[i]);
  }
  return max;
}

void scale_arrayf(const QOCOFloat* x, QOCOFloat* y, QOCOFloat s, QOCOInt n)
{
  qoco_assert(x || n == 0);
  qoco_assert(y || n == 0);

  if (n == 0)
    return;

  // If either pointer check succeeds and one is on device, use CUDA
  if (is_device_pointer(x) && is_device_pointer(y)) {
    const QOCOInt blockSize = 256;
    const QOCOInt numBlocks = (n + blockSize - 1) / blockSize;
    scale_arrayf_kernel<<<numBlocks, blockSize, 0, qoco_metric_stream>>>(x, y, s, n);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(qoco_complete_vector_operation());
  }
  else {
    for (QOCOInt i = 0; i < n; ++i) y[i] = s * x[i];
  }
}

void qoco_axpy(const QOCOFloat* x, const QOCOFloat* y, QOCOFloat* z,
               QOCOFloat a, QOCOInt n)
{
  qoco_assert(x || n == 0);
  qoco_assert(y || n == 0);

  if (n == 0)
    return;

  const QOCOInt blockSize = 256;
  const QOCOInt numBlocks = (n + blockSize - 1) / blockSize;
  axpy_kernel<<<numBlocks, blockSize, 0, qoco_metric_stream>>>(x, y, z, a, n);
  CUDA_CHECK(cudaGetLastError());
  CUDA_CHECK(qoco_complete_vector_operation());
}

void USpMv(const QOCOMatrix* M, const QOCOFloat* v, QOCOFloat* r)
{
  qoco_materialize_device_transpose(M);
  qoco_gpu_product<true>(M, v, r);
}

void SpMv(const QOCOMatrix* M, const QOCOFloat* v, QOCOFloat* r)
{
  qoco_materialize_device_transpose(M);
  qoco_gpu_product<false>(M, v, r);
}

void SpMtv(const QOCOMatrix* M, const QOCOFloat* v, QOCOFloat* r)
{
  qoco_materialize_device_transpose(M);
  if (M->d_csc_host->n > 0) {
    CUDA_CHECK(cudaMemsetAsync(r, 0, M->d_csc_host->n * sizeof(QOCOFloat), qoco_metric_stream));
    SpMtv_kernel<<<(M->d_csc_host->n + 255) / 256, 256, 0, qoco_metric_stream>>>(M->d_csc, v, r);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(qoco_complete_vector_operation());
  }
}

#include "qoco_device_scalar.cuh"

QOCOFloat inf_norm(const QOCOFloat* x, QOCOInt n)
{
  qoco_assert(x || n == 0);

  if (n == 0)
    return 0.0;

  if (is_device_pointer(x)) {
    return qoco_device_scalar::run<qoco_device_scalar::Maximum>(x, n);
  }
  else {
    QOCOFloat norm = 0.0;
    QOCOFloat xi;
    for (QOCOInt i = 0; i < n; ++i) {
      xi = qoco_abs(x[i]);
      norm = qoco_max(norm, xi);
    }
    return norm;
  }
}

QOCOFloat min_abs_val(const QOCOFloat* x, QOCOInt n)
{
  qoco_assert(x || n == 0);

  if (n == 0)
    return QOCOFloat_MAX;

  if (is_device_pointer(x)) {
    return qoco_device_scalar::run<qoco_device_scalar::Minimum>(x, n);
  }
  else {
    QOCOFloat min_val = QOCOFloat_MAX;
    QOCOFloat xi;
    for (QOCOInt i = 0; i < n; ++i) {
      xi = qoco_abs(x[i]);
      min_val = qoco_min(min_val, xi);
    }
    return min_val;
  }
}

__global__ void check_nan_kernel(const QOCOFloat* x, QOCOInt n, QOCOInt* found)
{
  QOCOInt i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i < n) {
    if (isnan(x[i])) {
      atomicExch(found, 1);
    }
  }
}

QOCOInt check_nan(const QOCOVectorf* x)
{
  return static_cast<QOCOInt>(qoco_device_scalar::run<qoco_device_scalar::HasNan>(x->d_data, x->len));
}

void sync_matrix_values_to_device(QOCOMatrix* M)
{
  if (qoco_device_mirror_current(M)) return;
  if (M && M->d_csc_host && M->csc->nnz > 0) {
    CUDA_CHECK(cudaMemcpy(M->d_csc_host->x, M->csc->x,
                          M->csc->nnz * sizeof(QOCOFloat), cudaMemcpyHostToDevice));
  }
}

#include "qoco_device_update.cuh"

#define SPACEPDHCG_QOCO_BATCHED_ITERATION 1

#include "qoco_ipm_parameters.cuh"
#include "qoco_batched_stopping.cuh"

#include "qoco_device_step_control.cuh"

#include "qoco_device_combined_rhs.cuh"

#include "qoco_trajectory_ordering.cuh"

#include "qoco_fused_kkt_product.cuh"

extern "C" cudaStream_t qoco_ir_exchange_stream(cudaStream_t stream) {
    const auto previous = qoco_metric_stream;
    qoco_metric_stream = stream;
    return previous;
}
extern "C" cudaStream_t qoco_ir_current_stream() { return qoco_metric_stream; }
extern "C" void qoco_ir_prepare_sparse(QOCOProblemData* data) {
    if (data->P) qoco_materialize_device_transpose(data->P);
    if (data->p) qoco_materialize_device_transpose(data->A);
    if (data->m) qoco_materialize_device_transpose(data->G);
}
extern "C" void qoco_ir_device_norm(const double* x, int count, double* scratch, cudaStream_t stream) {
    using namespace qoco_device_scalar;
    const int blocks = count <= 4096 ? 1 : std::min(256, (count - 1) / 256 + 1);
    double* output = scratch + 256;
    reduce<Maximum, false><<<blocks, 256, 0, stream>>>(x, count, blocks == 1 ? output : scratch);
    if (blocks > 1) reduce<Maximum, true><<<1, 256, 0, stream>>>(scratch, blocks, output);
    CUDA_CHECK(cudaGetLastError());
}

#include "qoco_device_control.cuh"

#include "qoco_device_direction.cuh"

#include "qoco_ipm_resources.cuh"
#include "qoco_ipm_control.cuh"

#include "qoco_ipm_initial_control.cuh"

#include "qoco_ipm_terminal.cuh"

#include "qoco_ipm_completion.cuh"
extern "C" int qoco_gpu_ipm_resources_compatible(void* pointer) {
    auto* r = static_cast<QocoIpmResources*>(pointer);
    int device;
    return r && !r->active && cudaGetDevice(&device) == cudaSuccess &&
        r->device == device && r->owner == std::this_thread::get_id();
}
