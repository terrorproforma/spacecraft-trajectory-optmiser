"""Retain finite CPU preparation checks; never launch the mission worker."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
out = KIT / sys.argv[1]
out.mkdir()
files = ["common.py", "worker.py", "supervise.py", "runtime.py", "observe.py", "check_fleet.py", "test_runtime.py"]
stages = [
    ("format", [sys.executable, "-m", "ruff", "format", "--check", *files]),
    ("lint", [sys.executable, "-m", "ruff", "check", "--no-cache", *files]),
    ("cpu", [sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-q", "test_runtime.py", "test_process_guard.py", "--tb=short"]),
]
report = {"GPU_calls": 0, "propagations": 0, "stages": [], "files": {name: hashlib.sha256((KIT / name).read_bytes()).hexdigest() for name in files}}
env = os.environ | {"CUDA_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1"}
for name, command in stages:
    start = time.perf_counter()
    result = subprocess.run(command, cwd=KIT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=90)
    (out / (name + ".log")).write_bytes(result.stdout)
    report["stages"].append({"name": name, "command": command, "returncode": result.returncode, "seconds": time.perf_counter() - start})
report["passed"] = all(x["returncode"] == 0 for x in report["stages"])
(out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
raise SystemExit(0 if report["passed"] else 1)
