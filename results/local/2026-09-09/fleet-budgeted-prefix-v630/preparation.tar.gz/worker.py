"""Three prescribed prefixes maximum, one small CUDA fleet selection, one checker pair."""

from __future__ import annotations

import hashlib
import itertools
import os
import time
import traceback
from types import SimpleNamespace

import common as C

COUNTERS = (
    "native_solves_started",
    "native_solves_returned",
    "native_iterations",
    "flight_certificate_calls",
    "wait_certificate_calls",
    "seeded_calls_started",
    "cold_calls_started",
)


def boundary_ephemeris_of(route):
    telemetry = dict(route.scheduler_telemetry.get("boundary_ephemeris", {}))
    if telemetry.get("backend") != "cuda" or telemetry.get("batches") != 1:
        raise ValueError("prescribed native route must record exactly one CUDA boundary batch")
    return telemetry


def main():
    if not __debug__ or os.environ.get("SPACEPDHCG_ROUTE_SUPERVISED") != str(os.getppid()):
        raise RuntimeError("Use the single foreground supervisor")
    frozen = C.activate()
    from check_fleet import check
    from observe import Observer
    from runtime import Coordinator, emit_route

    from spacepdhcg.gtoc12 import pipeline as p
    from spacepdhcg.gtoc12.bundles import ClusterPricingSettings, refine_candidates
    from spacepdhcg.gtoc12.cooperative import FleetColumn
    from spacepdhcg.gtoc12.fixed_refinement import refine_fixed
    from spacepdhcg.gtoc12.gpu_execution import using_gpu_execution
    from spacepdhcg.gtoc12.gpu_fleet import CudaFleetWorkspace
    from spacepdhcg.gtoc12.low_thrust import ScvxSettings
    from spacepdhcg.gtoc12.refinement_admission import FixedCargoRequest, FleetBudgetContext
    from spacepdhcg.gtoc12.search import RoutePlan
    from spacepdhcg.gtoc12.solution import Solution

    output = C.KIT / "output"
    start = time.perf_counter()
    deadline = start + 600
    protocol = C.read(C.KIT / "protocol.json")
    report = {
        "complete": False,
        "status": "running",
        "pid": os.getpid(),
        "cases": [],
        "full_fleet_CPU_checks": 0,
        "full_fleet_official_checks": 0,
        "runtime_CPU_body_state_calls": 0,
        "whole_routes_started": 0,
        "fleet_selection_calls": 0,
        "search_or_Lambert_calls": 0,
        "standalone_seed_inspections": 0,
        "source_Result_sha256": C.RESULT_SHA,
        "incumbent_promotions": 0,
    } | dict.fromkeys(COUNTERS, 0)

    def save():
        for key in COUNTERS:
            report[key] = sum(case[key] for case in report["cases"])
        C.current(output / "partial-report.json", report)
        assert report["whole_routes_started"] <= 3
        assert report["native_solves_started"] <= 50 and report["native_iterations"] <= 2200
        assert report["flight_certificate_calls"] <= 50 and report["wait_certificate_calls"] <= 3
        assert report["seeded_calls_started"] <= 3 and report["cold_calls_started"] <= 47

    original_body = p.body_state

    def body_state(*args):
        report["runtime_CPU_body_state_calls"] += 1
        return original_body(*args)

    coordinator = None
    try:
        for name, row in C.read(C.KIT / "input-index.json").items():
            assert C.sha(C.KIT / "inputs" / name) == row["sha256"]
        assert C.sha(C.BASE / "Result.txt") == C.RESULT_SHA
        baseline = C.read(C.BASE / "checker-binding.json")
        assert (
            baseline["result_sha256"] == C.RESULT_SHA
            and baseline["independent"]["ok"]
            and baseline["official"]["ok"]
        )
        C.write(output / "baseline-reused.json", baseline)
        catalogue, bonus = frozen.catalogue_and_bonus()
        weights = {int(a): float(bonus.coefficient[int(a) - 1]) for a in catalogue.ids}
        context = FleetBudgetContext.from_verified_result(
            (C.BASE / "Result.txt").read_bytes(),
            independent=baseline["independent"],
            official=baseline["official"],
            weights=weights,
        )
        admission = []
        for case in protocol["candidates"]:
            candidate = RoutePlan.from_summary(C.read(C.KIT / "inputs" / case["input_file"]))
            request = FixedCargoRequest.from_summary(candidate.summary())
            assert request.sha256 == case["request_sha256"]
            chosen = refine_candidates(
                [candidate],
                set(),
                ClusterPricingSettings(ships=1, refine_top=1),
                fleet_context=context,
                replacement_ship=case["ship"],
            )
            assert chosen == [candidate]
            budget = context.replacement(case["ship"], request)
            assert not budget.blocker and abs(budget.raw_gain_kg - case["raw_delta_kg"]) <= 1e-8
            assert abs(budget.objective_gain_kg - case["weighted_delta_kg"]) <= 1e-8
            admission.append(
                {
                    "id": case["id"],
                    "request_sha256": request.sha256,
                    "prescribed_budget": C.safe(budget),
                    "production_selector_admitted": True,
                }
            )
        C.write(output / "production-admission.json", admission)
        settings = ScvxSettings(**protocol["settings"])
        assert settings.selected_ephemeris_backend() == "cuda"
        assert settings.max_iterations == 40 and settings.polish_iterations == 4
        p.body_state = body_state
        certified = []
        with using_gpu_execution(
            SimpleNamespace(gpu_execution="graph", outer_loop_backend="cuda", workers=1)
        ):
            for case in protocol["candidates"]:
                if time.perf_counter() >= deadline:
                    report["stopped_before_case"] = case["id"]
                    break
                directory = output / case["id"]
                directory.mkdir()
                record = {
                    "id": case["id"],
                    "ship": case["ship"],
                    "rank": case["rank"],
                    "status": "started",
                    "certified": False,
                } | dict.fromkeys(COUNTERS, 0)
                report["cases"].append(record)
                report["whole_routes_started"] += 1
                save()
                plan = RoutePlan.from_summary(C.read(C.KIT / "inputs" / case["input_file"]))
                identity, cargo = plan.summary(), dict(plan.collected_mass)
                assert (
                    FixedCargoRequest.from_summary(identity, cargo).sha256 == case["request_sha256"]
                )
                C.write(directory / "prescribed-plan.json", identity)
                observer = Observer(
                    directory,
                    record,
                    save,
                    max_flights=case["native_flights"],
                    max_waits=len(case["waits"]),
                )
                coordinator = Coordinator(plan, catalogue, case, directory, observer, deadline)
                stamp = time.perf_counter()
                try:
                    with observer:
                        route = refine_fixed(
                            plan,
                            catalogue,
                            cargo,
                            settings=settings,
                            on_leg=coordinator.on_leg,
                            boundary_factory=coordinator.boundary_factory,
                            seed_factory=coordinator.seed_factory,
                            deadline=deadline,
                        )
                    C.write(directory / "route-result.json", route.summary())
                    record["boundary_ephemeris"] = boundary_ephemeris_of(route)
                    C.write(directory / "wait-summary.json", coordinator.wait_results)
                    assert identity == plan.summary() and cargo == route.collected_mass
                    record.update(
                        certified=bool(
                            route.certified
                            and not route.failures
                            and coordinator.all_waits_passed()
                        ),
                        status="certified"
                        if route.certified and coordinator.all_waits_passed()
                        else "refinement_or_wait_failed",
                        failures=route.failures,
                        seconds=time.perf_counter() - stamp,
                    )
                    if record["certified"]:
                        payload = emit_route(route, coordinator)
                        with (directory / "ship.txt").open("xb") as stream:
                            stream.write(payload)
                        column = FleetColumn.from_plan(
                            1000 + len(certified),
                            case["ship"],
                            case["id"],
                            plan,
                            route.collected_mass,
                            certified=True,
                        )
                        certified.append((column, payload, case))
                        record.update(
                            ship_sha256=hashlib.sha256(payload).hexdigest(),
                            prescribed_raw_kg=sum(cargo.values()),
                            prescribed_weighted_kg=sum(weights[a] * m for a, m in cargo.items()),
                            final_dry_mass_kg=route.final_mass_kg,
                        )
                except Exception as error:
                    record.update(
                        status="case_exception", error=repr(error), traceback=traceback.format_exc()
                    )
                finally:
                    coordinator.close()
                    coordinator = None
                    C.write(directory / "case-report.json", record)
                    save()
        if not certified:
            report["status"] = "no_new_certified_routes_incumbent_retained"
            return
        # Baseline ships are individually archived and jointly bound to both original checks.
        fleet = Solution.read(C.BASE / "Result.txt")
        columns, incumbent = [], []
        for ship in fleet.ships:
            dep, col, mass = {}, {}, {}
            for event in ship.asteroid_visits():
                delta = event.after.mass - event.before.mass
                if delta < 0:
                    assert abs(delta + 40) < 1e-7 and event.event_id not in dep
                    dep[event.event_id] = event.epoch
                else:
                    assert event.event_id not in col
                    col[event.event_id], mass[event.event_id] = event.epoch, delta
            assert set(dep) == set(col)
            column = FleetColumn(
                ship.ship_id, ship.ship_id, "verified frontier v629", dep, col, {}, mass, True
            )
            columns.append(column)
            incumbent.append(column)
        columns.extend(row[0] for row in certified)
        if time.perf_counter() >= deadline:
            report["status"] = "deadline_before_fleet_selection_incumbent_retained"
            return
        report["fleet_selection_calls"] += 1
        save()
        with CudaFleetWorkspace(columns, weights=weights) as master:
            selection = master.solve(
                incumbent=incumbent, max_ships=23, node_cap=100_000, exchange_rounds=8
            )
        C.write(output / "fleet-selection.json", selection.summary())
        selected = [
            row
            for row in certified
            if row[0].identifier in {c.identifier for c in selection.selected}
        ]
        assert len(selection.selected) == 23 and len({c.slot for c in selection.selected}) == 23
        if not selected:
            report["status"] = "no_better_selected_fleet_incumbent_retained"
            return
        # Verify the single GPU choice against at most eight prescribed combinations.
        alternatives = [
            [None] + [row for row in certified if row[2]["ship"] == ship] for ship in [22, 10, 19]
        ]
        enumerated = []
        for pair in itertools.product(*alternatives):
            chosen = [r for r in pair if r is not None]
            raw = baseline["independent"]["total_mass_kg"] + sum(
                r[2]["raw_delta_kg"] for r in chosen
            )
            score = baseline["independent"]["weighted_score_fixed_bonus_kg"] + sum(
                r[2]["weighted_delta_kg"] for r in chosen
            )
            footprints = [set(r[2]["asteroids"]) for r in chosen]
            if len(columns[:23]) <= p.C.maximum_ship_count(raw / 23) and all(
                not a & b for i, a in enumerate(footprints) for b in footprints[i + 1 :]
            ):
                enumerated.append(
                    {"ids": [r[2]["id"] for r in chosen], "raw_kg": raw, "weighted_kg": score}
                )
        best = max(r["weighted_kg"] for r in enumerated)
        expected = {
            "raw_kg": baseline["independent"]["total_mass_kg"]
            + sum(r[2]["raw_delta_kg"] for r in selected),
            "weighted_kg": baseline["independent"]["weighted_score_fixed_bonus_kg"]
            + sum(r[2]["weighted_delta_kg"] for r in selected),
        }
        C.write(
            output / "selection-oracle.json",
            {
                "combinations": enumerated,
                "selected": [r[2]["id"] for r in selected],
                "expected": expected,
            },
        )
        assert abs(expected["weighted_kg"] - best) <= 1e-8
        replacements = {row[2]["ship"]: row[1] for row in selected}
        payload = C.splice((C.BASE / "Result.txt").read_bytes(), replacements)
        directory = output / "fleet"
        directory.mkdir()
        path = directory / "Result.txt"
        with path.open("xb") as stream:
            stream.write(payload)
        parsed = Solution.read(path)
        expected["asteroids"] = len(
            {e.event_id for ship in parsed.ships for e in ship.asteroid_visits()}
        )
        old, new = C.sections((C.BASE / "Result.txt").read_bytes()), C.sections(payload)
        C.write(
            directory / "retained-sections.json",
            {
                "baseline_Result_sha256": C.RESULT_SHA,
                "result_sha256": C.sha(path),
                "changed_ships": sorted(replacements),
                "all_unselected_sections_exact": all(
                    old[n] == new[n] for n in old if n not in replacements
                ),
                "section_sha256": {n: hashlib.sha256(data).hexdigest() for n, data in new.items()},
            },
        )
        report["acceptance"] = check(path, catalogue, bonus, report, save, deadline, expected)
        report["status"] = (
            "verified_fleet_improvement"
            if report["acceptance"]["accepted_improvement"]
            else "full_fleet_rejected_incumbent_retained"
        )
    except BaseException as error:
        report.update(
            status="execution_failed", error=repr(error), traceback=traceback.format_exc()
        )
        raise
    finally:
        p.body_state = original_body
        if coordinator is not None:
            coordinator.close()
        report.update(complete=True, worker_seconds=time.perf_counter() - start)
        save()
        C.write(output / "report.json", report)


if __name__ == "__main__":
    main()
