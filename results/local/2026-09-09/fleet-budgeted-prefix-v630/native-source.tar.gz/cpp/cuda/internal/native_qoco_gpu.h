#pragma once

#include <cuda_runtime.h>
#include <cstdint>

struct QocoAuditCsc {
    int rows, columns, nonzeros;
    const int* offsets;
    const int* indices;
    const double* values;
};

struct QocoAuditInput {
    QocoAuditCsc quadratic, equality, conic, dual_map;
    const double* objective;
    const double* equality_rhs;
    const double* conic_rhs;
    int nonnegative, soc_count;
    const int* soc_sizes;
};

struct QocoAuditResult {
    double primal, dual, absolute_primal, absolute_dual, dual_cone, complementarity;
};
struct QocoReplayStatus { int status, iterations; };

// A device ledger for executions, not host calls made while recording a graph.
struct QocoGraphProgress {
    std::uint64_t attempts{}, solver_runs{}, iterations{}, d2d_count{}, d2d_bytes{};
    QocoReplayStatus last_status{};
    QocoAuditResult last_audit{};
    int last_validation{};
};
cudaError_t qoco_gpu_graph_record(QocoGraphProgress*,const QocoReplayStatus*,
    const QocoAuditResult*,const int*,std::uint64_t,std::uint64_t,cudaStream_t);

struct QocoAuditTransfers {
    std::uint64_t h2d_count{}, h2d_bytes{}, d2h_count{}, d2h_bytes{};
};

// Audit-owned allocations only, excluding opaque QOCO/cuDSS workspaces.
struct QocoAuditMemory {
    std::uint64_t allocations{}, bytes{}, peak_bytes{};
};

struct QocoGpuAudit;

cudaError_t qoco_gpu_audit_create(const QocoAuditInput&, bool host_solution,
                                cudaStream_t, QocoGpuAudit**);
cudaError_t qoco_gpu_audit_update(QocoGpuAudit*, const QocoAuditInput&, cudaStream_t);
cudaError_t qoco_gpu_audit_update_device(QocoGpuAudit*, const double* packed_values, cudaStream_t);
cudaError_t qoco_gpu_audit_upload_solution(QocoGpuAudit*, const double*, const double*,
                                         const double*, cudaStream_t,
                                         const double**, const double**, const double**);
// Inputs are unscaled device vectors. The mapped dual is written on the same
// stream. Only the six audit scalars are downloaded; no CPU numerical work.
cudaError_t qoco_gpu_audit_run(QocoGpuAudit*, const double*, const double*, const double*,
                             double* mapped_dual, cudaStream_t, QocoAuditResult*);
// Queue the same independent audit and return retained device scalars. No host
// download or wait. Consume on the same stream before updating/reusing the audit.
cudaError_t qoco_gpu_audit_run_device(QocoGpuAudit*, const double*, const double*, const double*,
                                    double* mapped_dual, cudaStream_t, const QocoAuditResult**);
// Queue an explicitly requested host report; caller owns destination lifetime
// and completes the stream. Transfer accounting remains owned by the audit.
cudaError_t qoco_gpu_audit_download_async(QocoGpuAudit*, cudaStream_t, QocoAuditResult*);
// Validate completion ABI v1 on device and retain only the two fields needed by
// transitional host dispatch. An unknown ABI produces status -1.
cudaError_t qoco_gpu_audit_replay_status(QocoGpuAudit*, const int* completion_header,
                                      cudaStream_t, const QocoReplayStatus**);
// Bootstrap bridge for a synchronous priming solve; subsequent replay status
// comes directly from the device completion packet.
cudaError_t qoco_gpu_audit_publish_status(QocoGpuAudit*, int status, int iterations,
                                       cudaStream_t, const QocoReplayStatus**);
const QocoAuditResult* qoco_gpu_audit_device_result(const QocoGpuAudit*);
QocoAuditTransfers qoco_gpu_audit_transfers(const QocoGpuAudit*);
QocoAuditMemory qoco_gpu_audit_memory(const QocoGpuAudit*);
void qoco_gpu_audit_destroy(QocoGpuAudit*);

// Optional translated primal coordinates x = delta + origin. Allocate retained
// storage once, then copy a device prefix (remaining coordinates are zero).
// Transform ONLY solver data: P unchanged, c'=c+P*origin, b'=b-A*origin,
// h'=h-G*origin. The audit always retains the original formulation.
cudaError_t qoco_gpu_audit_enable_origin(QocoGpuAudit*);
cudaError_t qoco_gpu_audit_set_origin(QocoGpuAudit*, const double*, int, cudaStream_t);
cudaError_t qoco_gpu_audit_origin_values(QocoGpuAudit*, const double*, cudaStream_t, const double**);
// Borrow until audit destruction; contents refresh before the translated solve.
const double* qoco_gpu_audit_origin(const QocoGpuAudit*);
const double* qoco_gpu_audit_origin_offset(const QocoGpuAudit*);
cudaError_t qoco_gpu_audit_reconstruct(QocoGpuAudit*, const double*, double*, cudaStream_t);

struct QocoTopologyInput {
    int counts[6]{};
    const int* arrays[6]{};
};
struct QocoGpuTopology;
// Create from host topology once; subsequent validation compares device arrays
// exactly and downloads a single mismatch flag, rather than the sparse indices.
cudaError_t qoco_gpu_topology_create(const QocoTopologyInput&, cudaStream_t, QocoGpuTopology**);
cudaError_t qoco_gpu_topology_validate(QocoGpuTopology*, const QocoTopologyInput&,
                                     cudaStream_t, bool* match);
// Borrowed device mismatch flag; capture-compatible, no download or wait.
cudaError_t qoco_gpu_topology_validate_device(QocoGpuTopology*, const QocoTopologyInput&,
    cudaStream_t, const int** mismatch);
QocoAuditTransfers qoco_gpu_topology_transfers(const QocoGpuTopology*);
QocoAuditMemory qoco_gpu_topology_memory(const QocoGpuTopology*);
void qoco_gpu_topology_destroy(QocoGpuTopology*);

// Canonical arrays: Q, A, F, c, scalar lower/upper, affine offset, variable lower/upper.
// A term is scale * (input[index] + other_scale * input[other]); other=-1 omits
// the second operand, input=-1 denotes the constant scale. Output rows sum terms
// in their compiled order, preserving duplicate sparse entries and SOC transforms.
struct QocoConversionTerm { int input, index, other; double scale, other_scale; };
struct QocoConversionPair { int first, second; };
struct QocoConversionPlan {
    int input_counts[9]{};
    int outputs{}, terms{}, symmetry_pairs{};
    const int* offsets{};
    const QocoConversionTerm* entries{};
    const int* bound_types{}; // scalar then variable; 0=free, 1=upper, 2=lower, 3=both, 4=equality
    const QocoConversionPair* symmetry{};
};
struct QocoConversionInputs { const double* arrays[9]{}; };
// Initial symbolic classification on CUDA. Download one byte per bound pair,
// scalar rows then variables: 0=free, 1=upper, 2=lower, 3=both, 4=equality,
// 255=NaN. No floating-point bound values leave the device. Completes stream.
cudaError_t qoco_gpu_bound_types(int scalar_rows, int variables,
    const double* scalar_lower, const double* scalar_upper,
    const double* variable_lower, const double* variable_upper,
    unsigned char* host_types, cudaStream_t);
struct QocoGpuConversion;
cudaError_t qoco_gpu_conversion_create(const QocoConversionPlan&, cudaStream_t, QocoGpuConversion**);
// invalid: bit 1=changed bound classification, bit 2=nonfinite arithmetic,
// bit 4=asymmetric quadratic. A null host_output retains values only on the device.
cudaError_t qoco_gpu_conversion_run(QocoGpuConversion*, const QocoConversionInputs&,
    double* host_output, int* invalid, cudaStream_t);
// Device flags retain bits 1/2/4 above; bit 8 denotes a topology mismatch.
// topology_mismatch may be null. All operands/results belong to the same stream.
cudaError_t qoco_gpu_conversion_run_device(QocoGpuConversion*, const QocoConversionInputs&,
    const int* topology_mismatch, cudaStream_t, const int** invalid);
cudaError_t qoco_gpu_conversion_download_flags_async(QocoGpuConversion*, cudaStream_t, int*);
// Combine a same-stream producer's nonzero invalid flag as bit 16. Queue after
// conversion validation, before numeric guarding; no download or wait.
cudaError_t qoco_gpu_conversion_include_producer(QocoGpuConversion*, const int*, cudaStream_t);
// Copy QOCO's borrowed nine-double scale report into retained conversion storage,
// combining its invalid flag with canonical validation before guarded replay.
cudaError_t qoco_gpu_conversion_guard_numeric(QocoGpuConversion*, const double* numeric_result,
    cudaStream_t, const double** guarded_result);
const double* qoco_gpu_conversion_values(const QocoGpuConversion*);
QocoAuditTransfers qoco_gpu_conversion_transfers(const QocoGpuConversion*);
QocoAuditMemory qoco_gpu_conversion_memory(const QocoGpuConversion*);
void qoco_gpu_conversion_destroy(QocoGpuConversion*);
