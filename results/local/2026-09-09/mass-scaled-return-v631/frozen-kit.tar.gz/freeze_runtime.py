"""Freeze only the demonstrated v631 native build's exact Python source."""

import hashlib
import json
import tarfile
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
BUILD = ROOT / "build/performance/gpu-scaled-zoh-v631"
MANIFEST_SHA = "b92df5cc06f0119e0958b85935334b82910967f580f0d02bab2bde8d39702e11"
GPU_SHA = "fb862f949b3e20b5d5bab1895717d384677b7c3eaef03c04752509ca75056fc5"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert __debug__
assert sha(BUILD / "manifest.json") == MANIFEST_SHA
assert sha(BUILD / "gpu-tests-a/report.json") == GPU_SHA
manifest = json.loads((BUILD / "manifest.json").read_bytes())
qualification = json.loads((BUILD / "gpu-tests-a/report.json").read_bytes())
assert manifest["complete"] and manifest["passed"]
assert qualification["complete"] and qualification["passed"]
archive = BUILD / "source.tar.gz"
assert sha(archive) == manifest["source_archive_sha256"]
host = KIT / "host"
host.mkdir()
members = {}
with tarfile.open(archive, "r|gz") as source:
    for member in source:
        if not member.isfile() or not member.name.startswith("src/spacepdhcg/"):
            continue
        payload = source.extractfile(member).read()
        expected = manifest["sources"][member.name]
        assert hashlib.sha256(payload).hexdigest() == expected
        target = host / member.name.removeprefix("src/")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        members[str(target.relative_to(host))] = expected
expected_members = {
    name.removeprefix("src/"): value
    for name, value in manifest["sources"].items()
    if name.startswith("src/spacepdhcg/")
}
assert members == expected_members
profile = json.loads((KIT / "profile-draft.json").read_bytes())
profile.update(
    scaled_zoh_supported=True,
    status="native_units_parity_and_memcheck_passed_mission_not_run",
    host_commit=manifest["base_commit"],
    source_head=manifest["base_commit"],
    library={k: manifest["outputs"]["library"][k] for k in ("path", "sha256")},
    native_manifest={
        "path": str((BUILD / "manifest.json").relative_to(ROOT)),
        "sha256": MANIFEST_SHA,
    },
    GPU_qualification=[
        {"path": str((BUILD / "gpu-tests-a/report.json").relative_to(ROOT)), "sha256": GPU_SHA}
    ],
)
profile["runtime_flags"]["SPACEPDHCG_GTOC12_CUDA_LIBRARY"] = profile["library"]["path"]
for name, data in (("host-index.json", members), ("profile.json", profile)):
    with (KIT / name).open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
print(
    json.dumps(
        {
            "host_files": len(members),
            "manifest_sha256": MANIFEST_SHA,
            "host_index_sha256": sha(KIT / "host-index.json"),
            "profile_sha256": sha(KIT / "profile.json"),
        },
        indent=2,
    )
)
