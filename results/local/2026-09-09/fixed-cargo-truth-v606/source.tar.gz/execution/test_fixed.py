"""Behavioral fixed-cargo, control-gating and fleet-provenance checks without native loads."""

from __future__ import annotations

import ctypes
import dataclasses
import math
import os
from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import patch

import common
import numpy as np
import pytest

common.activate_source()
from fixed_refine import FrozenLegRunner, refine_fixed, validate_prescription  # noqa: E402
from plan import make_plan, replacement_plan  # noqa: E402
from run import should_run_case  # noqa: E402

from spacepdhcg.gtoc12 import pipeline as p  # noqa: E402
from spacepdhcg.gtoc12.data import load_bonus_table, load_catalogue  # noqa: E402


@pytest.fixture(autouse=True)
def no_native():
    with patch.object(
        ctypes, "CDLL", side_effect=AssertionError("CPU tests must not load native libraries")
    ):
        yield


@pytest.fixture
def camp_plan():
    legs = (
        p.PlannedLeg(0, 1, 64328, 64828, 1, 1, "earth_out"),
        p.PlannedLeg(1, 2, 64828, 65028, 1, 1, "deploy_hop"),
        p.PlannedLeg(2, 2, 65028, 65628, 0, 1, "camp"),
        p.PlannedLeg(2, 1, 65628, 66628, 1, 1, "collect_hop"),
        p.PlannedLeg(1, 0, 66628, 67328, 1, 1, "earth_return"),
    )
    cargo = {1: 30.0, 2: 10.0}
    # Bad proxy deliberately does not prohibit a diagnostic physical solve.
    return p.RoutePlan(
        legs, {1: 64828, 2: 65028}, {1: 66628, 2: 65628}, cargo.copy(), 5000, 100
    ), cargo


class FakeRunner:
    def __init__(self, settings, *, burn=100, failure=None, exception=None, master=True):
        self.settings, self.burn = settings, burn
        self.failure, self.exception, self.master = failure, exception, master
        self.boundaries, self.closed, self.master_called = [], False, False

    def solve(self, leg, boundary, index):
        self.boundaries.append((leg, boundary))
        if index == self.exception:
            raise RuntimeError("synthetic native failure")
        certified = index != self.failure
        after = boundary.initial_mass - self.burn
        item = p.RefinedLeg(
            leg,
            SimpleNamespace(deterministic_id=1000 + index),
            SimpleNamespace(feasible=certified),
            None,
            None,
            certified,
            boundary.initial_mass,
            after,
        )
        return item, {
            "leg": index,
            "status": "converged" if certified else "failed",
            "certified": certified,
        }

    def certify_route(self, plan, refined):
        self.master_called = True
        return self.master

    @property
    def telemetry(self):
        return {"submitted": len(self.boundaries)}

    def close(self):
        self.closed = True


def invoke(plan, cargo, monkeypatch, **kwargs):
    monkeypatch.setattr(p, "body_state", lambda catalogue, body, epoch: (np.zeros(3), np.zeros(3)))
    settings = p.ScvxSettings(**common.read(common.ROOT / "preparation.json")["scvx_settings"])
    runner = FakeRunner(settings, **kwargs)
    result = refine_fixed(
        plan, None, cargo, settings=settings, runner_factory=lambda received: runner
    )
    return result, runner


def test_exact_cargo_not_maximum_mining_mass_and_camp_events_count_once(camp_plan, monkeypatch):
    plan, cargo = camp_plan
    before = deepcopy((plan.summary(), cargo))
    result, runner = invoke(plan, cargo, monkeypatch)
    assert result.certified and result.passes == 1
    assert len(runner.boundaries) == 4
    assert [boundary.initial_mass for _, boundary in runner.boundaries] == [3000, 2860, 2730, 2660]
    assert [boundary.minimum_final_mass for _, boundary in runner.boundaries] == [
        500,
        500,
        510,
        540,
    ]
    assert [(leg.departure_epoch, leg.arrival_epoch) for leg, _ in runner.boundaries] == [
        (64328, 64828),
        (64828, 65028),
        (65628, 66628),
        (66628, 67328),
    ]
    assert result.collected_mass == cargo == {1: 30.0, 2: 10.0}
    assert result.final_mass_kg == 2520.0
    assert (plan.summary(), cargo) == before
    assert runner.closed and runner.master_called


def test_rejected_proxy_can_only_be_probed_through_full_solver_path(camp_plan, monkeypatch):
    plan, cargo = camp_plan
    assert not plan.feasible
    result, runner = invoke(plan, cargo, monkeypatch)
    assert len(runner.boundaries) == 4 and runner.master_called
    assert result.certified


@pytest.mark.parametrize(
    "mode", ["leg_failure", "solver_exception", "mass_deficit", "master_failure"]
)
def test_failure_never_resizes_cargo_retimes_or_retries(camp_plan, monkeypatch, mode):
    plan, cargo = camp_plan
    original = deepcopy((plan.summary(), cargo))
    options = {
        "leg_failure": {"failure": 1},
        "solver_exception": {"exception": 1},
        "mass_deficit": {"burn": 650},
        "master_failure": {"master": False},
    }[mode]
    result, runner = invoke(plan, cargo, monkeypatch, **options)
    assert not result.certified and result.passes == 1
    assert result.collected_mass == cargo == original[1]
    assert plan.summary() == original[0]
    assert len(runner.boundaries) == (2 if mode in {"leg_failure", "solver_exception"} else 4)
    assert runner.closed and result.failures
    if mode == "mass_deficit":
        assert result.final_mass_kg == 320
        assert result.failures[-1]["status"] == "fixed_cargo_mass_deficit"
        assert result.failures[-1]["cargo_resized"] is False
        assert not runner.master_called


@pytest.mark.parametrize(
    "invalid", ["missing", "extra", "negative", "nan", "inf", "excess", "foreign", "mining_stay"]
)
def test_invalid_prescription_rejected_before_any_solver(camp_plan, invalid):
    plan, cargo = camp_plan
    cargo = dict(cargo)
    if invalid == "missing":
        del cargo[1]
    elif invalid == "extra":
        cargo[99] = 1.0
    elif invalid in {"negative", "nan", "inf", "excess"}:
        cargo[1] = {"negative": -1, "nan": math.nan, "inf": math.inf, "excess": 1000}[invalid]
    elif invalid == "foreign":
        plan = dataclasses.replace(plan, foreign_deploy_epochs={99: 64328})
    else:
        plan = dataclasses.replace(plan, collect_epochs={1: 64900, 2: 65628})
    with pytest.raises(ValueError):
        validate_prescription(plan, cargo)


def test_control_failure_blocks_only_its_paired_probe():
    cases = common.read(common.ROOT / "plan/plan.json")["cases"]
    control2, probe2, control7, probe7 = cases
    assert should_run_case(control2, {}) and should_run_case(control7, {})
    assert not should_run_case(probe2, {}) and not should_run_case(probe7, {})
    controls = {control2["id"]: False, control7["id"]: True}
    assert not should_run_case(probe2, controls)
    assert should_run_case(probe7, controls)


@pytest.fixture(scope="module")
def actual_inputs():
    os.environ["SPACEPDHCG_GTOC12_DATA"] = (
        "/home/angus/worktrees/spacepdhcg-release/benchmarks/gtoc12/data"
    )
    summaries, audit, solution = common.load_inputs()
    catalogue, bonus = load_catalogue(), load_bonus_table()
    assert catalogue.source_sha256 == common.DATA_SHA and bonus.source_sha256 == common.BONUS_SHA
    weights = {int(body): float(bonus.for_asteroid(int(body))) for body in catalogue.ids}
    return summaries, audit, solution, weights


def test_four_frozen_schedules_reproduce_exact_gpu_windows_and_weighted_opportunities(
    actual_inputs,
):
    summaries, audit, _, weights = actual_inputs
    fresh = make_plan(summaries, audit, weights)
    import json

    assert json.loads(json.dumps(fresh)) == common.read(common.ROOT / "plan/plan.json")
    assert len(fresh["cases"]) == 4 and fresh["maximum_leg_calls"] == 66
    controls = [case for case in fresh["cases"] if case["kind"] == "control"]
    probes = [case for case in fresh["cases"] if case["kind"] == "probe"]
    for control in controls:
        original = p.plan_from_route_summary(summaries[control["ship"]])
        assert control["plan"] == original.summary()
        assert control["prescribed_cargo_kg"] == {
            int(a): m for a, m in summaries[control["ship"]]["collected_mass_kg"].items()
        }
        assert control["raw_gain_kg"] == control["weighted_gain_kg"] == 0
    assert probes[0]["weighted_gain_kg"] == pytest.approx(6.236202514543038, abs=1e-7)
    assert probes[1]["weighted_gain_kg"] == pytest.approx(9.908764746603651, abs=1e-7)
    for probe in probes:
        assert probe["proxy_prediction"]["fleet_raw_shortfall_kg_estimate"] == 0
        assert not p.RoutePlan.from_summary(probe["plan"]).feasible


def test_tampered_saved_window_is_not_silently_regenerated(actual_inputs):
    summaries, _, _, _ = actual_inputs
    probe = deepcopy(
        common.read(common.ROOT / "reference/next-hypothesis.json")["candidate_probes"][0]
    )
    probe["ranking_estimate"]["incident_legs"][-1]["arrival"] += 1
    with pytest.raises(ValueError, match="saved GPU window"):
        replacement_plan(p.plan_from_route_summary(summaries[2]), probe)


@pytest.mark.parametrize("problem", ["control", "official", "independent", "raw", "weight", "nan"])
def test_no_promotion_without_passed_control_both_checkers_raw_floor_and_weighted_gain(problem):
    checked = {
        "ok": True,
        "independent": {"ok": True},
        "official": {"ok": True},
        "score_kg": 12820.0,
        "total_mass_kg": common.FLEET_RAW_FLOOR + 1,
    }
    control = True
    assert common.can_promote(checked, 12810.0, control)
    if problem == "control":
        control = False
    elif problem in {"official", "independent"}:
        checked[problem]["ok"] = False
    elif problem == "raw":
        checked["total_mass_kg"] = common.FLEET_RAW_FLOOR - 1
    elif problem == "weight":
        checked["score_kg"] = 12809.0
    else:
        checked["score_kg"] = math.nan
    assert not common.can_promote(checked, 12810.0, control)


def test_prescription_below_mining_maximum_is_not_increased(camp_plan, monkeypatch):
    plan, cargo = camp_plan
    cargo[1] = 1.0
    result, _ = invoke(plan, cargo, monkeypatch)
    assert result.collected_mass[1] == 1.0


def test_full_route_native_settings_match_successful_v595():
    preparation = common.read(common.ROOT / "preparation.json")
    previous = common.read(common.ROOT / "reference/v595-report.json")
    assert (
        dataclasses.asdict(p.ScvxSettings(**preparation["scvx_settings"]))
        == previous["scvx_settings"]
    )
    assert {
        name: row["sha256"] for name, row in preparation["native_libraries"].items()
    } == previous["native_sha256"]
    for name in ("pipeline.py", "gpu_scvx.py", "low_thrust.py", "verifier.py", "solution.py"):
        relative = f"src/spacepdhcg/gtoc12/{name}"
        old = common.ROOT / "reference/v595-python" / name
        assert common.sha(old) == previous["source_sha256"][relative]
        assert (
            old.read_bytes().replace(b"\r\n", b"\n")
            == (common.ROOT / "source" / relative).read_bytes()
        )


@pytest.mark.parametrize("outcome", ["passed", "native_failure", "certificate_failure"])
def test_real_scheduler_adapter_preserves_solver_and_certification_failure(
    camp_plan, monkeypatch, outcome
):
    plan, _ = camp_plan
    leg = plan.legs[0]
    boundary = p.LegBoundary(
        leg.departure_epoch,
        np.ones(3),
        np.zeros(3),
        leg.arrival_epoch,
        np.ones(3),
        np.zeros(3),
        3000,
    )
    settings = p.ScvxSettings(**common.read(common.ROOT / "preparation.json")["scvx_settings"])
    calls = []

    def solve(received, received_settings):
        assert received is boundary and received_settings is settings
        calls.append("native_boundary")
        if outcome == "native_failure":
            raise RuntimeError("simulated native failure retained by real adapter")
        return p.LegSolution(
            "converged",
            boundary,
            np.array([leg.departure_epoch, leg.arrival_epoch]),
            np.zeros((2, 3)),
            np.zeros((2, 7)),
            np.zeros(3),
            np.zeros(3),
            2900,
            100,
            0.2,
            3,
            2,
            0,
            0,
            0.02,
            history=[{"iteration": 3, "defect": 0}],
            solver_reports=[{"status": "solved"}],
            seed_backend="cuda",
            outer_loop_backend="cuda",
            convex_solver_backend="qoco",
        )

    def certify(solution):
        calls.append("independent_rollout_boundary")
        return p.LegCertificate(1e9 if outcome == "certificate_failure" else 0, 0, 2900, 1.0, 0, 0)

    monkeypatch.setattr(p, "solve_leg", solve)
    monkeypatch.setattr(p, "certify_leg", certify)
    runner = FrozenLegRunner(settings)
    try:
        refined, details = runner.solve(leg, boundary, 0)
        assert refined.certified == (outcome == "passed")
        assert runner.telemetry["submitted"] == runner.telemetry["completed"] == 1
        assert calls == (
            ["native_boundary"]
            if outcome == "native_failure"
            else ["native_boundary", "independent_rollout_boundary"]
        )
        if outcome == "native_failure":
            assert "simulated native failure" in details["diagnostic"]
        else:
            assert details["solution"]["history"] == [{"iteration": 3, "defect": 0}]
            assert details["solution"]["solver_reports"] == [{"status": "solved"}]
            assert details["certificate"]["final_mass_kg"] == 2900
    finally:
        runner.close()


def test_profile_sanitizes_experimental_flags_and_uses_one_pinned_host(tmp_path):
    from launch import recipe

    for name in ("local", "h100"):
        profile, environment = common.profile_environment(
            name,
            {
                "SPACEPDHCG_TEST_EXPERIMENT": "1",
                "QOCO_REPLAY_CAPTURE": "1",
                "LD_LIBRARY_PATH": "unrelated",
                "PATH": "/usr/bin",
            },
        )
        assert "SPACEPDHCG_TEST_EXPERIMENT" not in environment
        assert "QOCO_REPLAY_CAPTURE" not in environment
        assert environment["SPACEPDHCG_TEST_GTOC12_PARALLEL_DIRECTIONS"] == "0"
        assert environment["SPACEPDHCG_TEST_GTOC12_JOINT_BATCH"] == "0"
        assert environment["LD_LIBRARY_PATH"] == profile["LD_LIBRARY_PATH"]
        _, _, command = recipe(name, tmp_path / "fresh", 1800)
        assert command[command.index("--profile") + 1] == name
        assert command[0] == profile["python"]
        assert "--max-refinements" not in command  # Hard-coded overall bound cannot be expanded.


@pytest.mark.parametrize("invalid", ["parallel", "extra", "missing", "library_hash"])
def test_runtime_profile_refuses_unreviewed_flags_or_library_bytes(monkeypatch, invalid):
    _profile, environment = common.profile_environment("h100", {})
    if invalid == "parallel":
        environment["SPACEPDHCG_TEST_GTOC12_PARALLEL_DIRECTIONS"] = "1"
    elif invalid == "extra":
        environment["SPACEPDHCG_TEST_NEW_ALGORITHM"] = "1"
    elif invalid == "missing":
        del environment["SPACEPDHCG_QOCO_LIBRARY"]
    else:
        monkeypatch.setattr(common.Path, "is_file", lambda self: True)
        monkeypatch.setattr(common, "sha", lambda path: "wrong-hash")
    with pytest.raises(ValueError):
        common.validate_profile("h100", environment)


def test_h100_source_proof_is_scoped_to_unused_joint_and_disabled_parallel_kernel():
    profiles = common.read(common.ROOT / "profiles.json")
    profile = profiles["profiles"]["h100"]
    path = common.ROOT / profile["validation_reference"]
    assert common.sha(path) == profile["source_compatibility_report_sha256"]
    proof = common.read(path)
    assert proof["cpp_source_files_compared"] == 355
    assert proof["identical_source_files"] == 352
    assert proof["orbitweaver_exact_git_blobs_verified"]
    assert "not a new H100 test" in proof["scope"]
    assert (
        proof["h100_core_sha256"]
        == profile["native_libraries"]["SPACEPDHCG_GTOC12_CUDA_LIBRARY"]["sha256"]
    )


def test_native_call_observation_preserves_attempted_failure_and_success(tmp_path):
    from run import native_progress

    from spacepdhcg.gtoc12 import gpu_scvx

    boundary = SimpleNamespace(
        departure_epoch=1, arrival_epoch=2, initial_mass=3000, minimum_final_mass=500
    )
    result = SimpleNamespace(status="converged", iterations=3, accepted_iterations=2)
    report = {"native_solves_started": 0, "native_solves_completed": 0, "active_case": "control"}
    with patch.object(gpu_scvx, "solve_native", side_effect=[result, RuntimeError("native error")]):
        with native_progress(tmp_path, report):
            assert gpu_scvx.solve_native(boundary) is result
            with pytest.raises(RuntimeError):
                gpu_scvx.solve_native(boundary)
    import json

    rows = [json.loads(row) for row in (tmp_path / "native-solves.jsonl").read_text().splitlines()]
    assert report["native_solves_started"] == report["native_solves_completed"] == 2
    assert rows[0]["iterations"] == 3 and rows[0]["accepted_iterations"] == 2
    assert "native error" in rows[1]["error"]


@pytest.mark.parametrize("state", ["busy_lock", "compute_process", "timeout", "idle"])
def test_supervisor_never_overlaps_or_retries_and_retains_launch_evidence(
    tmp_path, monkeypatch, state
):
    import fcntl
    import subprocess

    import launch

    root = tmp_path / "kit"
    root.mkdir()
    (root / "source").mkdir()
    (root / "run.py").write_text("# synthetic child; no GPU or process launched by this test\n")
    lock_path = tmp_path / "shared.lock"
    lock_path.touch()
    monkeypatch.setattr(common, "ROOT", root)
    monkeypatch.setattr(common, "validate_ready", lambda: {})
    monkeypatch.setattr(common, "validate_profile", lambda name, environment: ({}, {}))
    profile = {"lock": str(lock_path)}
    monkeypatch.setattr(launch, "recipe", lambda *args: (profile, {}, ["synthetic-child"]))
    observations, children = [], []

    def observe(command, **kwargs):
        observations.append(command)
        if state == "timeout":
            raise subprocess.TimeoutExpired(command, 15)
        text = "999,other-job,100 MiB" if state == "compute_process" else ""
        return SimpleNamespace(stdout=text)

    class Child:
        pid = 12345

        def __init__(self, command, **kwargs):
            children.append(command)
            assert len(kwargs["pass_fds"]) == 1
            with lock_path.open("a+") as competing:
                with pytest.raises(BlockingIOError):
                    fcntl.flock(competing, fcntl.LOCK_EX | fcntl.LOCK_NB)

        def wait(self):
            return 0

    monkeypatch.setattr(launch.subprocess, "run", observe)
    monkeypatch.setattr(launch.subprocess, "Popen", Child)
    args = SimpleNamespace(profile="h100", output=root / "output", wall_seconds=1800, execute=True)
    with lock_path.open("a+") as other:
        if state == "busy_lock":
            fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if state == "idle":
            assert launch.main(args) == 0
        else:
            with pytest.raises((BlockingIOError, RuntimeError, subprocess.TimeoutExpired)):
                launch.main(args)
    evidence = common.read(root / "launch.json")
    assert evidence["launched"] == (state == "idle")
    assert len(children) == (1 if state == "idle" else 0)
    if state == "busy_lock":
        assert not observations
    if state != "idle":
        assert evidence["status"] == "refused_before_GPU_launch"
    # A repeated invocation cannot create another child, even after a no-GPU refusal.
    with pytest.raises(FileExistsError):
        launch.main(args)
