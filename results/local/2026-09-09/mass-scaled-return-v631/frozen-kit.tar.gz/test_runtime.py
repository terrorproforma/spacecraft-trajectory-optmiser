"""Emission/mass orchestration only: mock new return, no numerical trajectory call."""

from __future__ import annotations

import ctypes
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
PRIOR = KIT.parent / "fleet-budgeted-prefix-v630"


@pytest.fixture
def model(monkeypatch):
    def blocked(*args, **kwargs):
        raise AssertionError("No native call or trajectory propagation in orchestration tests")

    monkeypatch.setattr(ctypes, "CDLL", blocked)
    monkeypatch.syspath_prepend(str(KIT / "host"))
    monkeypatch.setattr(
        sys,
        "meta_path",
        [x for x in sys.meta_path if x.__class__.__module__ != "_editable_skbc_spacepdhcg"],
    )
    from spacepdhcg.gtoc12 import pipeline
    from spacepdhcg.gtoc12.low_thrust import ScvxSettings
    from spacepdhcg.gtoc12.search import RoutePlan

    monkeypatch.setattr(pipeline, "body_state", blocked)
    monkeypatch.setattr(pipeline, "earth_state", blocked)
    monkeypatch.setattr(pipeline, "asteroid_state", blocked)
    stub = SimpleNamespace(
        KIT=KIT,
        BASE=KIT / "inputs",
        PRIOR=PRIOR,
        read=lambda path: json.loads(Path(path).read_bytes()),
        sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
    )
    monkeypatch.setitem(sys.modules, "common", stub)
    spec = importlib.util.spec_from_file_location("v631_emission_test", KIT / "runtime.py")
    runtime = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime)
    plan = RoutePlan.from_summary(stub.read(KIT / "inputs/candidate-plan.json"))
    settings = ScvxSettings(**stub.read(KIT / "inputs/settings.json"))
    with np.load(KIT / "inputs/archived-return.npz", allow_pickle=False) as archive:
        seed = {key: archive[key].copy() for key in archive.files}
    return runtime, plan, settings, seed


def mock_return(model, *, certified=True, final_mass=1180.0):
    runtime, plan, settings, seed = model
    _, boundary = runtime.boundary_for(seed, settings, control=False)
    solution = SimpleNamespace(
        boundary=boundary,
        burn_arcs=lambda: [],
        arrival_vinf_km_s=np.array([0.1, -0.2, 0.3]),
    )
    return SimpleNamespace(
        planned=[leg for leg in plan.legs if leg.role != "camp"][-1],
        solution=solution,
        certified=certified,
        certificate=SimpleNamespace(final_mass_kg=final_mass) if certified else None,
        mock_only_not_a_physics_certificate=True,
    )


def test_saved_prefix_is_exact_certified_input_and_read_only(model):
    runtime, plan, _, _ = model
    prefix = runtime.load_prefix(plan)
    assert len(prefix) == 17
    assert all(item.known_saved_certificate for item in prefix)
    assert prefix[-1].certificate.final_mass_kg + plan.collected_mass[17126] == 1438.8883038351994
    with pytest.raises(ValueError):
        prefix[-1].solution.thrust_n.setflags(write=True)


def test_control_and_candidate_boundaries_preserve_rv_but_have_distinct_mass_gates(model):
    runtime, _, settings, seed = model
    _, control = runtime.boundary_for(seed, settings, control=True)
    generated, candidate = runtime.boundary_for(seed, settings, control=False)
    assert control.initial_mass == 1472.1728669809
    assert control.minimum_final_mass == 1171.4579055442
    assert candidate.initial_mass == 1438.8883038351994
    assert candidate.minimum_final_mass == 1177.2073921971253
    assert candidate.departure_epoch == control.departure_epoch == 69263.0
    np.testing.assert_array_equal(candidate.departure_velocity, seed["initial_state"][3:6])
    np.testing.assert_array_equal(candidate.arrival_velocity, generated.arrival_velocity)
    assert not np.array_equal(candidate.arrival_velocity, seed["arrival_spacecraft_velocity"])
    with pytest.raises(ValueError):
        candidate.departure_position.setflags(write=True)


@pytest.mark.parametrize("control", [True, False])
def test_final_scaled_seed_api_preserves_exact_archive_payload(model, control):
    runtime, _, settings, arrays = model
    from spacepdhcg.gtoc12 import trajectory_seed

    assert Path(trajectory_seed.__file__).resolve().is_relative_to(KIT / "host")
    _, boundary = runtime.boundary_for(arrays, settings, control=control)
    seed = trajectory_seed.ZohTrajectorySeed(
        arrays["node_epochs_mjd"],
        arrays["initial_state"],
        arrays["thrust_n"],
        arrays["source_sha256"].item(),
        target_initial_mass_kg=boundary.initial_mass,
    )
    seed.validate_for(boundary, settings, seed.node_epochs_mjd)
    assert seed.initial_state.tobytes() == arrays["initial_state"].tobytes()
    assert seed.thrust_n.tobytes() == arrays["thrust_n"].tobytes()
    assert seed.target_initial_mass_kg == boundary.initial_mass


def test_mock_return_emission_preserves_all_real_events_cargo_and_wait(model):
    runtime, plan, _, _ = model
    prefix = runtime.load_prefix(plan)
    original = plan.summary()
    from spacepdhcg.gtoc12.solution import parse_solution

    payload, audit = runtime.emit_candidate(plan, prefix, mock_return(model))
    # Only serialization is checked; the mock return has no physical certification.
    numbered = b"\n".join(b" ".join([b"1", *row.split()[1:]]) for row in payload.splitlines())
    ship = parse_solution(numbered.decode()).ships[0]
    assert len(ship.events) == 20
    wait_events = [e for e in ship.events if e.event_id == 59079]
    assert [e.epoch for e in wait_events] == [66728.0, 67733.0]
    assert len([e for e in audit["events"] if e["kind"] == "deploy"]) == 9
    assert len([e for e in audit["events"] if e["kind"] == "collect"]) == 9
    assert audit["draft_only_until_both_fleet_checks"]
    assert abs(ship.events[-1].after.mass - (1180.0 - 677.2073921971253)) < 1e-9
    assert plan.summary() == original


@pytest.mark.parametrize("final_mass", [1177.1, 500.0, float("nan")])
def test_mass_deficit_does_not_shrink_prescribed_cargo(model, final_mass):
    runtime, plan, _, _ = model
    cargo = dict(plan.collected_mass)
    with pytest.raises(ValueError, match="cargo cannot be reduced"):
        runtime.emit_candidate(
            plan, runtime.load_prefix(plan), mock_return(model, final_mass=final_mass)
        )
    assert plan.collected_mass == cargo


def test_failed_new_return_is_not_hidden_by_saved_prefix_certificates(model):
    runtime, plan, _, _ = model
    with pytest.raises(ValueError, match="own independent certificate"):
        runtime.emit_candidate(plan, runtime.load_prefix(plan), mock_return(model, certified=False))


def test_missing_saved_prefix_cannot_form_a_fleet_candidate(model):
    runtime, plan, _, _ = model
    with pytest.raises(ValueError, match="exact certified prefix"):
        runtime.emit_candidate(plan, runtime.load_prefix(plan)[:-1], mock_return(model))
