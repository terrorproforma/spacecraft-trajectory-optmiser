"""Exact first-leg seed, fixed mass handoffs, waits and route emission."""

from __future__ import annotations

import dataclasses
import importlib.util
import time

import common as C
import numpy as np

_spec = importlib.util.spec_from_file_location(
    "v629_validated_wait_helpers", C.CONTROL / "runtime.py"
)
_waits = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_waits)
next_mass, gpu_wait, wait_metrics = _waits.next_mass, _waits.gpu_wait, _waits.wait_metrics


class Coordinator:
    def __init__(
        self, plan, catalogue, case, directory, observer, deadline, *, wait_runner=gpu_wait
    ):
        self.plan, self.catalogue, self.case = plan, catalogue, case
        self.directory, self.observer, self.deadline = directory, observer, deadline
        self.flown = [leg for leg in plan.legs if leg.role != "camp"]
        self.items, self.boundaries, self.wait_results = {}, {}, {}
        self.wait_runner = wait_runner
        self.seed = np.load(C.KIT / "inputs" / case["first_seed"])
        (directory / "legs").mkdir()
        (directory / "waits").mkdir()

    def close(self):
        self.seed.close()

    def check_time(self):
        if time.perf_counter() >= self.deadline:
            raise TimeoutError("Finite batch deadline before operation")

    def boundary_factory(self, leg, generated, index):
        self.check_time()
        self.observer.index = index
        (self.directory / "legs" / f"{index:02d}").mkdir()
        effective = generated
        if index == 0:
            effective = dataclasses.replace(
                generated,
                departure_position=self.seed["initial_state"][:3],
                departure_velocity=self.seed["departure_body_velocity"],
                arrival_position=self.seed["arrival_position"],
                arrival_velocity=self.seed["arrival_velocity"],
            )
        self.boundaries[index] = effective
        C.write(
            self.directory / "legs" / f"{index:02d}" / "boundary.json",
            {
                "generated": generated,
                "effective": effective,
                "first_leg_archive_roundoff_only": index == 0,
                "production_representation_guard": True,
            },
        )
        return effective

    def seed_factory(self, leg, boundary, index):
        from spacepdhcg.gtoc12.trajectory_seed import ZohTrajectorySeed

        self.check_time()
        if index:
            previous = self.items[index - 1]
            assert previous.certified
            expected = next_mass(
                self.plan,
                self.flown[index - 1],
                leg,
                previous.certificate.final_mass_kg,
                self.plan.collected_mass,
            )
            assert boundary.initial_mass == expected
            C.write(
                self.directory / "legs" / f"{index:02d}" / "initialization.json",
                {
                    "kind": "native_cold",
                    "actual_initial_mass_kg": boundary.initial_mass,
                    "predecessor_certificate_sha256": C.sha(
                        self.directory / "legs" / f"{index - 1:02d}" / "leg-result.json"
                    ),
                },
            )
            return None
        assert boundary.initial_mass == self.seed["initial_state"][6] == 3000.0
        seed = ZohTrajectorySeed(
            self.seed["node_epochs_mjd"],
            self.seed["initial_state"],
            self.seed["thrust_n"],
            C.RESULT_SHA,
        )
        np.savez_compressed(
            self.directory / "legs/00/seed.npz",
            node_epochs_mjd=seed.node_epochs_mjd,
            initial_state=seed.initial_state,
            thrust_n=seed.thrust_n,
        )
        C.write(
            self.directory / "legs/00/initialization.json",
            {
                "kind": "archived_current_Earth_ZOH",
                "source_Result_sha256": C.RESULT_SHA,
                "source_seed_sha256": C.sha(C.KIT / "inputs" / self.case["first_seed"]),
                "actual_initial_mass_kg": boundary.initial_mass,
                "mesh_refinement": False,
            },
        )
        return seed

    def on_leg(self, index, item, record):
        from observe import save_solution

        from spacepdhcg.gtoc12 import pipeline as p

        directory = self.directory / "legs" / f"{index:02d}"
        if item.solution is not None:
            save_solution(item.solution, directory, "post-clamp")
        C.write(directory / "leg-result.json", record)
        self.items[index] = item
        if not item.certified:
            return
        assert (
            item.certificate is not None and item.mass_after_leg == item.certificate.final_mass_kg
        )
        for wait in self.case["waits"]:
            if wait["after_flight"] != index:
                continue
            self.check_time()
            assert wait["id"] not in self.wait_results
            self.wait_results[wait["id"]] = {"passed": False, "started": True}
            if wait["kind"] == "after_deployment":
                r, v = p.body_state(self.catalogue, wait["asteroid"], wait["t0"])
                initial = np.r_[r, v, item.certificate.final_mass_kg - 40.0]
                origin = (
                    "real emitted deployment-after event; certified arrival mass minus one miner"
                )
            else:
                captured = self.observer.raw[("flight", index)]
                assert captured["status"] == 0 and captured["rows"][0]["status"] == 0
                initial = captured["rows"][0]["final_state"].copy()
                assert initial[6] == item.certificate.final_mass_kg
                origin = "actual GPU flight final state into waiting coast; no body reset"
            target = np.concatenate(p.body_state(self.catalogue, wait["asteroid"], wait["tf"]))
            C.write(
                self.directory / "waits" / (wait["id"] + "-input.json"),
                {"wait": wait, "initial_state": initial, "target_rv": target, "origin": origin},
            )
            try:
                raw = self.wait_runner(wait, initial, self.observer)
                values = wait_metrics(raw, initial, target)
                self.wait_results[wait["id"]] = values
                C.write(self.directory / "waits" / (wait["id"] + "-result.json"), values)
                if not values["passed"]:
                    raise RuntimeError("Independent waiting coast rejected")
            except BaseException as error:
                C.write(
                    self.directory / "waits" / (wait["id"] + "-failure.json"),
                    {"error": repr(error)},
                )
                raise

    def all_waits_passed(self):
        return set(self.wait_results) == {w["id"] for w in self.case["waits"]} and all(
            r["passed"] for r in self.wait_results.values()
        )


def emit_route(route, coordinator):
    from spacepdhcg.gtoc12 import pipeline as p
    from spacepdhcg.gtoc12.solution import format_solution

    if not route.certified or not coordinator.all_waits_passed():
        raise ValueError("Flights, exact fixed cargo and all waits must certify")
    assert len(route.legs) == coordinator.case["native_flights"]
    assert route.collected_mass == coordinator.plan.collected_mass
    solution = p.emit_solution(route, coordinator.catalogue, ship_id=coordinator.case["ship"])
    ship = solution.ships[0]
    deploy, collect = {}, {}
    for event in ship.asteroid_visits():
        delta = event.after.mass - event.before.mass
        if delta < 0:
            assert abs(delta + 40.0) <= 1e-8
            assert event.event_id not in deploy
            deploy[event.event_id] = event.epoch
        else:
            assert event.event_id not in collect
            assert abs(delta - route.collected_mass[event.event_id]) <= 1e-8
            collect[event.event_id] = event.epoch
    assert deploy == route.plan.deploy_epochs and collect == route.plan.collect_epochs
    assert len(ship.events) == 2 + 2 * len(deploy)
    for wait in coordinator.case["waits"]:
        forbidden = wait["tf"] if wait["kind"] == "after_deployment" else wait["t0"]
        assert not any(e.epoch == forbidden and e.event_id == wait["asteroid"] for e in ship.events)
    assert abs(ship.events[-1].after.mass - route.final_mass_kg) <= 1e-8
    return format_solution(solution).encode()
