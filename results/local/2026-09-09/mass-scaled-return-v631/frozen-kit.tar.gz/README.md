This prepares one original-mass return control and one fixed-cargo candidate return. It has not run the mission solver yet. Both use the new CUDA mass-scaled ZOH initializer, with factor 1 for the control. A failed control blocks the candidate.

The exact source is ship 10 in the verified current fleet, Result SHA256 `765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da`. Its return from asteroid 17126 to Earth already uses MJD 69263–69713, the candidate's exact dates. The archived controls map to 226 nodes: 106 two-day burns and 119 coast intervals. No thrust interpolation or time change is needed. The source fleet passed both original checkers; that certificate does not certify the new candidate.

The archive starts at 1472.1728669809 kg. The candidate's saved certified prefix and final pickup produce 1438.8883038351994 kg. Scaling mass and thrust together by 0.9773908595299954 preserves the reference position/velocity dynamics analytically. The reference final mass becomes 1166.9174106318446 kg, below the prescribed 1177.2073921971253 kg by 10.289981565280641 kg. Optimization must recover that fuel; no cargo is removed to make the seed feasible. The arithmetic is an initialization diagnostic, not a newly propagated trajectory or an infeasibility proof.

The worker uploads the original archived initial state and physical thrust unchanged. CUDA performs the scaling and rollout. Archived coordinates differ from the saved generated body coordinates only within the existing 64-epsilon representation guard. Earth arrival velocity remains the body velocity from the saved boundary; the archive's spacecraft arrival velocity is a free-arrival result.

The maximum new numerical work is two native returns, 44 SCvx iterations each (40 main plus 4 polish), and two independent GPU flight certificates. There are no new prefix solves, wait propagations, Lambert searches, standalone seed inspections, retimings or alternate seed policies. The candidate reuses 17 saved flight certificates and one saved wait certificate from v630. Its draft emission preserves exact prescribed cargo/events and the other 22 fleet sections. A score improvement requires one unchanged independent CPU fleet checker and one official checker to pass on the same final Result bytes.

The supervisor uses the shared nonblocking GPU lock and verifies the compute-process inventory. It preserves the lock through owned-descendant cleanup, including SIGHUP, TERM and INT. Its hard deadline is 240 seconds, followed by 10 seconds for TERM and 30 seconds for KILL/reaping. The worker's 220-second checks are soft boundaries; the unchanged native inner setting is 900 seconds, bounded externally by the supervisor. There is one launch marker and no automatic retry.

`report.json` and `inputs/` contain parse-only preparation, while `external-evidence.json` binds the complete failed return and all saved prefix inputs/readbacks. `source/` preserves the old cold initializer and parser for diagnosis. `host/` contains the exact newly validated v631 build's Python source. `profile.json` binds that new core, QOCO, runtime and prior native unit/memcheck evidence. The earlier `profile-draft.json` is non-executable provenance. No production files were edited by this kit.

After root reviews the sealed `ready.json`, its single local command is:

```powershell
wsl -d Ubuntu-22.04 -- /home/angus/worktrees/spacepdhcg-literature-venv/bin/python -B /mnt/c/Users/Angus/Desktop/projects/spacecraft-trajectory-optmiser/build/performance/mission-initialization-v631/supervise.py
```

This preparation leaves the incumbent unchanged. A passing candidate remains subject to comparison with the latest verified fleet before publication; no viewer or default changes are made here.
