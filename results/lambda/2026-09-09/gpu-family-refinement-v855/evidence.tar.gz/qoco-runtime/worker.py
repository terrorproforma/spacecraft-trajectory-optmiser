from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,time,traceback
root=Path('/home/ubuntu/spacepdhcg-retry-conditioning-v686');repo=root/'repo'
report=dict(complete=False,success=False,stages=[])
py='/home/ubuntu/spacepdhcg/v1/.venv/bin/python';cmake='/home/ubuntu/spacepdhcg/v1/.venv/bin/cmake'
cudss='/home/ubuntu/spacepdhcg-recovery-v152/cudss'
env={k:v for k,v in os.environ.items() if not k.startswith(('SPACEPDHCG_TEST_','QOCO_REPLAY_'))}
env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONPATH=str(repo/'src'),LD_LIBRARY_PATH=str(root/'final')+':'+cudss+'/lib:/usr/local/cuda/lib64',SPACEPDHCG_GTOC12_DATA='/home/ubuntu/spacepdhcg/gtoc12/benchmarks/gtoc12/data')
def save(): (root/'report.json').write_text(json.dumps(report,indent=2))
def run(name,cmd,extra=None):
    started=time.perf_counter()
    with (root/(name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=repo,env=dict(env,**(extra or {})),stdout=log,stderr=subprocess.STDOUT,timeout=600)
    report['stages'].append(dict(name=name,returncode=r.returncode,seconds=time.perf_counter()-started,command=cmd));save();return r
save()
try:
    run('git-init',['git','init']).check_returncode();run('git-add',['git','add','-f','.']).check_returncode();run('git-freeze',['git','-c','user.name=GPU validation','-c','user.email=gpu-validation@localhost','commit','-m','Frozen GPU conditioning retry']).check_returncode()
    run('qoco-configure',[cmake,'-S',str(root/'qoco'),'-B',str(root/'qoco-build'),'-G','Ninja','-DQOCO_ALGEBRA_BACKEND=cuda','-DQOCO_BUILD_TYPE=Release','-DCMAKE_BUILD_TYPE=Release','-DBUILD_QOCO_DEMO=OFF','-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=90','-DCMAKE_CUDA_FLAGS=--default-stream per-thread -I'+cudss+'/include','-DCUDSS_LIB='+cudss+'/lib/libcudss.so']).check_returncode()
    run('qoco-build',[cmake,'--build',str(root/'qoco-build'),'-j3']).check_returncode()
    run('core-configure',[cmake,'-S',str(repo/'cpp'),'-B',str(root/'core-build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSPACEPDHCG_BUILD_CUDA=ON','-DSPACEPDHCG_BUILD_NATIVE_TESTS=OFF','-DBUILD_TESTING=ON','-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=90','-DSPACEPDHCG_PDHCG_SOURCE_ROOT=/home/ubuntu/spacepdhcg/v1/_upstream/pdhcg']).check_returncode()
    run('core-build',[cmake,'--build',str(root/'core-build'),'--target','spacepdhcg_cuda','-j3']).check_returncode()
    final=root/'final';final.mkdir()
    for path in [root/'qoco-build/libqoco.so',root/'core-build/cuda/libspacepdhcg_cuda.so']:shutil.copyfile(path,final/path.name)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in final.iterdir()};report['libraries']=hashes;save()
    source=(root/'return-run.py').read_text().replace('d2a885ee4c68ed800cf9b6ace353e591d0fdd32b4cb27afac4aa09b7b476b896',hashes['libspacepdhcg_cuda.so']).replace('5b1b1a047f9d5041f821b64490562a3d598f51b47fedb08d89cdae211728940a',hashes['libqoco.so'])
    (root/'return-pinned.py').write_text(source)
    env.update(SPACEPDHCG_GTOC12_CUDA_LIBRARY=str(final/'libspacepdhcg_cuda.so'),SPACEPDHCG_QOCO_LIBRARY=str(final/'libqoco.so'),SPACEPDHCG_GTOC12_GPU_TESTS='1')
    replay=root/'retry_snapshot_replay'
    run('replay-build',['/usr/local/cuda/bin/nvcc','--default-stream','per-thread','-arch=sm_90','-std=c++17',*['-I'+str(root/'qoco'/n) for n in ['include','algebra/cuda','lib/qdldl/include','lib/amd']],str(root/'retry_snapshot_replay.cu'),'-L'+str(final),'-lqoco','-o',str(replay)]).check_returncode()
    with Path('/home/ubuntu/.spacepdhcg-gpu.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        run('return-replay',[py,str(root/'return-pinned.py'),'--repo',str(repo),'--fixture',str(root/'return-fixture.json'),'--output',str(root/'return-output'),'--execute','--max-solves','6','--wall-seconds','600','--lock',str(root/'child.lock')],{'SPACEPDHCG_TEST_GTOC12_CONDITIONING_RETRY':'1'}).check_returncode()
        boot="import sys;sys.meta_path=[f for f in sys.meta_path if f.__class__.__module__!='_editable_skbc_spacepdhcg'];import pytest;sys.exit(pytest.main(sys.argv[1:]))"
        run('pytest-new',[py,'-c',boot,'-q','tests/test_gtoc12_gpu_conditioning_retry.py'])
        run('qp-replay',[str(replay),str(root/'input-qp.txt'),'12'],{'SPACEPDHCG_TEST_QOCO_IPM_GRAPH':'1'}).check_returncode()
    report['success']=True
except BaseException:report['error']=traceback.format_exc()
report['complete']=True;save()
