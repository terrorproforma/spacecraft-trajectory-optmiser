"""Copy reviewed ownership/checker helpers with finite two-return accounting."""

import hashlib
import json
from pathlib import Path

KIT = Path(__file__).resolve().parent
PRIOR = KIT.parent / "fleet-budgeted-prefix-v630"
lineage = {}
for name in ("common.py", "check_fleet.py", "observe.py", "process_guard.py", "supervise.py"):
    data = (PRIOR / name).read_bytes()
    text = data.decode()
    lineage[name] = {"source": str(PRIOR / name), "sha256": hashlib.sha256(data).hexdigest()}
    if name == "common.py":
        text = text.replace(
            'CONTROL = ROOT / "build/performance/seeded-route-v625"',
            'PRIOR = ROOT / "build/performance/fleet-budgeted-prefix-v630"\n'
            'CURRENT = ROOT / "results/local/2026-09-09/mass-budgeted-frontier-v629"',
        )
        text = text.replace(
            'assert sha(BASE / "Result.txt") == RESULT_SHA',
            'assert sha(CURRENT / "Result.txt") == RESULT_SHA',
        )
    elif name == "observe.py":
        text = text.replace(
            'counter = "seeded_calls_started" if index == 0 else "cold_calls_started"',
            'counter = "seeded_calls_started"',
        )
        text = text.replace("if index == 0:\n", "if True:\n")
        text = text.replace('== "cuda_zoh_replay"', '== "cuda_zoh_mass_scaled_replay"')
    elif name == "supervise.py":
        text = text.replace(
            "three prefixes, shared GPU lock, hard600-second wait",
            "two returns, shared GPU lock, hard240-second wait",
        )
        text = text.replace("hard_wait_seconds=600", "hard_wait_seconds=240")
        text = text.replace('"hard_wait_seconds": 600', '"hard_wait_seconds": 240')
        text = text.replace("child.wait(timeout=600)", "child.wait(timeout=240)")
        text = text.replace(
            'terminal["native_solves_started"] <= 50 and terminal["native_iterations"] <= 2200',
            'terminal["native_solves_started"] <= 2 and terminal["native_iterations"] <= 88',
        )
        text = text.replace(
            'terminal["flight_certificate_calls"] <= 50 and terminal["wait_certificate_calls"] <= 3',
            'terminal["flight_certificate_calls"] <= 2 and terminal["wait_certificate_calls"] == 0',
        )
        text = text.replace(
            'assert terminal["fleet_selection_calls"] <= 1',
            'assert terminal["standalone_inspection_calls"] == 0',
        )
        text = text.replace(
            'terminal["seeded_calls_started"] <= 3 and terminal["cold_calls_started"] <= 47',
            'terminal["seeded_calls_started"] <= 2 and terminal["cold_calls_started"] == 0',
        )
    with (KIT / name).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(text)
with (KIT / "harness-lineage.json").open("x") as stream:
    json.dump(lineage, stream, indent=2)
    stream.write("\n")
