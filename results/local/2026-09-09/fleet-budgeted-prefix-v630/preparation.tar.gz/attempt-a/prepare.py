"""Saved plans + Result parsing only; no new geometry, propagation or optimization."""
from __future__ import annotations

import ctypes
import dataclasses
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import tarfile

import numpy as np

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
BASE = ROOT / "results/local/2026-09-09/mass-budgeted-frontier-v629"
POOL = ROOT / "results/lambda/2026-09-09/gpu-collect-reuse-v806"
AUDIT = ROOT / "build/performance/frontier-opportunities-v630"
RESULT_SHA = "765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da"
SELECTED = (22, 10, 19)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, data):
    with Path(path).open("x") as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def extract_seed(ship, settings, target):
    launch, first = ship.launch, ship.asteroid_visits()[0]
    duration = first.epoch - launch.epoch
    nodes = np.arange(math.floor(duration / settings.node_days + 1e-9) + 1) * settings.node_days
    if duration - nodes[-1] > 1e-9:
        nodes = np.append(nodes, duration)
    epochs = launch.epoch + nodes
    thrust = np.zeros((len(nodes), 3))
    used = np.zeros(len(nodes) - 1, dtype=bool)
    arcs = []
    for arc in ship.burns:
        if arc.start >= first.epoch or arc.end <= launch.epoch:
            continue
        assert launch.epoch <= arc.start < arc.end <= first.epoch
        values = np.asarray([x.thrust for x in arc.interior])
        assert len(values) and np.all(values == values[0])
        left, right = np.flatnonzero(epochs == arc.start), np.flatnonzero(epochs == arc.end)
        assert len(left) == len(right) == 1 and right[0] > left[0]
        assert not used[left[0]:right[0]].any()
        thrust[left[0]:right[0]] = values[0]
        used[left[0]:right[0]] = True
        arcs.append({"t0": arc.start, "tf": arc.end, "thrust_n": values[0].tolist()})
    initial = np.r_[launch.after.position, launch.after.velocity, launch.after.mass]
    assert np.array_equal(launch.before.position, launch.after.position)
    np.savez_compressed(target, initial_state=initial, node_epochs_mjd=epochs, thrust_n=thrust,
                        departure_body_velocity=launch.before.velocity,
                        arrival_position=first.before.position, arrival_velocity=first.before.velocity)
    return {"source_Result_sha256": RESULT_SHA, "first_asteroid": first.event_id,
            "t0": launch.epoch, "tf": first.epoch, "nodes": len(nodes),
            "initial_mass_kg": float(initial[6]), "nonzero_intervals": int(used.sum()),
            "burns": arcs, "seed_sha256": sha(target.read_bytes()),
            "mapping": "Exact current Result ZOH controls; no resampling or interpolation"}


def main():
    if not __debug__ or os.environ.get("CUDA_VISIBLE_DEVICES") != "":
        raise RuntimeError("CPU-only preparation requires assertions and CUDA_VISIBLE_DEVICES empty")
    def blocked(*args, **kwargs):
        raise AssertionError("no native library in CPU preparation")
    ctypes.CDLL = blocked
    sys.path.insert(0, str(ROOT / "src"))
    from spacepdhcg.gtoc12.bundles import ClusterPricingSettings, refine_candidates
    from spacepdhcg.gtoc12.fixed_refinement import validate_prescription
    from spacepdhcg.gtoc12.low_thrust import ScvxSettings
    from spacepdhcg.gtoc12.refinement_admission import FixedCargoRequest, FleetBudgetContext
    from spacepdhcg.gtoc12.search import RoutePlan
    from spacepdhcg.gtoc12.solution import Solution

    output = KIT / "inputs"
    output.mkdir()
    result = (BASE / "Result.txt").read_bytes()
    assert sha(result) == RESULT_SHA
    binding = read(BASE / "checker-binding.json")
    package = read(POOL / "sha256.json")
    manifest = read(POOL / "local-files.json")
    assert sha((POOL / "local-files.json").read_bytes()) == package["local-files.json"]
    assert sha((POOL / "local.tar.gz").read_bytes()) == package["local.tar.gz"]
    wanted = {f"v802/ship-{n:02d}/plans.json" for n in SELECTED} | {"runtime/bonus_coefficients.txt"}
    saved = {}
    with tarfile.open(POOL / "local.tar.gz", "r|gz") as archive:
        for member in archive:
            if member.name in wanted:
                data = archive.extractfile(member).read()
                assert {"bytes": len(data), "sha256": sha(data)} == manifest[member.name]
                saved[member.name] = data
                if set(saved) == wanted:
                    break
    assert set(saved) == wanted
    bonus_data = saved["runtime/bonus_coefficients.txt"]
    assert sha(bonus_data) == "e8a3795e599556ed5b66713ab1fa176de93ef37f93cb2a4a87d561539b1caa21"
    weights = {i + 1: float(line.split()[0]) for i, line in enumerate(bonus_data.splitlines())}
    context = FleetBudgetContext.from_verified_result(result, independent=binding["independent"],
                                                       official=binding["official"], weights=weights)
    (output / "Result.txt").write_bytes(result)
    (output / "bonus_coefficients.txt").write_bytes(bonus_data)
    (output / "checker-binding.json").write_bytes((BASE / "checker-binding.json").read_bytes())
    prior = read(ROOT / "build/performance/mass-budgeted-frontier-v629/batch-protocol.json")
    settings = ScvxSettings(**prior["settings"])
    assert settings.max_iterations == 40 and settings.polish_iterations == 4
    ships = {s.ship_id: s for s in Solution.read(output / "Result.txt").ships}
    opportunities = read(AUDIT / "positive-requests.json")
    candidates, mapping = [], {}
    for number in SELECTED:
        identifier = f"local-v802-ship{number:02d}-rank0000"
        member = f"v802/ship-{number:02d}/plans.json"
        raw = json.loads(saved[member])[0]
        audited = next(x for x in opportunities if identifier in x["aliases"])
        canonical = json.dumps(raw, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        assert sha(canonical) == audited["canonical_plan_sha256"]
        route = RoutePlan.from_summary(raw)
        request = FixedCargoRequest.from_summary(route.summary())
        assert request.sha256 == audited["request_sha256"]
        validate_prescription(route, route.collected_mass)
        budget = context.replacement(number, request)
        assert not budget.blocker
        assert abs(budget.raw_gain_kg - audited["raw_delta_kg"]) < 1e-8
        assert abs(budget.objective_gain_kg - audited["weighted_delta_kg"]) < 1e-8
        # This is the same production selector used by price_cluster's replacement mode.
        first = route.legs[0]
        keys = {(first.to_id, first.departure_epoch, first.tof_days)}
        admitted = refine_candidates([route], keys, ClusterPricingSettings(ships=1, refine_top=1),
                                    fleet_context=context, replacement_ship=number)
        assert admitted == [route]
        seed_name = f"ship-{number:02d}-earth-seed.npz"
        seed = extract_seed(ships[number], settings, output / seed_name)
        assert [first.to_id, first.departure_epoch, first.arrival_epoch] == [seed["first_asteroid"], seed["t0"], seed["tf"]]
        mapping[number] = seed
        flown = [x for x in route.legs if x.role != "camp"]
        waits = []
        for index, (left, right) in enumerate(zip(flown, flown[1:])):
            assert left.to_id == right.from_id and left.arrival_epoch <= right.departure_epoch
            if left.arrival_epoch < right.departure_epoch:
                deployed = route.deploy_epochs.get(left.to_id) == left.arrival_epoch
                collected = route.collect_epochs.get(left.to_id) == right.departure_epoch
                assert deployed or collected
                waits.append({"id": f"wait-{index:02d}", "after_flight": index, "next_flight": index + 1,
                              "asteroid": left.to_id, "t0": left.arrival_epoch, "tf": right.departure_epoch,
                              "kind": "after_deployment" if deployed else "before_collection"})
        name = identifier + ".json"
        (output / name).write_bytes(canonical + b"\n")
        candidates.append({"id": identifier, "ship": number, "rank": 0,
                           "input_file": name, "request_sha256": request.sha256,
                           "input_sha256": sha((output / name).read_bytes()),
                           "source_archive": str((POOL / "local.tar.gz").relative_to(ROOT)),
                           "source_member": member, "source_member_sha256": manifest[member]["sha256"],
                           "canonical_plan_sha256": sha(canonical), "first_seed": seed_name,
                           "native_flights": len(flown), "waits": waits,
                           "asteroids": list(route.asteroids), "miners": len(route.deploy_epochs),
                           "raw_delta_kg": budget.raw_gain_kg, "weighted_delta_kg": budget.objective_gain_kg,
                           "production_admission": dataclasses.asdict(budget),
                           "historical_failures": audited["historically_failed_flight_prefix_matches"],
                           "new_geometry": False, "unattempted_under_corrected_endpoint_core": True})
    for i, a in enumerate(candidates):
        for b in candidates[i + 1:]:
            assert not set(a["asteroids"]) & set(b["asteroids"])
    raw_delta = sum(x["raw_delta_kg"] for x in candidates)
    weighted_delta = sum(x["weighted_delta_kg"] for x in candidates)
    flights = sum(x["native_flights"] for x in candidates)
    protocol = {"stage": "inputs_prepared_runtime_pin_pending_no_launch",
                "hypothesis": "Exercise fleet-budget-aware fixed-cargo production admission on three historically failed prefixes using corrected endpoint merit; one representative per prefix, not a new geometry search",
                "baseline_Result_sha256": RESULT_SHA, "baseline_raw_kg": context.raw_kg,
                "baseline_weighted_kg": context.objective_kg, "score_kind": context.score_kind,
                "settings": dataclasses.asdict(settings), "candidates": candidates,
                "prescribed_all_pass_raw_kg": context.raw_kg + raw_delta,
                "prescribed_all_pass_weighted_kg": context.objective_kg + weighted_delta,
                "max_whole_routes": 3, "max_native_leg_calls": flights,
                "max_outer_iterations": 44 * flights, "max_flight_certificates": flights,
                "max_wait_certificates": sum(len(x["waits"]) for x in candidates),
                "max_first_leg_seeded_calls": 3, "max_remaining_native_cold_calls": flights - 3,
                "max_final_original_fullfleet_check_pairs": 1, "max_candidate_combinations": 8,
                "future_hard_worker_seconds": 600, "TERM_grace_seconds": 10, "KILL_reap_seconds": 30,
                "retry_or_shrink_or_retime": False, "runtime_profile": "PENDING_ROOT_VALIDATED_EPHEMERIS_CORE_AND_HOST",
                "work": {"native": 0, "propagation": 0, "geometry": 0, "Lambert": 0,
                         "forward_proxy": 0, "saved_prescriptions_validated": 3, "Earth_seed_ZOH_mappings": 3},
                "input_sources": {str((BASE / "checker-binding.json").relative_to(ROOT)): sha((BASE / "checker-binding.json").read_bytes()),
                                  str((POOL / "local-files.json").relative_to(ROOT)): package["local-files.json"],
                                  str((POOL / "local.tar.gz").relative_to(ROOT)): package["local.tar.gz"],
                                  str((AUDIT / "index.json").relative_to(ROOT)): sha((AUDIT / "index.json").read_bytes())}}
    write(output / "earth-seed-mapping.json", mapping)
    write(KIT / "protocol.json", protocol)
    write(KIT / "input-index.json", {p.name: {"sha256": sha(p.read_bytes()), "bytes": p.stat().st_size} for p in sorted(output.iterdir())})
    print(json.dumps({"stage": protocol["stage"], "flights": flights,
                      "waits": protocol["max_wait_certificates"], "weighted_delta": weighted_delta,
                      "raw_delta": raw_delta, "protocol_sha256": sha((KIT / "protocol.json").read_bytes())}))


if __name__ == "__main__":
    main()
