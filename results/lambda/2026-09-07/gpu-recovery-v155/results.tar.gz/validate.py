from pathlib import Path
import os,subprocess,json,time,fcntl,hashlib
root=Path('/home/ubuntu/spacepdhcg-recovery-v155');repo=root/'repo';base=root/'final';staged=Path('/home/ubuntu/spacepdhcg-recovery-v152')
out=root/'validation';out.mkdir(exist_ok=False)
env=dict(os.environ,LD_LIBRARY_PATH=f'{base}:{staged}/cudss/lib:/usr/local/cuda/lib64',SPACEPDHCG_QOCO_LIBRARY=str(base/'libqoco.so'),SPACEPDHCG_G4_EXECUTOR=str(base/'device_scvx_integration_test'),PYTHONPATH=str(repo/'src'))
report=dict(commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),started=time.time(),tests=[],recovery=[])
def run(name,args,timeout=180):
 start=time.monotonic()
 try:
  with (out/f'{name}.log').open('w') as log,(out/f'{name}.err').open('w') as err:r=subprocess.run(args,env=env,cwd=repo,stdout=log,stderr=err,timeout=timeout)
  rc=r.returncode
 except subprocess.TimeoutExpired:rc=124
 result=dict(name=name,command=args,returncode=rc,wall_seconds=time.monotonic()-start)
 return result
def save(): (out/'report.json').write_text(json.dumps(report,indent=2))
try:
 with open('/home/ubuntu/.spacepdhcg-gpu.lock','w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
  assert not gpu,gpu
  report['hardware']=subprocess.check_output(['nvidia-smi','-q'],text=True)
  result=run('division-build',['/usr/local/cuda/bin/nvcc','-arch=sm_90','-I',str(staged/'qoco/include'),str(repo/'cpp/cuda/tests/qoco_safe_division_test.cu'),'-o',str(out/'division-test')]);report['tests'].append(result);assert result['returncode']==0
  for name,args in [('division',[str(out/'division-test')]),('audit',[str(base/'qoco_gpu_audit_test')]),('conversion',[str(base/'qoco_gpu_conversion_test')])]+[(f'native-{ruiz}-{mode}-{origin}',[str(base/'native_qoco_conversion_test'),str(ruiz),mode,origin]) for ruiz in [0,3] for mode in ['cpu-oracle','device-validation'] for origin in ['original','origin']]:
   result=run(name,args);report['tests'].append(result);save();print(json.dumps(result),flush=True)
  for i in range(6):
   manifest=staged/f'cases/{i}.json';coordinate=json.loads(manifest.read_text())['coordinate'];hashes=json.loads((staged/f'cases/{i}-command.json').read_text())[-3:]
   result=run(f'recovery-{i}',[str(base/'device_scvx_integration_test'),'--g4-recovery',str(manifest),*hashes,'5'])
   records=[json.loads(line) for line in (out/f'recovery-{i}.log').read_text().splitlines() if any(line.startswith('{"case":"'+name+'"') for name in ['g4_sample','production_outer','gpu_recovery_profile','gpu_recovery_failure'])]
   result.update(coordinate=coordinate,records=records);report['recovery'].append(result);save();print(json.dumps(result),flush=True)
  result=run('pytest-recovery-session',['/home/ubuntu/spacepdhcg/v1/.venv/bin/python','-m','pytest','tests/test_g4_recovery_gpu.py','tests/test_g4_ipm_session_gpu.py','-q']);report['tests'].append(result)
 report['completed']=True
except Exception as error:report['completed']=False;report['error']=repr(error)
report['ended']=time.time();report['files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='report.json'};save()
