from pathlib import Path
import subprocess,shutil,json,os,sys,hashlib,time,fcntl
root=Path('/home/ubuntu/spacepdhcg-outer-v156');repo=root/'repo';out=root/'validation';out.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'scripts/gpu'))
from prepare_qoco_outer_graph import prepare
shutil.copytree('/home/ubuntu/spacepdhcg-recovery-v152/qoco',root/'source')
patches=prepare(root/'source');runtime=Path('/home/ubuntu/spacepdhcg-recovery-v152/cudss')
cmake='/home/ubuntu/spacepdhcg/v1/.venv/bin/cmake'
env=dict(os.environ,SPACEPDHCG_TEST_QOCO_IPM_GRAPH='1',LD_LIBRARY_PATH=str(root/'build')+':'+str(runtime/'lib')+':/usr/local/cuda/lib64')
commands=[('configure',[cmake,'-S',str(root/'source'),'-B',str(root/'build'),'-G','Ninja','-DQOCO_ALGEBRA_BACKEND=cuda','-DQOCO_BUILD_TYPE=Release','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=90','-DCMAKE_CUDA_FLAGS=--default-stream per-thread -I'+str(runtime/'include'),'-DCUDSS_LIB='+str(runtime/'lib/libcudss.so'),'-DCMAKE_C_FLAGS=-Werror=implicit-function-declaration','-DBUILD_QOCO_DEMO=OFF']),('build',[cmake,'--build',str(root/'build'),'--target','qoco','-j','3'])]
for name in ['qoco_ipm_replay_probe','qoco_outer_graph_probe','qoco_outer_numeric_probe']:
 commands.append((name+'-build',['/usr/local/cuda/bin/nvcc','--default-stream','per-thread','-arch=sm_90','-std=c++17',*['-I'+str(root/'source'/n) for n in ['include','algebra/cuda','lib/qdldl/include','lib/amd']],str(repo/'cpp/cuda/tests'/(name+'.cu')),'-L'+str(root/'build'),'-lqoco','-o',str(out/name)]))
 commands.append((name,[str(out/name)]))
report=dict(patches=patches,started=time.time(),stages=[])
try:
 with open('/home/ubuntu/.spacepdhcg-gpu.lock','w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
  for name,command in commands:
   started=time.time()
   with (out/(name+'.log')).open('w') as log,(out/(name+'.err')).open('w') as err:r=subprocess.run(command,env=env,stdout=log,stderr=err,timeout=180)
   report['stages'].append(dict(name=name,command=command,returncode=r.returncode,seconds=time.time()-started));(out/'report.json').write_text(json.dumps(report,indent=2));r.check_returncode()
 report['completed']=True;report['runtime_sha256']=hashlib.sha256((root/'build/libqoco.so').read_bytes()).hexdigest()
except Exception as e:report['completed']=False;report['error']=repr(e)
report['ended']=time.time();(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
