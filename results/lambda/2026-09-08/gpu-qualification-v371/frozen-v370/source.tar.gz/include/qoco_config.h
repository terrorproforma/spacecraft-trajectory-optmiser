#ifndef QOCO_CONFIG_H
#define QOCO_CONFIG_H

// Version Macros
#define QOCO_VERSION_MAJOR 0
#define QOCO_VERSION_MINOR 3
#define QOCO_VERSION_PATCH 2
#define QOCO_VERSION "0.3.2"

// OS Macros
#define IS_LINUX
/* #undef IS_MACOS */
/* #undef IS_WINDOWS */

/* #undef QOCO_SINGLE_PRECISION */
/* #undef QOCO_LONG_DOUBLE_PRECISION */

#endif // #ifndef QOCO_CONFIG_H
