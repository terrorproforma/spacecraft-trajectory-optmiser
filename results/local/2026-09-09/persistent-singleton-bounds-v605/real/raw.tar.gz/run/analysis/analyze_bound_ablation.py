#!/usr/bin/env python3
"""CPU-only analysis of immutable v605 logs; never changes acceptance gates.

The counterfactual deliberately assigns multipliers without bound contact. It is
not a valid reconstruction policy or a proposed solver change. Its purpose is to
show whether dropping the guard alone could resolve the observed failures.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from fractions import Fraction
from pathlib import Path

import numpy as np


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def peak(values):
    values = np.asarray(values, dtype=np.longdouble)
    if not values.size:
        return {"absolute": 0.0, "index": None, "value": 0.0}
    index = int(np.argmax(np.abs(values)))
    return {"absolute": float(abs(values[index])), "index": index, "value": float(values[index])}


def read_record(path: Path, expected_hash: str):
    lines = path.read_text().splitlines()
    metadata = [json.loads(line.removeprefix("PERSISTENT_REPLAY_META "))
                for line in lines if line.startswith("PERSISTENT_REPLAY_META ")]
    records = [json.loads(line.removeprefix("PERSISTENT_REPLAY "))
               for line in lines if line.startswith("PERSISTENT_REPLAY ")]
    assert len(metadata) == len(records) == 1
    assert metadata[0]["input_sha256"] == expected_hash
    assert metadata[0]["coordinate_system"] == "original"
    return metadata[0], records[0]


def singleton_bounds(problem):
    """Derive bounds independently with exact rational arithmetic on FP64 data."""
    matrix = problem["G"].tocsc()
    rows = [[] for _ in range(problem["l"])]
    for column in range(problem["n"]):
        for entry in range(matrix.indptr[column], matrix.indptr[column + 1]):
            row, coefficient = int(matrix.indices[entry]), float(matrix.data[entry])
            if row < problem["l"] and coefficient != 0.0:
                rows[row].append((column, coefficient))
    lower = np.full(problem["n"], -np.inf, dtype=np.float64)
    upper = np.full(problem["n"], np.inf, dtype=np.float64)
    lower_owner = np.full(problem["n"], -1, dtype=int)
    upper_owner = np.full(problem["n"], -1, dtype=int)
    folded = {}
    for row, entries in enumerate(rows):
        if len(entries) != 1:
            continue
        variable, coefficient = entries[0]
        exact = Fraction(float(problem["h"][row])) / Fraction(coefficient)
        try:
            bound = float(exact)
        except OverflowError:
            continue
        if not np.isfinite(bound) or Fraction(bound) != exact:
            continue
        folded[row] = (variable, coefficient, bound)
        limits, owners = ((upper, upper_owner) if coefficient > 0
                          else (lower, lower_owner))
        tighter = bound < limits[variable] if coefficient > 0 else bound > limits[variable]
        owner = int(owners[variable])
        if tighter or (bound == limits[variable]
                       and (owner < 0 or abs(coefficient) > abs(folded[owner][1]))):
            limits[variable], owners[variable] = bound, row
    assert np.all(lower <= upper)
    return folded, lower, upper, lower_owner, upper_owner


def analyze_case(root, label, auditor):
    source = root / "inputs" / f"{label}.txt"
    source_hash = digest(source)
    problem = auditor.load_snapshot(source)
    assert problem["shift"] == 0, "this evidence analysis intentionally covers the unshifted v605 captures"
    folded, lower, upper, lower_owner, upper_owner = singleton_bounds(problem)
    indices = np.asarray(sorted(folded), dtype=int)
    variants = {}
    for variant in ("generic", "folded"):
        log = root / f"{label}-{variant}.log"
        metadata, record = read_record(log, source_hash)
        actual = auditor.audit(problem, record, backend="persistent", coordinates="original")
        x = np.asarray(record["x"], dtype=np.float64).astype(np.longdouble)
        slack = problem["h"] - problem["G"] @ x
        bounds_violation = np.maximum(np.longdouble(0), np.maximum(lower.astype(np.longdouble) - x,
                                                                  x - upper.astype(np.longdouble)))
        variants[variant] = {
            "log_sha256": digest(log),
            "native_natural_residual": record["native_natural_residual"],
            "iterations": record["iterations"],
            "termination": record["termination"],
            "original_equation_audit": actual,
            "original_singleton_violation": float(np.max(np.maximum(-slack[indices], 0), initial=0)),
            "box_violation": peak(bounds_violation),
        }
        if variant != "folded":
            continue
        assert metadata["folded_rows"] == len(folded)
        assert all(abs(entry[1]) == 1.0 for entry in folded.values()), "v605 exact singleton coefficient inventory changed"
        local = np.asarray(record["x_solver"], dtype=np.float64)
        assert np.array_equal(local, np.asarray(record["x"], dtype=np.float64))
        y = np.asarray(record["y"], dtype=np.float64).astype(np.longdouble)
        z = np.asarray(record["z"], dtype=np.float64).astype(np.longdouble)
        z[indices] = 0
        normal = -(problem["P"] @ x + problem["c"] + problem["A"].T @ y + problem["G"].T @ z)
        counterfactual_z = z.astype(np.float64)
        off_contact, one_ulp, maximum_distance = 0, 0, np.longdouble(0)
        for variable, value in enumerate(normal):
            owner = int(upper_owner[variable] if value > 0 else lower_owner[variable] if value < 0 else -1)
            if owner < 0:
                continue
            _, coefficient, bound = folded[owner]
            if local[variable] != bound:
                off_contact += 1
                one_ulp += int(local[variable] in (np.nextafter(bound, -np.inf), np.nextafter(bound, np.inf)))
                maximum_distance = max(maximum_distance, abs(np.longdouble(local[variable]) - bound))
            counterfactual_z[owner] = float(value / coefficient)
        assert np.all(np.isfinite(counterfactual_z))
        assert off_contact == record["off_contact_bound_normals"]
        assert one_ulp == record["off_contact_one_ulp_normals"]
        counterfactual = dict(record, z=counterfactual_z.tolist())
        counterfactual_audit = auditor.audit(problem, counterfactual,
                                            backend="persistent", coordinates="original")
        variants[variant].update({
            "exact_folded_rows": len(folded),
            "nonnegative_rows": problem["l"],
            "native_scalar_rows": metadata["native_scalar_rows"],
            "bounded_variables": int(np.count_nonzero(np.isfinite(lower) | np.isfinite(upper))),
            "off_contact_normals": off_contact,
            "one_ulp_off_contact_normals": one_ulp,
            "max_off_contact_distance": float(maximum_distance),
            "normal_without_folded_duals": peak(normal),
            "unsupported_contact_counterfactual": {
                "scope": "invalid-support diagnostic only; multipliers assigned without bound contact; primal unchanged; never an accepted solution",
                "original_equation_audit": counterfactual_audit,
                "max_folded_complementarity": float(np.max(abs(slack[indices] * counterfactual_z[indices]), initial=0)),
            },
        })
    original = variants["generic"]["original_equation_audit"]
    changed = variants["folded"]["original_equation_audit"]
    return {
        "input_sha256": source_hash,
        "variants": variants,
        "folded_to_generic_primal_defect_ratio": changed["primal_absolute"] / original["primal_absolute"],
        "folded_to_generic_primal_cone_violation_ratio": changed["primal_cone_violation"] / original["primal_cone_violation"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    auditor_path = root / "audit_persistent_snapshot.py"
    spec = importlib.util.spec_from_file_location("frozen_v605_original_equation_auditor", auditor_path)
    auditor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auditor)
    report = {
        "scope": "CPU-only independent reading of completed v605 evidence; no new solve or acceptance-policy change",
        "script_sha256": digest(Path(__file__)),
        "frozen_auditor_sha256": digest(auditor_path),
        "run_report_sha256": digest(root / "report.json"),
        "longdouble_mantissa_bits": int(np.finfo(np.longdouble).nmant),
        "cases": {label: analyze_case(root, label, auditor) for label in ("conditioning", "difficult")},
        "finding": "Folded primal feasibility is worse independently of dual reconstruction; zero box/singleton violations confirm bound satisfaction; off-contact cases are not one-ULP effects; removing contact guards does not recover a qualified solution.",
        "next_diagnostic": [
            "Select one already independently qualified QOCO original-coordinate vector for each exact capture, preserving snapshot and log hashes.",
            "Map the same primal/dual point to generic and folded persistent layouts, with folded duals omitted from native scalar storage; first measure canonical residuals without iterations and compare independent original-equation metrics.",
            "Run a bounded one-step and then short continuation from each mapped point; independently audit vectors after every stage. Distinguish absolute native stopping from normalized original-equation acceptance.",
            "If the known point passes the mapping check but drifts under iterations, investigate numerical update/step scaling; if warm continuation remains qualified but cold runs stall, prioritize convergence/preconditioning. Keep original folded multipliers as audit-only reference data, never invent contact or modify primal to make the initial point pass.",
        ],
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(args.output), "sha256": digest(args.output), "finding": report["finding"]}))


if __name__ == "__main__":
    main()
