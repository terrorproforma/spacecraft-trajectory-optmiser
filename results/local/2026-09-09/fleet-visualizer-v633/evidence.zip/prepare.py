"""Saved JSON/Result parsing only. No propagation, optimizer or project imports."""

import hashlib
import json
import re
import struct
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
VIEWER = ROOT / "results/lambda/2026-09-06/visualiser"
BASE = VIEWER / "data/gtoc12-frontier-v629"
RUN = ROOT / "build/performance/fleet-addition-v633b"
SOURCE = ROOT / "results/gtoc12/runs/fleet_master_v10/fleet/Result.txt"
RESULT_SHA = "1f420928bbef8da91e3a6f8b74d3bf00039c78d4257215c103a484bc55bb22da"
BASE_RESULT_SHA = "765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da"
BASE_FLEET_SHA = "f013e14fd7c84c855ae44e408c7896f29dbe7c50e7732992defbcd7fbf7d1680"
CATALOGUE_SHA = "99a42cc30d4498d99b8acf507790ab74f040ff2e202ef6c8e90bbb39b6c46675"
SOURCE_SHA = "795d4a494db6640faae21b19548dfe48898e5c998f055e27b37b676aa8c69b7c"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def write(path, value):
    path.write_bytes(encode(value))


def ship_objects(raw):
    """Return exact JSON object byte slices, preserving whitespace and number text."""
    text = raw.decode()
    cursor = re.search(r'  "ships": \[', text).end()
    decoder = json.JSONDecoder()
    objects = []
    while True:
        while text[cursor] in " \r\n,":
            cursor += 1
        if text[cursor] == "]":
            return objects
        _, end = decoder.raw_decode(text, cursor)
        objects.append(text[cursor:end].encode())
        cursor = end


def rows(raw, ship_id):
    return [line for line in raw.splitlines() if line.split() and int(line.split()[0]) == ship_id]


def main():
    out = HERE / "dataset-b"
    require(not out.exists(), "Fresh output required; preserve an earlier preparation")
    sources = {
        "base_fleet": BASE / "fleet.json",
        "base_manifest": BASE / "manifest.json",
        "base_Result": ROOT / "results/local/2026-09-09/mass-budgeted-frontier-v629/Result.txt",
        "Result": RUN / "draft/Result.txt",
        "checker_binding": RUN / "output/checker-binding.json",
        "report": RUN / "output/report.json",
        "prior_format_failure_report": ROOT / "build/performance/fleet-addition-v633/output/report.json",
        "official": RUN / "output/official.json",
        "independent": RUN / "output/independent.json",
        "source_Result": SOURCE,
        "source_section": RUN / "draft/source-ship-09.txt",
        "catalogue": RUN / "output/official/GTOC12_Asteroids_Data.txt",
    }
    data = {key: path.read_bytes() for key, path in sources.items()}
    for key, pin in {
        "base_fleet": BASE_FLEET_SHA, "base_Result": BASE_RESULT_SHA,
        "Result": RESULT_SHA, "source_Result": SOURCE_SHA, "catalogue": CATALOGUE_SHA,
    }.items():
        require(sha(data[key]) == pin, f"Pinned source differs: {key}")
    binding = json.loads(data["checker_binding"])
    report = json.loads(data["report"])
    require(report["complete"] and report["qualified"], "Complete qualified checker report required")
    for item in [binding, report, binding["official"], binding["independent"],
                 json.loads(data["official"]), json.loads(data["independent"])]:
        require(item["result_sha256"] == RESULT_SHA, "Checker Result binding differs")
    require(binding["official"]["ok"] and binding["independent"]["ok"], "Both checks must pass")
    require(data["Result"].startswith(data["base_Result"]), "Original 23-ship Result prefix changed")
    old_rows = rows(data["source_Result"], 9)
    new_rows = rows(data["Result"], 24)
    require([r.split()[1:] for r in old_rows] == [r.split()[1:] for r in new_rows],
            "Ship 24 source payload differs beyond ship identifier")
    require(old_rows == rows(data["source_section"], 9), "Archived section differs")
    require({int(r.split()[0]) for r in data["Result"].splitlines() if r.split()} == set(range(1, 25)),
            "24-ship inventory differs")
    for sid in range(1, 24):
        require(rows(data["Result"], sid) == rows(data["base_Result"], sid), "Existing rows changed")

    numbered = [(n + 1, row.split()) for n, row in enumerate(new_rows)]
    event_rows = [(n, r) for n, r in numbered if int(r[1]) != -1]
    require(len(event_rows) == 40, "Expected 20 event pairs")
    events, event_sources, points = [], [], []
    cargo = Decimal(0)
    for i in range(20):
        (before_line, before), (after_line, after) = event_rows[2 * i:2 * i + 2]
        require(len(before) == len(after) == 10 and before[:3] == after[:3], "Event pairing")
        require(before[3:6] == after[3:6], "Position differs across event")
        body = int(before[1])
        epoch, mass_before, mass_after = map(float, (before[2], before[9], after[9]))
        delta = mass_after - mass_before
        role = "launch" if i == 0 else "earth-return" if i == 19 else "deploy" if delta < 0 else "collect"
        kind = "launch" if i == 0 else "flyby" if i == 19 else "rendezvous"
        require((body == 0 if i == 0 else body == -3 if i == 19 else body > 0), "Event identity")
        if role == "deploy":
            require(abs(delta + 40) <= 1e-9, "Miner mass changed")
        if role == "collect":
            cargo += Decimal(after[9].decode()) - Decimal(before[9].decode())
        position = list(map(float, before[3:6]))
        points.append([epoch, *position])
        events.append({"index": i, "epoch_mjd": epoch, "event_id": body, "kind": kind, "role": role,
                       "body": "Earth (launch)" if i == 0 else "Earth" if i == 19 else f"asteroid {body}",
                       "mass_before_kg": mass_before, "mass_after_kg": mass_after,
                       "mass_delta_kg": delta, "position_km": position})
        event_sources.append({"index": i, "before_line_in_ship_section": before_line,
                              "after_line_in_ship_section": after_line,
                              "before_fields": [x.decode() for x in before],
                              "after_fields": [x.decode() for x in after]})
    require(cargo == Decimal("624.0383299112"), "Exact saved cargo differs")
    controls = [list(map(float, row[3:6])) for _, row in numbered if int(row[1]) == -1]
    require(len(controls) == 4319, "Control row inventory differs")
    point_bytes = b"".join(struct.pack("<4d", *p) for p in points)
    series = {"point_count": 20, "original_point_count": 20,
              "original_sha256": sha(point_bytes), "selected_indices": list(range(20)),
              "points_txyz": points}
    asteroid_ids = list(dict.fromkeys(e["event_id"] for e in events if e["event_id"] > 0))
    ship = {
        "ship_id": 24, "trajectory_id": "gtoc12_local_fleet_addition_v633_ship24",
        "launch_epoch_mjd": points[0][0], "return_epoch_mjd": points[-1][0],
        "final_sample_epoch_mjd": points[-1][0], "initial_mass_kg": events[0]["mass_before_kg"],
        "final_mass_kg": events[-1]["mass_after_kg"], "collected_kg": float(cargo),
        "miners_deployed": 9, "collects": 9, "asteroids": asteroid_ids, "events": events,
        "replay": {**series, "gap_after_indices": list(range(19))}, "transcription": series,
        "controls_summary": {name: {"minimum": min(r[i] for r in controls),
                                      "maximum": max(r[i] for r in controls),
                                      "mean": sum(r[i] for r in controls) / len(controls)}
                             for i, name in enumerate(("Tx", "Ty", "Tz"))},
        "display_sample_kind": "archived_event_states_only",
        "display_sample_provenance": {
            "source_Result_sha256": SOURCE_SHA, "source_ship_id": 9, "display_ship_id": 24,
            "current_Result_sha256": RESULT_SHA, "event_side_for_position": "before",
            "position_before_after_bytes_identical": True, "native_node_samples": 0,
            "dense_replay_samples": 0, "saved_event_samples": 20, "new_propagations": 0,
            "point_hash_encoding": "20 rows of little-endian FP64 (MJD,x_km,y_km,z_km)",
        },
        "qualification": {"qualified": True, "label": "Both current full-fleet checkers pass; event-only display"},
        "raw_evidence_sha256": RESULT_SHA,
    }
    fleet = json.loads(data["base_fleet"])
    original_objects = ship_objects(data["base_fleet"])
    require(len(original_objects) == 23, "Base viewer ship inventory differs")
    old_asteroids = {r["id"] for r in fleet["asteroids"]}
    require(old_asteroids.isdisjoint(asteroid_ids), "New route asteroid conflict")
    catalogue = {}
    for line in data["catalogue"].splitlines():
        fields = line.split()
        if len(fields) == 8 and fields[0].isdigit():
            sid = int(fields[0])
            catalogue[sid] = dict(zip(("epoch_mjd", "a_au", "e", "i_deg", "node_deg", "peri_deg", "m0_deg"), map(float, fields[1:])))
    require(len(catalogue) == 60000, "Catalogue inventory")
    fleet["asteroids"] = sorted(fleet["asteroids"] + [{"id": sid, **catalogue[sid], "visited_by": [24], "visits": 2} for sid in asteroid_ids], key=lambda r: r["id"])
    independent = binding["independent"]
    composition = {"baseline_Result_sha256": BASE_RESULT_SHA, "retained_ship_ids": list(range(1, 24)),
                   "appended_ship_id": 24, "archived_source_ship_id": 9, "qualified": True,
                   "raw_gain_kg": report["raw_delta_kg"], "weighted_gain_kg": report["weighted_delta_kg"]}
    provenance = {"new_propagations": 0, "new_orbital_equation_evaluations": 0, "new_interpolated_samples": 0,
                  "reused_history_ship_ids": list(range(1, 24)), "event_only_ship_ids": [24],
                  "native_node_ship_ids_inherited": [8, 19], "unsampled_intervals_are_gaps": True,
                  "new_event_samples": 20, "new_catalogue_rows_parsed": 9}
    mapping = {"sources": {key: {"path": str(path.relative_to(ROOT)).replace("\\", "/"), "sha256": sha(data[key]), "bytes": len(data[key])} for key, path in sources.items()},
               "composition": composition, "display_replay_provenance": provenance,
               "ship_record_sha256": {str(i + 1): sha(raw) for i, raw in enumerate(original_objects)},
               "ship24": {"events": event_sources, "control_rows": 4319, "point_encoding_sha256": sha(point_bytes),
                          "missing_intervals_mjd": [[points[i][0], points[i + 1][0]] for i in range(19)],
                          "archived_ship_section_sha256": sha(data["source_section"])}}
    out.mkdir()
    write(out / "source-display-map.json", mapping)
    (out / "checker-binding.json").write_bytes(data["checker_binding"])
    (out / ".gitattributes").write_bytes(b"*.json -text -whitespace\n")
    run_id = "local_fleet_addition_v633"
    source = {"generator": "Saved Result events plus byte-preserved frontier-v629 display records",
              "solution_basename": "Result.txt", "solution_sha256": RESULT_SHA,
              "solution_bytes": len(data["Result"]), "solution_verified_locally": True,
              "official_verifier_ok": True, "independent_verifier_ok": True,
              "catalogue": fleet["source"]["catalogue"], "base_display_source": fleet["source"],
              "display_data_basename": "source-display-map.json",
              "display_data_sha256": sha((out / "source-display-map.json").read_bytes()),
              "transform": "23 original ship JSON objects retained byte-for-byte. Ship 24 uses 20 saved event positions, with all 19 unsampled intervals omitted. No propagation or interpolation."}
    fleet.update(title="GTOC12 verified 24-ship fleet — local archive addition v633",
                 export_title="Verified archive addition with event-only display for ship 24", run_id=run_id,
                 generated_by_commit="verified-frontier-v629+archive-fleet-master-v10+v633b-checkers",
                 composition=composition, display_replay_provenance=provenance, source=source,
                 verification=independent,
                 score={"ships": 24, "unique_asteroids": 208, "mined_asteroids": 208,
                        "total_collected_kg": independent["total_mass_kg"],
                        "independent_total_mass_kg": independent["total_mass_kg"],
                        "official_total_mass_kg": binding["official"]["total_mass_kg"],
                        "weighted_score_fixed_bonus_kg": independent["weighted_score_fixed_bonus_kg"],
                        "ship_limit": independent["ship_limit"], "verifier_ok": True})
    fleet["kepler_check"] = {**fleet["kepler_check"], "scope": "Inherited context check for the existing 23 ships only; nine added catalogue rows parsed without a new context propagation check."}
    fleet["ships"] = [f"PRESERVED_SHIP_OBJECT_{i}" for i in range(23)] + [ship]
    serialized = encode(fleet)
    for i, raw in enumerate(original_objects):
        serialized = serialized.replace(json.dumps(f"PRESERVED_SHIP_OBJECT_{i}").encode(), raw, 1)
    (out / "fleet.json").write_bytes(serialized)
    require(ship_objects(serialized)[:23] == original_objects, "Original ship record bytes changed")
    actual = json.loads(serialized)
    require(actual["score"]["ships"] == len(actual["ships"]) == 24 and len(actual["asteroids"]) == 208, "Final inventory")
    prior_report = json.loads(data["prior_format_failure_report"])
    worker_seconds = report["seconds"] + prior_report["seconds"]
    compute = {"run_id": run_id, "fleet_run_id": run_id, "commit": fleet["generated_by_commit"],
               "result_sha256": RESULT_SHA, "weighted_score_fixed_bonus_kg": independent["weighted_score_fixed_bonus_kg"],
               "raw_kg_per_ship": independent["total_mass_kg"] / 24,
               "hardware": {"fleet_assembly": "Local saved-route composition and CPU full-fleet checks; no new GPU solves", "upstream_search": "Historical source fleet_master_v10; previous 23 ships retained"},
               "timing": {"wall_seconds_total": worker_seconds,
                   "wall_human": f"{worker_seconds:.3f} s summed checker-worker time, 2 attempts (2 CPU + 2 official calls); final pass {report['seconds']:.3f} s; excludes archive recovery and display export",
                   "scope": "Sum of both checker-worker elapsed times, excluding archive recovery and display export",
                   "first_format_rejection_seconds": prior_report["seconds"],
                   "final_pass_seconds": report["seconds"]},
               "model": {"dynamics": "Both original full-fleet checkers; unchanged physical tolerances", "local_refine": "No new refinement in this archive-addition step"},
               "optimisation": {"strategy": "Add one disjoint certified 9-asteroid route using available fleet raw-mass budget", "proven_optimal": False},
               "run_counts": {"native_solves": 0, "search_calls": 0, "GPU_calls": 0, "checker_attempts": 2, "independent_full_fleet_checks": 2, "official_full_fleet_checks": 2},
               "final_pass_counts": {"independent_full_fleet_checks": 1, "official_full_fleet_checks": 1},
               "all_checker_attempts": {"independent_full_fleet_checks": 2, "official_full_fleet_checks": 2,
                   "worker_seconds_total": report["seconds"] + json.loads(data["prior_format_failure_report"])["seconds"],
                   "prior_attempt": "Independent physics passed; official checker rejected one trailing empty line. Final attempt removed only terminal CRLF."},
               "composition": composition, "display_replay_provenance": provenance}
    write(out / "compute.json", compute)
    manifest = {"schema_version": "1.0.0", "dataset_kind": "gtoc12-fleet", "source": source,
                "composition": composition, "display_replay_provenance": provenance,
                "kepler_check": fleet["kepler_check"], "transform": source["transform"],
                "summary": {"ships": 24, "unique_asteroids": 208, "events": sum(len(s["events"]) for s in actual["ships"]),
                            "replay_points": sum(s["replay"]["point_count"] for s in actual["ships"]),
                            "official_total_mass_kg": binding["official"]["total_mass_kg"]},
                "files": {p.name: {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())} for p in sorted(out.iterdir())}}
    write(out / "manifest.json", manifest)
    write(HERE / "preparation-report.json", {"complete": True, "passed": True, "new_numerical_calls": 0,
          "Result_sha256": RESULT_SHA, "fleet_sha256": sha(serialized), "preserved_ship_objects": 23,
          "ship24_event_points": 20, "ship24_unsampled_gaps": 19, "summary": manifest["summary"],
          "source_display_map_sha256": sha((out / "source-display-map.json").read_bytes())})
    print(json.dumps(manifest["summary"]))


if __name__ == "__main__":
    main()
