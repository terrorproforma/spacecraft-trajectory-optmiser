# ruff: noqa: E402 -- activate the pinned source before importing production modules
from __future__ import annotations

import copy
import dataclasses
import json
import os
from types import SimpleNamespace

import common as C
import numpy as np
import pytest

assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
C.activate()
from check_fleet import qualify
from runtime import Coordinator, emit_route

from spacepdhcg.gtoc12 import pipeline as p
from spacepdhcg.gtoc12.fixed_refinement import validate_prescription
from spacepdhcg.gtoc12.low_thrust import LegBoundary, ScvxSettings
from spacepdhcg.gtoc12.refinement_admission import FixedCargoRequest
from spacepdhcg.gtoc12.search import RoutePlan
from spacepdhcg.gtoc12.trajectory_seed import ZohTrajectorySeed

PROTOCOL = C.read(C.KIT / "protocol.json")


def case_and_plan(index):
    case = PROTOCOL["candidates"][index]
    return case, RoutePlan.from_summary(C.read(C.KIT / "inputs" / case["input_file"]))


def test_exact_three_prefixes_and_finite_budget():
    assert [c["id"] for c in PROTOCOL["candidates"]] == [
        "local-v794-ship22-rank0000",
        "local-v794-ship10-rank0000",
        "local-v802-ship19-rank0000",
    ]
    assert [c["native_flights"] for c in PROTOCOL["candidates"]] == [16, 18, 16]
    assert sum(c["native_flights"] for c in PROTOCOL["candidates"]) == 50
    assert sum(len(c["waits"]) for c in PROTOCOL["candidates"]) == 3
    assert PROTOCOL["max_outer_iterations"] == 2200
    assert ScvxSettings(**PROTOCOL["settings"]).selected_ephemeris_backend() == "cuda"


@pytest.mark.parametrize("index", range(3))
def test_real_prescriptions_validate_and_identity_catches_changed_cargo(index):
    case, plan = case_and_plan(index)
    validate_prescription(plan, plan.collected_mass)
    request = FixedCargoRequest.from_summary(plan.summary(), plan.collected_mass)
    assert request.sha256 == case["request_sha256"]
    changed = dict(plan.collected_mass)
    changed[next(iter(changed))] -= 0.01
    assert FixedCargoRequest.from_summary(plan.summary(), changed).sha256 != request.sha256
    too_much = dict(plan.collected_mass)
    too_much[next(iter(too_much))] += 100
    with pytest.raises(ValueError):
        validate_prescription(plan, too_much)
    assert all((leg.from_id, leg.to_id) != (37322, 37066) for leg in plan.legs)


@pytest.mark.parametrize("ship", [22, 10, 19])
def test_exact_current_earth_seed_and_missing_node_rejected(ship):
    with np.load(C.KIT / "inputs" / f"ship-{ship:02d}-earth-seed.npz") as stored:
        epochs = stored["node_epochs_mjd"]
        initial = stored["initial_state"]
        boundary = LegBoundary(
            epochs[0],
            initial[:3],
            stored["departure_body_velocity"],
            epochs[-1],
            stored["arrival_position"],
            stored["arrival_velocity"],
            initial_mass=3000.0,
            minimum_final_mass=500.0,
            free_departure_vinf=True,
        )
        seed = ZohTrajectorySeed(epochs, initial, stored["thrust_n"], C.RESULT_SHA)
        settings = ScvxSettings(**PROTOCOL["settings"])
        seed.validate_for(boundary, settings, epochs)
        changed = ZohTrajectorySeed(
            np.delete(epochs, 1), initial, np.delete(stored["thrust_n"], 1, axis=0), C.RESULT_SHA
        )
        with pytest.raises(ValueError):
            changed.validate_for(boundary, settings, epochs)
        assert not seed.initial_state.flags.writeable
        assert not seed.thrust_n.flags.writeable


def coordinator(tmp_path, case_index, wait_index, monkeypatch, *, failed=False):
    case, plan = case_and_plan(case_index)
    descriptor = case["waits"][wait_index]
    index = descriptor["after_flight"]
    raw = np.array([4.0e8 + 0.01, 7.0, 9.0, 0.0, 20.0, 0.0, 1400.0])
    observer = SimpleNamespace(
        index=None,
        raw={("flight", index): {"status": 0, "rows": [{"status": 0, "final_state": raw}]}},
    )
    rv = np.array([4.0e8, 0.0, 0.0]), np.array([0.0, 20.0, 0.0])
    monkeypatch.setattr(p, "body_state", lambda *args: tuple(x.copy() for x in rv))
    calls = []

    def wait_runner(wait, initial, unused):
        calls.append(initial.copy())
        state = np.r_[*rv, initial[6]]
        if failed:
            state[6] += 1.0
        return {"status": 0, "final_state": state, "minimum_radius_km": 4.0e8}

    directory = tmp_path / "case"
    directory.mkdir()
    value = Coordinator(
        plan, None, case, directory, observer, float("inf"), wait_runner=wait_runner
    )
    (directory / "legs" / f"{index:02d}").mkdir()
    item = SimpleNamespace(
        solution=None,
        certified=True,
        mass_after_leg=1400.0,
        certificate=SimpleNamespace(final_mass_kg=1400.0),
    )
    return value, index, item, raw, rv, calls


def test_before_collection_wait_uses_actual_gpu_state(tmp_path, monkeypatch):
    value, index, item, raw, rv, calls = coordinator(tmp_path, 0, 0, monkeypatch)
    # Synthetic callback branch check; all three real waits are after deployment.
    value.case["waits"][0]["kind"] = "before_collection"
    try:
        value.on_leg(index, item, {"certified": True})
        assert len(calls) == 1 and np.array_equal(calls[0], raw)
        assert not np.array_equal(calls[0][:3], rv[0])
        assert value.all_waits_passed()
    finally:
        value.close()


def test_after_deployment_wait_subtracts_one_miner(tmp_path, monkeypatch):
    value, index, item, _raw, rv, calls = coordinator(tmp_path, 2, 0, monkeypatch)
    try:
        value.on_leg(index, item, {"certified": True})
        assert np.array_equal(calls[0][:6], np.r_[*rv])
        assert calls[0][6] == 1360.0
        assert value.all_waits_passed()
    finally:
        value.close()


def test_failed_wait_retains_failure_and_prevents_emission(tmp_path, monkeypatch):
    value, index, item, _, _, _ = coordinator(tmp_path, 0, 0, monkeypatch, failed=True)
    try:
        before = copy.deepcopy(value.plan.summary())
        with pytest.raises(RuntimeError, match="coast rejected"):
            value.on_leg(index, item, {"certified": True})
        assert not value.all_waits_passed()
        assert list((value.directory / "waits").glob("*-failure.json"))
        with pytest.raises(ValueError):
            emit_route(SimpleNamespace(certified=True), value)
        assert value.plan.summary() == before
    finally:
        value.close()


def test_three_ship_splice_preserves_other_20_sections_exactly():
    payload = b"".join(f"{ship} old\r\n".encode() for ship in range(1, 24)).rstrip(b"\r\n")
    composed = C.splice(payload, {22: b"22 new", 10: b"10 new", 19: b"19 new"})
    original, new = C.sections(payload), C.sections(composed)
    assert all(original[s] == new[s] for s in original if s not in (22, 10, 19))
    assert new[22] == b"22 new\n" and new[10] == b"10 new\n" and new[19] == b"19 new\n"
    with pytest.raises(AssertionError):
        C.splice(payload, {8: b"19 wrong id"})


@pytest.mark.parametrize(
    "change, accepted",
    [
        ({}, True),
        ({"ship_limit": 22.99}, False),
        ({"weighted_score_fixed_bonus_kg": float("nan")}, False),
        ({"ok": False}, False),
    ],
)
def test_raw_decrease_uses_actual_fleet_rule_not_per_ship_filter(change, accepted):
    baseline = C.read(C.BASE / "checker-binding.json")["independent"]
    expected = {
        "raw_kg": baseline["total_mass_kg"] - 1,
        "weighted_kg": baseline["weighted_score_fixed_bonus_kg"] + 1,
        "asteroids": 200,
    }
    independent = {
        "ok": True,
        "ships": 23,
        "mined_asteroids": 200,
        "ship_limit": 23.8,
        "total_mass_kg": expected["raw_kg"],
        "weighted_score_fixed_bonus_kg": expected["weighted_kg"],
    } | change
    official = {"ok": True, "ships": 23, "mined_asteroids": 200}
    assert qualify(independent, official, expected, baseline)["accepted_improvement"] is accepted
    assert not qualify(independent, official | {"ok": False}, expected, baseline)[
        "accepted_improvement"
    ]


def test_supervisor_preserves_lock_for_detached_worker(monkeypatch):
    import supervise

    launch = {}
    monkeypatch.setattr(
        supervise.subprocess, "Popen", lambda *args, **kwargs: launch.update(kwargs)
    )
    supervise.run_owned(["dummy"], None, {}, SimpleNamespace(fileno=lambda: 91))
    assert launch["pass_fds"] == (91,) and launch["start_new_session"] is True


@pytest.mark.parametrize(
    "inventory,expected", [("", True), ("123 other-process", False), (None, False)]
)
def test_cleanup_blocks_success_when_inventory_fails_or_is_nonempty(
    monkeypatch, inventory, expected
):
    import supervise

    called = []
    child = SimpleNamespace(poll=lambda: 0)
    monkeypatch.setattr(
        supervise.process_guard,
        "cleanup",
        lambda *args: called.append(args) or {"verified_empty": True},
    )

    def query(*args, **kwargs):
        if inventory is None:
            raise OSError("inventory unavailable")
        return inventory

    monkeypatch.setattr(supervise.subprocess, "check_output", query)
    report = {"passed": True, "failures": []}
    supervise.finish_cleanup(report, child, {"nvidia_smi": "unused"}, object())
    assert called == [(child, 10, 30)]
    assert report["passed"] is expected
    assert report["child_exit_after_cleanup"] == 0
    assert bool(report["failures"]) is (inventory is None)


def test_report_json_preserves_nonfinite_diagnostic_without_claiming_numeric_validity():
    payload = {
        "array": np.array([1.0, np.inf]),
        "boundary": dataclasses.make_dataclass("D", [("mass", float)])(3.0),
    }
    encoded = json.dumps(C.safe(payload), allow_nan=False)
    assert json.loads(encoded) == {"array": [1.0, "inf"], "boundary": {"mass": 3.0}}


def test_new_production_context_reprices_exact_current_saved_requests():
    from spacepdhcg.gtoc12.bundles import ClusterPricingSettings, refine_candidates
    from spacepdhcg.gtoc12.refinement_admission import FleetBudgetContext

    raw = (C.BASE / "bonus_coefficients.txt").read_bytes()
    weights = {i + 1: float(line.split()[0]) for i, line in enumerate(raw.splitlines())}
    checked = C.read(C.BASE / "checker-binding.json")
    context = FleetBudgetContext.from_verified_result(
        (C.BASE / "Result.txt").read_bytes(),
        independent=checked["independent"],
        official=checked["official"],
        weights=weights,
    )
    for index in range(3):
        case, plan = case_and_plan(index)
        before = copy.deepcopy(plan.summary())
        selected = refine_candidates(
            [plan],
            set(),
            ClusterPricingSettings(ships=1, refine_top=1),
            fleet_context=context,
            replacement_ship=case["ship"],
        )
        assert selected == [plan] and before == plan.summary()
        budget = context.replacement(case["ship"], FixedCargoRequest.from_summary(plan.summary()))
        assert abs(budget.raw_gain_kg - case["raw_delta_kg"]) < 1e-8
        assert abs(budget.objective_gain_kg - case["weighted_delta_kg"]) < 1e-8
    assert PROTOCOL["candidates"][0]["raw_delta_kg"] < 0


def test_boundary_batch_telemetry_uses_actual_refined_route_field():
    from worker import boundary_ephemeris_of

    _case, plan = case_and_plan(0)
    route = p.RefinedRoute(
        plan,
        [],
        dict(plan.collected_mass),
        500,
        False,
        False,
        1,
        0,
        {"boundary_ephemeris": {"backend": "cuda", "batches": 1}},
    )
    copied = boundary_ephemeris_of(route)
    assert copied == {"backend": "cuda", "batches": 1}
    route.scheduler_telemetry["boundary_ephemeris"]["batches"] = 0
    assert copied["batches"] == 1
    with pytest.raises(ValueError, match="exactly one CUDA"):
        boundary_ephemeris_of(route)
