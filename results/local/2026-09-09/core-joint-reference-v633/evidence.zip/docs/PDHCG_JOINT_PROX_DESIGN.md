# Joint equality and L1 primal proximal design

The [v631 CPU reference](PDHCG_EQUALITY_PRIMAL_REFERENCE.md) made the original equalities accurate to roundoff on two frozen stages of one synthetic trajectory fixture. Both optimization results still failed the original KKT gate. Their largest gap contribution was virtual-control L1 complementarity: all 525 virtual coordinates remained nonzero while their pair duals were far from the original penalty endpoints.

The proposed next reference puts equality feasibility and the original L1 penalty in the same primal proximal operation. It retains every physical and virtual-control variable, every remaining scalar/SOC constraint, and the original penalty lambda. It applies only to the two exact zero-Q inputs; a nonzero quadratic objective is rejected.

For retained primal u, equality E*u=b and conic operator C, the outer step is

    z_new = project_cones(z + Sigma_C*(C*u_bar-h))
    w = u - T*(c_ret + C^T*z_new)
    u_new = argmin_{E*a=b} .5*||a-w||^2_{T^-1} + sum(lambda*|a_virtual|).

There is no separate L1 dual update or additional old-q term in w. The exact v631 T and Sigma_C are retained. Removing the lambda selector rows from the dual operator preserves its sufficient coefficient-based squared norm bound below 0.9025 for an exact proximal operation; it does not justify increasing any step.

Given an equality multiplier mu, the inner candidate is a diagonal soft threshold:

    a = w-T*E^T*mu
    u_physical = a_physical
    u_virtual = soft(a_virtual, T_virtual*lambda)
    q = clip(a_virtual/T_virtual, -lambda, lambda).

The remaining inner equation is E*u(mu)=b. Its active Hessian is the physical Gram plus diagonal contributions from the active virtual controls. The captured dynamics have distinct virtual columns with coefficient -1, so the active contributions are diagonal after the same trajectory ordering. The full Gram has half-bandwidth 19. A singular or numerically unusable active factor triggers a descent direction using the full Gram E*T*E^T; this is not a ridge or an objective change. Factors and all fallback work must be charged.

Original-coordinate readout uses y=mu, t=|v|, pair multipliers (lambda+q)/2 and (lambda-q)/2, and s=h-G*x. It does not round tiny v values to zero. At an exact inner solution, q is a valid original L1 subgradient; original optimization stationarity still depends on convergence of the outer iteration.

The [sealed v632 design](../build/performance/core-joint-prox-v632/DESIGN.md), [tiny results](../build/performance/core-joint-prox-v632/RESULTS.md) and [eight-file index](../build/performance/core-joint-prox-v632/index.json) contain the derivation, nine independent Fraction fixtures, exact witness-gap bounds, FP64 tests and a deliberately unresolved 32-direction limit case. The index SHA-256 is `27bbd087aedd788f920b434484c56b2a7feec9ce648a45ba038dcfe02bffb854`.

The fixed experimental FP64 stop is 1e-11 for normalized equality, proximal stationarity, L1 Fenchel defect and equality-dual gap debt, with an exact represented q-box check. Each call permits at most 32 directions and 12 Newton halvings per direction. This practical stop is **not** a summably-inexact PDHG convergence guarantee. The separate witness theorem requires exact feasibility or certified roundoff enclosures; the tiny exact bounds are not captured-problem certificates.

The v632 evidence contains no captured proximal calls, optimization runs or GPU work. The subsequent [v633 CPU reference](../results/local/2026-09-09/core-joint-reference-v633/README.md) ran once on the two saved inputs. Both charged initial joint proximal calls passed, but the early case failed its first outer attempt and the near-converged case failed after 73 committed updates. All full/active factors passed; neither failure was an iteration cap. Both stopped at the fallback merit-decrease check after Newton backtracking was exhausted.

All six saved original points fail the unchanged long-double and 65-digit KKT gates. Their virtual L1 cost and pair complementarity are zero, but original cone, stationarity and gap errors remain. Complete worker process time was 0.71946 seconds for this short failed run, including setup and all failed work; it is not a speed improvement over a completed longer run.

Saved-state arithmetic identifies the early blocking inner metric as normalized equality-dual gap debt 1.72283e-10, and the near blocking metric as normalized equality residual 4.06063e-10. Both exceed the fixed 1e-11 budget. The line search computes a trial's residual verdict but does not consult it before Armijo. Rejected trial vectors and decrease terms were not saved, so the evidence does not establish that any discarded trial passed.

The next numerical test preserves all steps and gates: honor the existing residual stop on a trial, and use the dual quadratic decrease -F^T*delta + .5*delta^T*H_active*delta on an unchanged signed branch. The full Gram supplies an upper bound across branch changes and for the fallback direction. Exact tiny branch/cancellation tests and retained trial diagnostics are needed before a new captured comparison. The v633 failures remain unchanged.
