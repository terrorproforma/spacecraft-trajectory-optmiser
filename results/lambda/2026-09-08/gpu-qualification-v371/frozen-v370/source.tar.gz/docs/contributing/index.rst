Contributing
============

.. toctree::
   :maxdepth: 2
   :hidden:

   developer_guide

We are very open to any contribution including new features, bug fixes, new interfaces for different languages, and documentation improvements. File any issues, bug reports, or feature requests `here <https://github.com/qoco-org/qoco/issues>`_.

If you have any questions, comments, or any feedback, please email us at `govindchari1@gmail.com <mailto:govindchari1@gmail.com>`_.