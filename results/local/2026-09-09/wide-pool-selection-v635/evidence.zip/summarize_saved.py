"""Summarize already saved pool metrics and link prior outcomes; no model imports."""
from collections import Counter
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write(name, value):
    with (HERE / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    if not __debug__:
        raise RuntimeError('Assertions must remain enabled')
    assert not (HERE / 'index.json').exists()
    rows = [r for r in load(HERE / 'all-candidate-metrics.json') if r['hardware'] == 'local']
    assert len(rows) == 1960
    assert len({r['request_sha256'] for r in rows}) == 1960
    summary = {
        'source_metrics_sha256': sha(HERE / 'all-candidate-metrics.json'),
        'distinct_requests': len(rows),
        'new_requests': sum(r['new_request_vs_narrow'] for r in rows),
        'new_order_records': sum(r['new_order_vs_narrow'] for r in rows),
        'new_deployment_orders': len({(r['ship'], r['order_sha256']) for r in rows if r['new_order_vs_narrow']}),
        'all_first_Earth_legs_unchanged': all(r['compatible_first_Earth_leg'] for r in rows),
        'ship24_conflicting_requests': sum(bool(r['conflicts_with_new_ship24']) for r in rows),
        'recommended_additional_gain_refinements_from_this_pool': 0,
        'per_ship': {},
        'new_model_or_solver_calls': 0,
        'frozen_campaign': {
            'search_weights': 'unit; actual bonus only in output ranking/reporting',
            'opportunity_prices_passed': False,
            'master_family_objective_passed': False,
            'ships': [10, 21],
            'Earth_seed': 'exact incumbent first body, launch and duration',
            'family_radius': 4,
            'pool_neighbour_limit': 192,
            'pool_includes_own_footprint': True,
            'pool_excludes_other_ships': True,
            'beam_width': 128, 'neighbours': 96, 'max_deploys': 10,
            'max_per_first': 128, 'first_level_window_days': 0,
            'time_budget_seconds': 60, 'harvest_substitution': False,
            'fit_role': 'five-feature propellant inflation; not fleet opportunity prices',
            'source_run_sha256': sha(HERE / 'inputs/wide-run.py'),
            'source_fit_sha256': sha(HERE / 'inputs/wide-fit.json'),
        },
    }
    for ship in (10, 21):
        items = [r for r in rows if r['ship'] == ship]
        owners, asteroids = Counter(), Counter()
        for row in items:
            owners.update({owner for ids in row['conflicts'].values() for owner in ids})
            asteroids.update(row['conflicts'].keys())
        summary['per_ship'][str(ship)] = {
            'requests': len(items),
            'conflicting_requests': sum(bool(r['conflicts']) for r in items),
            'conflicting_owner_counts_overlap': dict(owners),
            'conflicting_asteroid_counts_overlap': dict(asteroids),
            'fits_raw_rule': sum(r['fits_fleet_raw_rule'] for r in items),
            'new_order_raw_eligible': [r['id'] for r in items if r['new_order_vs_narrow'] and r['fits_fleet_raw_rule']],
            'best_new_order_weighted_delta_kg': max(r['weighted_delta_kg'] for r in items if r['new_order_vs_narrow']),
        }
    s10 = max(r['weighted_delta_kg'] for r in rows if r['ship'] == 10)
    s21new = summary['per_ship']['21']['best_new_order_weighted_delta_kg']
    summary['best_ship10_plus_best_new_ship21_weighted_delta_kg'] = s10 + s21new
    assert summary['new_requests'] == 972 and summary['new_deployment_orders'] == 509
    assert summary['ship24_conflicting_requests'] == 0
    write('selection-summary.json', summary)

    names = {
        'prefix_case': 'build/performance/fleet-budgeted-prefix-v630/output/local-v794-ship10-rank0000/case-report.json',
        'prefix_route': 'build/performance/fleet-budgeted-prefix-v630/output/local-v794-ship10-rank0000/route-result.json',
        'mass_merit_audit': 'build/performance/mass-merit-return-v632/saved-audit.json',
        'mass_merit_profile': 'build/performance/mass-merit-return-v632/profile.json',
        'interval_saved_audit': 'build/performance/interval-defect-replay-v633/saved-audit.json',
        'interval_analysis': 'build/performance/interval-defect-replay-v633/output/analysis.json',
        'separate_horizon_protocol': 'build/performance/return-horizon-v634/protocol.json',
    }
    data = {key: load(ROOT / value) for key, value in names.items()}
    audit = data['mass_merit_audit']
    candidate = [r for r in audit['cases'] if r['case'] != 'original_mass_control']
    assert len(candidate) == 1
    interval = data['interval_analysis']
    assert not interval['original_gate_passed']
    assert interval['worst']['component'] == 'vy' and interval['worst']['interval_index_zero_based'] == 0
    write('failure-context.json', {
        'scope': 'Previously saved outcomes and source identity; no audit or trajectory rerun',
        'dependencies': {k: {'path': v, 'sha256': sha(ROOT / v)} for k, v in names.items()},
        'mass_merit_source_equations': audit['source_equation_hashes'],
        'mass_merit_library_sha256': data['mass_merit_profile']['library']['sha256'],
        'mass_merit_manifest_sha256': audit['native_delta']['new_manifest_sha256'],
        'mass_merit_candidate_saved_record': candidate[0],
        'interval_saved_worst': interval['worst'],
        'interval_saved_gate': interval['original_defect_gate'],
        'interval_saved_over_gate_components': interval['components_over_original_gate'],
        'horizon_protocol_only': data['separate_horizon_protocol'],
        'horizon_run_outcome_inspected': False,
        'new_model_or_solver_calls': 0,
    })
    files = {p.relative_to(HERE).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(HERE.rglob('*')) if p.is_file() and p.name != 'index.json'}
    index = {'file_count': len(files), 'bytes': sum(x['bytes'] for x in files.values()),
             'files': files, 'mode': 'saved-data-only pool analysis', 'passed': True}
    write('index.json', index)
    assert all((HERE / name).stat().st_size == item['bytes'] and sha(HERE / name) == item['sha256']
               for name, item in index['files'].items())
    print(json.dumps({'index_sha256': sha(HERE / 'index.json'), 'file_count': index['file_count'],
                      'bytes': index['bytes'], 'findings_sha256': sha(HERE / 'findings.json'),
                      'report_sha256': sha(HERE / 'REPORT.md')}, indent=2))


if __name__ == '__main__':
    main()
