"""CPU-only tests for the profiler supervisor's process ownership boundary."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

from process_guard import cleanup, descendants, enable_subreaper, process_record


class OwnershipTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        enable_subreaper()

    def exercise(self, exited_leader):
        with tempfile.TemporaryDirectory(prefix="dual-profile-guard-") as folder:
            marker = Path(folder) / "leaf.txt"
            leaf = "import os,pathlib,sys,time; pathlib.Path(sys.argv[1]).write_text(str(os.getpid())); time.sleep(60)"
            middle = "import subprocess,sys,time; subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[2]], start_new_session=True); time.sleep(0.1)"
            leader = ("import subprocess,sys,time; subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[2],sys.argv[3]], start_new_session=True); time.sleep(0.2)"
                      if exited_leader else
                      "import subprocess,sys,time; subprocess.Popen([sys.executable,'-c',sys.argv[2],sys.argv[3]], start_new_session=True); time.sleep(60)")
            child = subprocess.Popen([sys.executable, "-c", leader, middle, leaf, str(marker)],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                     start_new_session=True)
            try:
                deadline = time.monotonic() + 5
                while not marker.exists() and time.monotonic() < deadline:
                    time.sleep(0.01)
                self.assertTrue(marker.exists())
                leaf_pid = int(marker.read_text())
                if exited_leader:
                    self.assertEqual(child.wait(timeout=5), 0)
                self.assertTrue(any(p["pid"] == leaf_pid for p in descendants()))
            finally:
                report = cleanup(child, term_seconds=1, kill_seconds=2)
            self.assertTrue(report["verified_empty"], report)
            self.assertEqual(descendants(), [])
            self.assertIsNone(process_record(leaf_pid))

    def test_active_leader_and_detached_child(self):
        self.exercise(False)

    def test_exited_leader_double_fork_adopted(self):
        self.exercise(True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
