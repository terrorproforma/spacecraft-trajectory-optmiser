from pathlib import Path
import fcntl,json,os,subprocess,time
root=Path('/home/ubuntu/spacepdhcg-scaled-followup-v550');root.mkdir(exist_ok=True)
py='/home/ubuntu/spacepdhcg/v1/.venv/bin/python'
env={k:v for k,v in os.environ.items() if not k.startswith(('SPACEPDHCG_TEST_','QOCO_REPLAY_'))}
env.update(PYTHONPATH=str(Path('src').resolve()),SPACEPDHCG_GTOC12_GPU_TESTS='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',SPACEPDHCG_GTOC12_DATA='/home/ubuntu/spacepdhcg/gtoc12/benchmarks/gtoc12/data')
boot="import sys;sys.meta_path=[f for f in sys.meta_path if f.__class__.__module__!='_editable_skbc_spacepdhcg'];import pytest;sys.exit(pytest.main(sys.argv[1:]))"
test='tests/test_gtoc12_gpu_scaled_workspace_pool.py::test_scaled_pool_refreshes_and_discards_failed_leg[1-lagrange-1]'
report=dict(pid=os.getpid(),complete=False,cases=[])
def save():
 t=root/'report.tmp';t.write_text(json.dumps(report,indent=2));t.replace(root/'report.json')
save()
try:
 with open('/home/ubuntu/.spacepdhcg-gpu.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for label,core,qoco in [
   ('previous','/home/ubuntu/spacepdhcg-retained-replay-v514/core-build/cuda','/home/ubuntu/spacepdhcg-preserve-objective-v535/final'),
   ('candidate','/home/ubuntu/spacepdhcg-scaled-pool-v545/core-build/cuda','/home/ubuntu/spacepdhcg-scaled-pool-v545/final')]:
   env.update(SPACEPDHCG_GTOC12_CUDA_LIBRARY=core+'/libspacepdhcg_cuda.so',SPACEPDHCG_QOCO_LIBRARY=qoco+'/libqoco.so',LD_LIBRARY_PATH=core+':'+qoco+':/home/ubuntu/spacepdhcg-recovery-v152/cudss/lib:/usr/local/cuda/lib64')
   cmd=['/usr/local/cuda/bin/compute-sanitizer','--tool',('synccheck' if label=='previous' else 'racecheck'),'--error-exitcode','99',py,'-c',boot,test,'-x','-s','-q']
   with (root/(label+'.log')).open('x') as log:
    start=time.perf_counter();child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);report.update(stage=label,child_pid=child.pid);save();rc=child.wait(timeout=300)
   text=(root/(label+'.log')).read_text()
   report['cases'].append(dict(name=label,returncode=rc,seconds=time.perf_counter()-start,command=cmd,unknown_error_999='cudaErrorUnknown (error 999)' in text));save()
 report['complete']=True
except Exception as error:report['error']=repr(error)
save()
