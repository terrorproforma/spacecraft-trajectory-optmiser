// Saved-data schema and source identity only. No Kepler/trajectory propagation.
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { replayGaps, currentReplaySample, visibleSegmentRanges, sampleSourceLabel } from '../../../results/lambda/2026-09-06/visualiser/replay.js';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../../..');
const directory = process.argv[2] ? resolve(process.argv[2]) : resolve(here, 'dataset-b');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const read = async path => JSON.parse(await readFile(path, 'utf8'));
const fleet = await read(resolve(directory, 'fleet.json'));
const manifest = await read(resolve(directory, 'manifest.json'));
const mapping = await read(resolve(directory, 'source-display-map.json'));
const binding = await read(resolve(directory, 'checker-binding.json'));
const compute = await read(resolve(directory, 'compute.json'));
for (const [name, pin] of Object.entries(manifest.files)) {
  const bytes = await readFile(resolve(directory, name));
  assert.equal(bytes.length, pin.bytes);
  assert.equal(hash(bytes), pin.sha256);
}
for (const pin of Object.values(mapping.sources)) {
  const bytes = await readFile(resolve(root, pin.path));
  assert.equal(bytes.length, pin.bytes);
  assert.equal(hash(bytes), pin.sha256);
}
assert.equal(fleet.source.solution_sha256, '1f420928bbef8da91e3a6f8b74d3bf00039c78d4257215c103a484bc55bb22da');
for (const item of [binding, binding.independent, binding.official]) assert.equal(item.result_sha256, fleet.source.solution_sha256);
assert.equal(binding.independent.ok, true);
assert.equal(binding.official.ok, true);
assert.equal(fleet.score.total_collected_kg, binding.independent.total_mass_kg);
assert.equal(fleet.score.weighted_score_fixed_bonus_kg, binding.independent.weighted_score_fixed_bonus_kg);
assert.equal(fleet.ships.length, 24);
assert.equal(fleet.asteroids.length, 208);
assert.equal(fleet.score.ships, 24);
assert.equal(fleet.score.unique_asteroids, 208);
assert.equal(fleet.run_id, compute.fleet_run_id);
assert.equal(fleet.generated_by_commit, compute.commit);
assert.equal(compute.run_counts.checker_attempts, 2);
assert.equal(compute.run_counts.independent_full_fleet_checks, 2);
assert.equal(compute.run_counts.official_full_fleet_checks, 2);
assert.equal(compute.timing.wall_seconds_total, compute.timing.first_format_rejection_seconds + compute.timing.final_pass_seconds);
const base = await read(resolve(root, mapping.sources.base_fleet.path));
assert.deepEqual(fleet.ships.slice(0, 23), base.ships);
const oldIds = new Set(base.asteroids.map(a => a.id));
assert.deepEqual(fleet.asteroids.filter(a => oldIds.has(a.id)), base.asteroids);
let points = 0, events = 0, raw = 0;
for (const ship of fleet.ships) {
  assert.equal(ship.transcription.point_count, ship.events.length);
  assert.equal(ship.replay.point_count, ship.replay.points_txyz.length);
  assert.equal(ship.transcription.point_count, ship.transcription.points_txyz.length);
  for (const series of [ship.replay, ship.transcription]) {
    assert.equal(series.selected_indices.length, series.point_count);
    assert.match(series.original_sha256, /^[0-9a-f]{64}$/);
    series.points_txyz.forEach((p, i) => {
      assert.equal(p.length, 4);
      assert.ok(p.every(Number.isFinite));
      if (i) assert.ok(p[0] >= series.points_txyz[i - 1][0]);
    });
  }
  replayGaps(ship.replay);
  for (const [i, event] of ship.events.entries()) {
    assert.deepEqual(ship.transcription.points_txyz[i], [event.epoch_mjd, ...event.position_km]);
    assert.ok(ship.replay.points_txyz.some(p => p[0] === event.epoch_mjd));
    if (event.role === 'collect') raw += event.mass_delta_kg;
  }
  points += ship.replay.point_count;
  events += ship.events.length;
}
assert.ok(Math.abs(raw - fleet.score.total_collected_kg) < 1e-8);
assert.equal(Number(raw.toPrecision(6)), binding.official.total_mass_kg);
assert.equal(points, 11672);
assert.equal(events, 464);
const added = fleet.ships[23];
assert.equal(added.display_sample_kind, 'archived_event_states_only');
assert.match(sampleSourceLabel(added), /event positions only/);
assert.equal(added.events.length, 20);
assert.equal(added.final_mass_kg, added.events.at(-1).mass_after_kg);
assert.equal(added.final_mass_kg, 501.4432517332);
assert.equal(added.replay.point_count, 20);
assert.deepEqual(added.replay.gap_after_indices, Array.from({ length: 19 }, (_, i) => i));
assert.ok(added.asteroids.every(id => !oldIds.has(id)));
const state = { times: added.replay.points_txyz.map(p => p[0]), gapAfter: replayGaps(added.replay) };
assert.deepEqual(visibleSegmentRanges(20, 20, state.gapAfter), []);
for (let i = 0; i < 20; i++) {
  assert.equal(currentReplaySample(state, state.times[i]), i);
  if (i < 19) assert.equal(currentReplaySample(state, (state.times[i] + state.times[i + 1]) / 2), -1);
  const event = added.events[i], source = mapping.ship24.events[i];
  assert.deepEqual(added.replay.points_txyz[i], source.before_fields.slice(2, 6).map(Number));
  assert.equal(event.mass_before_kg, Number(source.before_fields[9]));
  assert.equal(event.mass_after_kg, Number(source.after_fields[9]));
}
const report = { passed: true, dataset: directory, fleet_sha256: manifest.files['fleet.json'].sha256,
  result_sha256: fleet.source.solution_sha256, preserved_ship_records: 23, new_event_points: 20,
  blank_unsampled_intervals: 19, ships: 24, asteroids: 208, total_display_points: points, events,
  saved_data_checks_only: true, numerical_propagation_calls: 0, GPU_calls: 0 };
await writeFile(resolve(here, process.argv[2] ? 'installed-validation.json' : 'schema-validation.json'), `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify(report));
