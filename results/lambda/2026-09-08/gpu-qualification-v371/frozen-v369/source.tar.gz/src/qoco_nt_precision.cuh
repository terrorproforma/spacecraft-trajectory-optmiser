#pragma once
namespace qoco_cone_arithmetic {
__device__ DD divide(DD a, DD b) {
    double q1=a.hi/b.hi;
    DD r=add(a,neg(mul(b,DD(q1))));
    double q2=r.hi/b.hi;
    r=add(r,neg(mul(b,DD(q2))));
    return add(add(DD(q1),DD(q2)),DD(r.hi/b.hi));
}
__device__ DD root(DD a) {
    double h=sqrt(a.hi);
    if(!(h>0.0) || !isfinite(h)) return DD(h);
    DD r=add(a,neg(mul(DD(h),DD(h))));
    return add(DD(h),divide(r,DD(2.0*h)));
}
__device__ DD euclidean(const double* s,const double* z,int n) {
    DD sum;
    for(int j=0;j<n;++j)sum=add(sum,mul(DD(s[j]),DD(z[j])));
    return sum;
}
}
