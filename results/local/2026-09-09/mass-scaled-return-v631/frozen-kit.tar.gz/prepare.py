"""Parse and bind the exact certified return; no propagation or optimization."""

from __future__ import annotations

import ctypes
import hashlib
import importlib.util
import json
import math
import os
import sys
import tarfile
import types
from pathlib import Path

import numpy as np

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
PRIOR = ROOT / "build/performance/fleet-budgeted-prefix-v630"
CASE = PRIOR / "output/local-v794-ship10-rank0000"
CURRENT = ROOT / "results/local/2026-09-09/mass-budgeted-frontier-v629"
RESULT_SHA = "765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da"
PRIOR_READY_SHA = "a145167e71d52a709bd80bf3af87458fd824c13c14484e702eb326f27ae60643"
NATIVE = ROOT / "build/performance/gpu-route-ephemeris-v630"
NATIVE_MANIFEST_SHA = "7435b392a5faceff50db4361bab287fb3ce98b1b37aa93d2d5d633c0a9e68a14"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def pin(path):
    path = Path(path)
    payload = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "sha256": sha(payload), "bytes": len(payload)}


def load_parser(source):
    """Load only the two frozen parsing modules, never the live package."""
    package = types.ModuleType("v631_frozen")
    package.__path__ = [str(source)]
    sys.modules[package.__name__] = package
    for name in ("constants", "solution"):
        spec = importlib.util.spec_from_file_location(f"v631_frozen.{name}", source / f"{name}.py")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
    return sys.modules["v631_frozen.solution"]


def map_zoh(arcs, epochs):
    """Preserve every nonzero interval exactly or reject the source mapping."""
    epochs = np.asarray(epochs, dtype=np.float64)
    if epochs.ndim != 1 or len(epochs) < 2 or not np.all(np.diff(epochs) > 0):
        raise ValueError("strict finite node grid required")
    if not np.isfinite(epochs).all():
        raise ValueError("strict finite node grid required")
    thrust = np.zeros((len(epochs), 3), dtype=np.float64)
    used = np.zeros(len(epochs) - 1, dtype=bool)
    mapping = []
    for arc in arcs:
        if arc.end <= epochs[0] or arc.start >= epochs[-1]:
            continue
        if not epochs[0] <= arc.start < arc.end <= epochs[-1]:
            raise ValueError("source burn crosses the requested leg")
        values = np.asarray([sample.thrust for sample in arc.interior], dtype=np.float64)
        if values.ndim != 2 or values.shape[1] != 3 or len(values) < 2:
            raise ValueError("source burn requires at least two vector samples")
        if not np.isfinite(values).all() or not np.all(values == values[0]):
            raise ValueError("source arc is not an exact constant ZOH control")
        left, right = np.flatnonzero(epochs == arc.start), np.flatnonzero(epochs == arc.end)
        if len(left) != 1 or len(right) != 1:
            raise ValueError("source boundary absent from exact solver grid")
        a, b = int(left[0]), int(right[0])
        if used[a:b].any():
            raise ValueError("overlapping source burns")
        used[a:b] = True
        thrust[a:b] = values[0]
        mapping.append(
            {
                "start_mjd": arc.start,
                "end_mjd": arc.end,
                "first_interval": a,
                "exclusive_last_interval": b,
                "thrust_n": values[0].tolist(),
                "source_sample_lines": [x.line_number for x in arc.samples],
            }
        )
    return thrust, used, mapping


def mass_scaling(source_mass, source_final_mass, target_mass, minimum_final_mass):
    """Algebraic reference only; production scaling must execute in CUDA."""
    values = (source_mass, source_final_mass, target_mass, minimum_final_mass)
    if not all(math.isfinite(x) and x > 0 for x in values):
        raise ValueError("finite positive physical masses required")
    if not source_final_mass <= source_mass or not minimum_final_mass <= target_mass:
        raise ValueError("source or target mass order is impossible")
    scale = target_mass / source_mass
    final_mass = scale * source_final_mass
    fuel = scale * (source_mass - source_final_mass)
    shortfall = minimum_final_mass - final_mass
    return {
        "source_initial_mass_kg": source_mass,
        "source_final_mass_kg": source_final_mass,
        "target_initial_mass_kg": target_mass,
        "minimum_final_mass_kg": minimum_final_mass,
        "scale": scale,
        "reference_final_mass_kg": final_mass,
        "reference_propellant_kg": fuel,
        "required_fuel_reduction_kg": shortfall,
        "required_fuel_reduction_fraction": shortfall / fuel if fuel else None,
        "seed_satisfies_final_mass": bool(final_mass >= minimum_final_mass),
        "arithmetic_scope": "Analytic mass/thrust homothety; no new trajectory propagation",
    }


def roundoff_comparison(archived, generated):
    old, new = np.asarray(archived), np.asarray(generated)
    limit = 64 * np.finfo(np.float64).eps * max(1.0, float(np.abs(new).max()))
    difference = old - new
    return {
        "archived": old.tolist(),
        "generated": new.tolist(),
        "difference": difference.tolist(),
        "maximum_absolute_difference": float(np.abs(difference).max()),
        "existing_64eps_limit": limit,
        "within_representation_guard": bool(np.all(np.abs(difference) <= limit)),
    }


def sections(payload):
    output = {}
    for line in payload.splitlines(keepends=True):
        row = line.split()
        if row:
            number = int(row[0])
            output[number] = output.get(number, b"") + line
    return output


def main():
    if not __debug__ or os.environ.get("CUDA_VISIBLE_DEVICES") != "":
        raise RuntimeError(
            "CPU-only preparation requires assertions and CUDA_VISIBLE_DEVICES empty"
        )

    def blocked(*args, **kwargs):
        raise AssertionError("native loading is prohibited during parse-only preparation")

    ctypes.CDLL = blocked
    assert sha((PRIOR / "ready.json").read_bytes()) == PRIOR_READY_SHA
    assert sha((NATIVE / "manifest.json").read_bytes()) == NATIVE_MANIFEST_SHA
    native = read(NATIVE / "manifest.json")
    assert native["complete"] and native["passed"]
    source = KIT / "source"
    inputs = KIT / "inputs"
    source.mkdir()
    inputs.mkdir()
    host_index = read(PRIOR / "host-index.json")
    for name in ("constants.py", "solution.py"):
        key = f"spacepdhcg/gtoc12/{name}"
        payload = (PRIOR / "host" / key).read_bytes()
        assert sha(payload) == host_index[key] == native["sources"][f"src/{key}"]
        (source / name).write_bytes(payload)
    archive = NATIVE / "source.tar.gz"
    if not archive.exists():
        archive = ROOT / "results/local/2026-09-09/fleet-budgeted-prefix-v630/native-source.tar.gz"
    assert sha(archive.read_bytes()) == native["source_archive_sha256"]
    wanted = {"cpp/cuda/internal/gtoc12_seed.cuh", "cpp/cuda/src/gtoc12_scvx.cu"}
    found = set()
    with tarfile.open(archive, "r|gz") as data:
        for member in data:
            if member.name in wanted:
                payload = data.extractfile(member).read()
                assert sha(payload) == native["sources"][member.name]
                (source / Path(member.name).name).write_bytes(payload)
                found.add(member.name)
    assert found == wanted
    parser = load_parser(source)
    payload = (CURRENT / "Result.txt").read_bytes()
    assert sha(payload) == RESULT_SHA
    binding = read(CURRENT / "checker-binding.json")
    assert binding["result_sha256"] == RESULT_SHA
    assert all(
        binding[x]["ok"] and binding[x]["result_sha256"] == RESULT_SHA
        for x in ("independent", "official")
    )
    solution = parser.parse_solution(payload.decode("utf-8"))
    assert solution.ship_count == 23
    ship = next(x for x in solution.ships if x.ship_id == 10)
    departure, arrival = ship.events[-2:]
    assert (departure.event_id, departure.epoch, arrival.event_id, arrival.epoch) == (
        17126,
        69263.0,
        -3,
        69713.0,
    )
    assert np.array_equal(departure.before.position, departure.after.position)
    assert np.array_equal(departure.before.velocity, departure.after.velocity)
    protocol = read(PRIOR / "protocol.json")
    candidate = next(x for x in protocol["candidates"] if x["ship"] == 10)
    assert (
        candidate["request_sha256"]
        == "dcfc0573a6d96ca76120347a4e22ba91f33bbd53bfc1c59704c0481a8053a6af"
    )
    settings = protocol["settings"]
    assert settings["hold"] == "zoh" and settings["node_days"] == 2.0
    assert settings["max_iterations"] == 40 and settings["polish_iterations"] == 4
    epochs = np.arange(departure.epoch, arrival.epoch + 1.0, 2.0)
    assert epochs.shape == (226,) and epochs[-1] == arrival.epoch
    thrust, used, mapping = map_zoh(ship.burns, epochs)
    initial = np.r_[departure.after.position, departure.after.velocity, departure.after.mass]
    boundary = read(CASE / "legs/17/boundary.json")["effective"]
    assert [boundary["departure_epoch"], boundary["arrival_epoch"]] == [
        departure.epoch,
        arrival.epoch,
    ]
    assert not boundary["free_departure_vinf"] and boundary["free_arrival_vinf"]
    analysis = mass_scaling(
        initial[6], arrival.before.mass, boundary["initial_mass"], boundary["minimum_final_mass"]
    )
    comparisons = {
        "departure_position_km": roundoff_comparison(initial[:3], boundary["departure_position"]),
        "departure_velocity_km_s": roundoff_comparison(
            initial[3:6], boundary["departure_velocity"]
        ),
        "arrival_position_km": roundoff_comparison(
            arrival.before.position, boundary["arrival_position"]
        ),
    }
    assert all(x["within_representation_guard"] for x in comparisons.values())
    impulse = math.fsum(
        float(np.linalg.norm(t)) * float(dt) * 86400.0
        for t, dt in zip(thrust[:-1], np.diff(epochs), strict=True)
    )
    fuel = impulse / (4000.0 * 9.80665)
    assert abs(fuel - (initial[6] - arrival.before.mass)) < 1e-7
    maximum = float(np.linalg.norm(thrust, axis=1).max())
    assert maximum <= 0.6
    analysis.update(
        {
            "source_control_integrated_propellant_kg": fuel,
            "source_control_vs_event_fuel_difference_kg": fuel - (initial[6] - arrival.before.mass),
            "source_maximum_thrust_n": maximum,
            "scaled_reference_maximum_thrust_n": maximum * analysis["scale"],
        }
    )
    np.savez_compressed(
        inputs / "archived-return.npz",
        initial_state=initial,
        thrust_n=thrust,
        node_epochs_mjd=epochs,
        arrival_position=arrival.before.position,
        arrival_spacecraft_velocity=arrival.before.velocity,
        arrival_body_velocity=np.asarray(boundary["arrival_velocity"]),
        source_sha256=np.array(RESULT_SHA),
        target_initial_mass_kg=np.array(boundary["initial_mass"]),
    )
    (inputs / "ship10-section.txt").write_bytes(sections(payload)[10])
    (inputs / "candidate-plan.json").write_bytes(
        (PRIOR / "inputs" / candidate["input_file"]).read_bytes()
    )
    (inputs / "checker-binding.json").write_bytes((CURRENT / "checker-binding.json").read_bytes())
    write(inputs / "failed-boundary.json", boundary)
    write(inputs / "settings.json", settings)
    write(inputs / "burn-mapping.json", mapping)
    prescribed = read(inputs / "candidate-plan.json")
    cargo = {int(k): v for k, v in prescribed["collected_mass_kg"].items()}
    assert (
        len(cargo) == 9
        and abs(sum(cargo.values()) + 500.0 - boundary["minimum_final_mass"]) < 1e-10
    )
    prefix = []
    for number in range(17):
        record = read(CASE / f"legs/{number:02d}/leg-result.json")
        assert record["certified"] and record["certificate"] is not None
        prefix.append(
            {
                "index": number,
                "from": record["from"],
                "to": record["to"],
                "departure": record["departure"],
                "arrival": record["arrival"],
                "initial_mass_kg": record["initial_mass_kg"],
                "final_mass_kg": record["certificate"]["final_mass_kg"],
                "record": pin(CASE / f"legs/{number:02d}/leg-result.json"),
            }
        )
    wait = read(CASE / "wait-summary.json")
    assert len(wait) == 1 and wait["wait-08"]["passed"]
    handoff = prefix[-1]["final_mass_kg"] + cargo[17126]
    assert handoff == boundary["initial_mass"]
    failure = read(CASE / "legs/17/leg-result.json")
    assert not failure["certified"] and failure["certificate"] is None
    external = [
        pin(CURRENT / "Result.txt"),
        pin(CURRENT / "checker-binding.json"),
        pin(PRIOR / "ready.json"),
        pin(PRIOR / "protocol.json"),
        pin(PRIOR / "profile.json"),
        pin(PRIOR / "host-index.json"),
        pin(NATIVE / "manifest.json"),
        pin(archive),
    ]
    external.extend(pin(path) for path in sorted(CASE.rglob("*")) if path.is_file())
    write(KIT / "external-evidence.json", external)
    report = {
        "status": "prepared_no_execution",
        "source_head": "106e0cdc98b891e0633cdd6a4fe589f200de3561",
        "scope_counts": {
            "parsed_fleet_files": 1,
            "parsed_ships": 23,
            "saved_prefix_flight_certificates": 17,
            "saved_prefix_wait_certificates": 1,
            "new_trajectory_propagations": 0,
            "Lambert_calls": 0,
            "native_solver_calls": 0,
            "GPU_calls": 0,
            "new_verifier_calls": 0,
        },
        "current_fleet": binding,
        "candidate": candidate,
        "fixed_cargo_kg": cargo,
        "candidate_prefix": prefix,
        "prefix_wait": wait,
        "actual_return_mass_handoff_kg": handoff,
        "schedule": {
            "from": 17126,
            "to": 0,
            "departure_mjd": 69263.0,
            "arrival_mjd": 69713.0,
            "node_count": 226,
            "intervals": 225,
            "node_days": 2.0,
            "hold": "zoh",
            "nonzero_intervals": int(used.sum()),
            "burn_arcs": len(mapping),
            "coast_intervals": int((~used).sum()),
            "mesh_refinement_required": False,
            "resampled_or_interpolated_controls": False,
        },
        "reference_mass_scaling": analysis,
        "boundary_representation": comparisons,
        "arrival_velocity_policy": (
            "Use saved generated Earth body velocity; archived spacecraft velocity is "
            "free-arrival output, not a boundary body velocity."
        ),
        "failed_cold_return": {
            "status": failure["status"],
            "diagnostic": failure["diagnostic"],
            "iterations": failure["solution"]["iterations"],
            "accepted_iterations": failure["solution"]["accepted_iterations"],
            "max_defect": failure["solution"]["max_defect"],
            "infeasibility_certificate": False,
            "full_record": pin(CASE / "legs/17/leg-result.json"),
        },
        "seed_semantics": (
            "Upload archived initial state and thrust unchanged. CUDA applies target/source "
            "mass factor before existing ZOH rollout. No CPU trajectory upload or Python "
            "production scaling."
        ),
        "acceptance": (
            "The scaled reference fails the final-mass requirement. Only a newly optimized, "
            "independently certified return plus both complete-fleet checkers may qualify "
            "the candidate. The archive source certificate is not a candidate certificate."
        ),
    }
    write(KIT / "report.json", report)
    write(
        KIT / "preparation-index.json",
        {
            str(p.relative_to(KIT)): sha(p.read_bytes())
            for p in sorted(KIT.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts
        },
    )
    print(
        json.dumps(
            {"status": report["status"], "schedule": report["schedule"], "mass_scaling": analysis},
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
