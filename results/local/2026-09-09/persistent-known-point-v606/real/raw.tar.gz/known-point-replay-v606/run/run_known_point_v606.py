"""Run bounded native steps from independently qualified points, preserving failed outcomes."""

import argparse
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import shutil
import subprocess
import time
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--manifest", type=Path, required=True)
parser.add_argument("--manifest-sha256", required=True)
parser.add_argument("--executable", type=Path, required=True)
parser.add_argument("--tiny-report", type=Path, required=True)
args = parser.parse_args()
assert sha(args.manifest) == args.manifest_sha256
manifest = json.loads(args.manifest.read_text())
assert manifest["complete"] and sha(args.executable) == manifest["executable_sha256"]
core = Path(manifest["immutable_core_path"])
assert sha(core) == manifest["immutable_core_sha256"]
assert sha(core) == "d4b0bea9672bb0cea612b7d4e8db5d448f1b79b9831be5710723276edd128633"
assert json.loads(args.tiny_report.read_text())["complete"]
root = Path(__file__).resolve().parent / "known-point-replay-v606"
output = root / "run"
encoded = json.loads((root / "encoded-points.json").read_text())
assert encoded["complete"]
spec = importlib.util.spec_from_file_location("audit", root / "source/audit_persistent_snapshot.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
environment = {
    k: v
    for k, v in os.environ.items()
    if not k.startswith(("SPACEPDHCG_", "QOCO_", "PDHCG_", "CUDA_VISIBLE_DEVICES"))
}
environment.update(
    LD_LIBRARY_PATH=f"{core.parent}:/usr/local/cuda-12.8/lib64",
    CUDA_VISIBLE_DEVICES="0",
    OPENBLAS_NUM_THREADS="1",
    OMP_NUM_THREADS="1",
)
report = {
    "complete": False,
    "pid": os.getpid(),
    "scope": "known-qualified-point mapping, stopping and local stability; not cold solve speed",
    "source_pin": manifest["frozen_commit"],
    "manifest_sha256": args.manifest_sha256,
    "executable_sha256": sha(args.executable),
    "library_sha256": sha(core),
    "tiny_report_sha256": sha(args.tiny_report),
    "point_manifest_sha256": sha(root / "encoded-points.json"),
    "iteration_budgets": [1, 1000],
    "bootstrap_iteration_budget": 1,
    "requested_tolerance": 1e-9,
    "deadline_seconds_per_solve_phase": 10,
    "cases": [],
}


def save():
    path = output / "report.tmp"
    path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    path.replace(output / "report.json")


def records(lines, prefix):
    return [json.loads(line[len(prefix) + 1 :]) for line in lines if line.startswith(prefix + " ")]


with Path("/home/angus/.spacepdhcg-gpu.lock").open("a") as lock:
    print(json.dumps({"pid": os.getpid(), "stage": "waiting_for_shared_gpu_lock"}), flush=True)
    fcntl.flock(lock, fcntl.LOCK_EX)
    output.mkdir(exist_ok=False)
    shutil.copyfile(__file__, output / Path(__file__).name)
    shutil.copyfile(args.manifest, output / "adapter-manifest.json")
    shutil.copyfile(args.tiny_report, output / "tiny-report.json")
    report["gpu"] = subprocess.run(
        ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    save()
    for point in encoded["points"]:
        label = point["label"]
        snapshot = root / "inputs" / (label + ".txt")
        initial = root / "inputs" / (label + "-initial.txt")
        assert sha(snapshot) == point["snapshot_sha256"]
        assert sha(initial) == point["encoded_sha256"]
        problem = audit.load_snapshot(snapshot)
        for iterations in (1, 1000):
            for folded in (False, True) if label == "conditioning" else (True, False):
                name = f"{label}-{'folded' if folded else 'generic'}-{iterations}"
                command = [
                    str(args.executable),
                    str(snapshot),
                    "--initial-point",
                    str(initial),
                    "--tolerance",
                    "1e-9",
                    "--iterations",
                    str(iterations),
                    "--deadline-seconds",
                    "10",
                    "--mode",
                    "cold",
                    "--repeats",
                    "1",
                ]
                if folded:
                    command.append("--fold-singleton-bounds")
                row = {
                    "name": name,
                    "label": label,
                    "folded": folded,
                    "iterations_requested": iterations,
                    "command": command,
                    "input_sha256": sha(snapshot),
                    "point_sha256": sha(initial),
                }
                log = output / (name + ".log")
                report["stage"] = name
                save()
                began = time.perf_counter()
                with log.open("x") as stream:
                    try:
                        result = subprocess.run(
                            command,
                            env=environment,
                            stdout=stream,
                            stderr=subprocess.STDOUT,
                            timeout=45,
                        )
                        row.update(returncode=result.returncode, timed_out=False)
                    except subprocess.TimeoutExpired:
                        row.update(returncode=None, timed_out=True)
                row["process_seconds"] = time.perf_counter() - began
                row["log_sha256"] = sha(log)
                lines = log.read_text().splitlines()
                meta = records(lines, "PERSISTENT_REPLAY_META")
                seeds = records(lines, "PERSISTENT_REPLAY_INITIAL_POINT")
                prestep = records(lines, "PERSISTENT_REPLAY_PRESTEP")
                final = records(lines, "PERSISTENT_REPLAY")
                row["metadata"] = meta
                row["prestep"] = prestep
                row["initial_point_reports"] = [
                    {
                        k: v
                        for k, v in seed.items()
                        if k not in ("x", "y", "z", "s", "x_solver", "dual_solver")
                    }
                    for seed in seeds
                ]
                row["solver_reports"] = [
                    {k: v for k, v in result.items() if k not in ("x", "y", "z", "s", "x_solver")}
                    for result in final
                ]
                try:
                    row["audits"] = audit.audit_log(
                        problem,
                        log,
                        sha(snapshot),
                        backend="persistent",
                        coordinates="original",
                        record_prefix="PERSISTENT_REPLAY",
                    )
                    row["initial_reference_external_audits"] = [
                        audit.audit(problem, seed, backend="persistent", coordinates="original")
                        for seed in seeds
                    ]
                except (ValueError, KeyError) as error:
                    row["audit_error"] = str(error)
                    row["audits"] = []
                row["qualified"] = sum(result["qualified"] for result in row["audits"])
                row["raw_record_count"] = len(final)
                row["runtime_identity_matches"] = len(meta) == 1 and (
                    meta[0]["library_sha256"] == report["library_sha256"]
                    and meta[0]["source_commit"] == report["source_pin"]
                    and meta[0]["source_sha256"] == manifest["compiled_snapshot_source_sha256"]
                    and meta[0]["initial_point_sha256"] == sha(initial)
                    and meta[0]["fold_singleton_bounds"] == folded
                )
                fields = {
                    "primal": "primal",
                    "dual": "dual",
                    "gap": "gap",
                    "objective": "objective",
                    "dual_objective": "dual_objective",
                    "block_complementarity_normalized": "complementarity_max_relative",
                }
                row["independent_native_audit_agrees"] = (
                    bool(final)
                    and len(final) == len(row["audits"])
                    and all(
                        native["kkt_qualified_original"] == independent["passes_common_kkt_gate"]
                        and all(
                            math.isclose(
                                native["audit"][nk], independent[ik], rel_tol=1e-9, abs_tol=1e-12
                            )
                            for nk, ik in fields.items()
                        )
                        for native, independent in zip(final, row["audits"], strict=True)
                    )
                )
                if len(final) == len(seeds) == 1:
                    row["maximum_primal_change_from_seed"] = float(
                        np.max(
                            np.abs(
                                np.asarray(final[0]["x_solver"]) - np.asarray(seeds[0]["x_solver"])
                            )
                        )
                    )
                report["cases"].append(row)
                save()
                print(
                    json.dumps(
                        {
                            key: row[key]
                            for key in (
                                "name",
                                "returncode",
                                "qualified",
                                "process_seconds",
                                "runtime_identity_matches",
                                "independent_native_audit_agrees",
                            )
                        }
                    ),
                    flush=True,
                )
    report.update(complete=True, stage="complete")
    save()
print(json.dumps({"complete": True, "report": str(output / "report.json")}), flush=True)
