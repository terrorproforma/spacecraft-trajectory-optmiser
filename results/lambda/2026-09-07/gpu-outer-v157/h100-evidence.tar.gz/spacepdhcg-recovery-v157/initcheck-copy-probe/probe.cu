
#include <cuda_runtime.h>
#include <atomic>
#include <chrono>
#include <thread>
#include <cstdio>
#include <cstdlib>
#define CHECK(x) do {auto e=(x);if(e!=cudaSuccess){std::fprintf(stderr,"CUDA %s\n",cudaGetErrorString(e));std::exit(2);}}while(0)
struct Held{std::atomic<bool> entered{false},release{false},expired{false};};
void CUDART_CB hold(void* p){auto& h=*static_cast<Held*>(p);h.entered=true;while(!h.release.load())std::this_thread::yield();}
int main(){
 cudaStream_t stream;CHECK(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));
 double *a,*b;CHECK(cudaMalloc(&a,64));CHECK(cudaMalloc(&b,64));
 CHECK(cudaMemsetAsync(a,0,64,stream));CHECK(cudaMemsetAsync(b,0,64,stream));CHECK(cudaStreamSynchronize(stream));
 Held h;CHECK(cudaLaunchHostFunc(stream,hold,&h));
 std::thread watchdog([&]{auto end=std::chrono::steady_clock::now()+std::chrono::seconds(3);while(!h.release.load()&&std::chrono::steady_clock::now()<end)std::this_thread::yield();if(!h.release.load()){h.expired=true;h.release=true;}});
 while(!h.entered.load()&&!h.expired.load())std::this_thread::yield();
 auto start=std::chrono::steady_clock::now();auto status=cudaMemcpyAsync(b,a,64,cudaMemcpyDeviceToDevice,stream);
 double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
 bool expired=h.expired.load();h.release=true;watchdog.join();CHECK(status);CHECK(cudaStreamSynchronize(stream));
 CHECK(cudaFree(a));CHECK(cudaFree(b));CHECK(cudaStreamDestroy(stream));
 std::printf("D2D_ASYNC seconds=%.6f watchdog_expired=%d\n",seconds,int(expired));return expired?1:0;
}
