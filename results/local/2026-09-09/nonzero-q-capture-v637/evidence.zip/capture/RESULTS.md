# HCW N20 capture result - v637

The one approved host-only capture completed and its saved native/QOCO map validated. No solver, proximal routine, factorization or GPU call ran. This is an assembled coefficient fixture, not an optimized or certified trajectory.

- One compiler process: 1.625722 s wall, return0. One exporter process: 0.023756 s wall, return0; one native host assembly and20 existing HCW reference-step evaluations. No retries. Both process cleanup checks and final descendant inventory are empty.
- Actual input:186 variables,132 equalities,80 conic rows,20 SOC4. All186 P values are positive; all1212 A structural entries (including signed zeros),60 G entries and native bounds/cones are retained. The saved validator confirms native Q/A/c bits and the F-to-G row/sign map.
- Canonical QP objective constant remains0. The separate physical tracking reference constant is 9.2595168749999953e-06, metadata only. It is excluded from the snapshot and original KKT gap.
- All five saved persistent/QOCO/cuDSS artifacts were rehashed against validated manifests and matched. They were not loaded or executed. Source, compiler, executable and host math-library hashes are retained.
- Physical initial/target states, times, reference/control arrays and straight-line objective references are exported. The declared zero candidate is labeled separately from backend-generated initialization. Final solver vectors are explicitly unavailable (not_run).

| Artifact | SHA256 |
|---|---|
| execution-a/capture/snapshot.txt | 4b226f55a8ea9e43c1b6719f2c80c66334ed35177127e3c122657617329f087d |
| execution-a/capture/native.json | a04e231b0d2381216accaf5d798fa55808b844f2d6acc1ad3042f91b4979246b |
| execution-a/capture/context.json | 4c4b2733435bf41c7960e4ff214d181a2f92fdf2d63d97c0bdb1f0f0d45cd352 |
| execution-a/capture/capture-report.json | 242f599dd3a774d0cf6d714733fa7371eb452664f37b292181e5e1aded461b36 |
| execution-a/capture-validation.json | 5735dcc6ab5b020afb3c86759f4367db065e997a92df620f0332f8747326198c |
| execution-a/report.json | 2d5638d407c82bb3fcc63d3fc841d4c745de3e144f54091eb229a0daa96e2457 |

The coefficient bytes are now suitable for a separately reviewed matched-solver protocol. Consume the same snapshot for each method, retain all original gates and full final x/y/z/s, and count setup plus every inner iteration. The validated local persistent frontend uses explicit quadratic gradients; an original PDHCG-CG comparison requires its actual reviewed frontend. A process exit, map check or free reference rollout is not convergence evidence.
