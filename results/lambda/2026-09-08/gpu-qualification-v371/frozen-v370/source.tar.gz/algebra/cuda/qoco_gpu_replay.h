// SPDX-License-Identifier: Apache-2.0
#pragma once
#include "qoco.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct QocoGpuCompletion {
    int abi_version, status, iterations, ir_iterations, step_ir_iterations, restored;
    double primal_residual, dual_residual, gap, objective, dynamic_reg;
} QocoGpuCompletion;
typedef struct QocoGpuOutput {
    const QocoGpuCompletion* completion;
    const double *x, *y, *s, *z;
    int n, p, m;
} QocoGpuOutput;
// Prime with a synchronous graph-enabled qoco_solve first. Replay requires
// captured initialisation AND terminal handling with unchanged static settings.
// Numeric values/scalings may change in their existing buffers before replay.
// Queues on the supplied CUDA stream without downloading or waiting for results.
// GPU consumers must use that same stream. Before changing streams, updating,
// or using any other solver API, finish_device must complete all queued work.
// Same-stream replays can be chained, with consumers between them; outputs are
// overwritten by the next replay. Host sol metadata is invalidated, not updated.
// Current host settings supply each replay's tolerances/budgets/dynamic reg/warm
// flag. No implicit host update from the preceding device solve is performed.
// Returns 0 queued, 1 invalid arguments/settings, 2 unprepared/stale/incompatible,
// 3 pending on another stream, 4 CUDA error. Failure clears the output descriptor.
int qoco_gpu_ipm_replay_device(QOCOSolver*, void* stream, QocoGpuOutput*);
// Waits for the replay stream INCLUDING subsequently queued GPU consumers.
// Does not download or materialise legacy host solution metadata.
int qoco_gpu_ipm_finish_device(QOCOSolver*);
// Queued numeric updates require one successful synchronous numeric update first.
// The borrowed nine-double result contains k,kinv,three min/max pairs,invalid.
// Queue updated replay and consumers on the SAME stream, then finish both APIs.
// No other solver APIs may run while update/replay work remains pending.
// materialize=1 refreshes legacy host scale/range metadata before host API use;
// materialize=0 waits only and permits subsequent device-update/replay chains.
// An invalid update causes updated replay to skip all IPM factor/solve work and
// publish numerical-error completion. Rebuild after such an update failure.
int qoco_gpu_update_numeric_device(void*,const double*,cudaStream_t,const double**);
int qoco_gpu_finish_numeric_update(void*,int materialize);
int qoco_gpu_ipm_replay_updated_device(QOCOSolver*,void*,const double*,QocoGpuOutput*);
// Emit a prepared solve into an existing graph, including a conditional body.
// No graph is executed. All dependencies must belong to graph. Outputs and
// solver-owned buffers must remain alive until every executable using the nodes
// is destroyed. No other solver API may run during that ownership period;
// launches using this workspace must be serialized. Destroy external graphs
// and complete their streams before settings changes, replay or cleanup.
// Capture/execute on the solver's original host thread and CUDA device. Call
// after synchronous priming and finish_device, with no active stream capture.
// A borrowed numeric_update may supply changing scaling/invalid values on GPU.
// Null uses host settings captured at emission. Returned node gates consumers.
// Each enclosing loop iteration resets IPM control/counters on GPU. No report
// downloads or host callbacks are emitted. Host solution metadata is unchanged.
// Returns 0 emitted, 1 invalid, 2 unprepared/pending/stale, 4 CUDA error.
int qoco_gpu_ipm_emit_graph(QOCOSolver*,cudaGraph_t,const cudaGraphNode_t*,size_t,
    const double* numeric_update,QocoGpuOutput*,cudaGraphNode_t* completion_node);
// Capture the prepared numeric-update kernels on an actively capturing stream.
// Same exclusive external-graph ownership rules as emit_graph. Prime numeric
// scaling synchronously first. Output is the borrowed nine-double device packet.
int qoco_gpu_capture_numeric_update(void*,const double*,cudaStream_t,const double**);
#ifdef __cplusplus
}
#endif
