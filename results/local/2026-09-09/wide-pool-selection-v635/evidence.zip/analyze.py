"""Saved v835 plans, fleet events and bonus arithmetic only; no production imports."""
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
import hashlib
import json
import math
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
POOL = ROOT / 'results/lambda/2026-09-09/gpu-beam-expansion-v835'
FLEET = ROOT / 'results/local/2026-09-09/fleet-addition-v633'
FINAL_SHA = '1f420928bbef8da91e3a6f8b74d3bf00039c78d4257215c103a484bc55bb22da'
BONUS_SHA = 'e8a3795e599556ed5b66713ab1fa176de93ef37f93cb2a4a87d561539b1caa21'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def read(path):
    return json.loads(path.read_bytes())


def write(name, value):
    with (HERE / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def request(plan):
    assert plan['self_cleaning'] and not plan['foreign_deploy_epochs'] and not plan['orphaned']
    out = {'flights': [(int(x['from']), int(x['to']), float(x['t0']), float(x['tf']))
                      for x in plan['legs'] if x['role'] != 'camp']}
    for target, key in [('deploy', 'deploy_epochs'), ('collect', 'collect_epochs'), ('cargo', 'collected_mass_kg')]:
        out[target] = sorted((int(k), float(v)) for k, v in plan[key].items())
    assert set(dict(out['deploy'])) == set(dict(out['collect'])) == set(dict(out['cargo'])) == set(plan['asteroids'])
    assert out['flights'][0][0] == out['flights'][-1][1] == 0
    return out


def fleet_inventory(payload, weights):
    parts = defaultdict(list)
    for line in payload.splitlines():
        tokens = line.split()
        assert tokens
        parts[int(tokens[0])].append(tokens)
    result = {}
    for ship, rows in parts.items():
        events = [row for row in rows if int(row[1]) != -1]
        assert len(events) % 2 == 0
        collected, epochs, deployments = {}, [], {}
        for before, after in zip(events[::2], events[1::2]):
            assert before[:3] == after[:3]
            body = int(before[1])
            t = Decimal(before[2].decode())
            gain = Decimal(after[9].decode())-Decimal(before[9].decode())
            epochs.append((body, float(t)))
            if body > 0:
                if gain > 0:
                    assert body not in collected
                    collected[body] = gain
                else:
                    assert gain == -40 and body not in deployments
                    deployments[body] = t
        assert set(collected) == set(deployments)
        raw = sum(collected.values(), Decimal(0))
        weighted = sum((weights[k]*v for k, v in collected.items()), Decimal(0))
        result[ship] = dict(raw=raw, weighted=weighted, cargo=collected,
            asteroids=set(collected), first_leg=(0, epochs[1][0], epochs[0][1], epochs[1][1]))
    assert set(result) == set(range(1, 25))
    return result


def main():
    if not __debug__:
        raise RuntimeError('Assertions must remain enabled')
    assert not (HERE / 'findings.json').exists(), 'Preserve prior saved-data outputs'
    pins, members = {}, {}
    top = read(POOL / 'sha256-manifest.json')
    all_plans, all_narrow, reports = {}, {}, {}
    wanted = {'wide/report.json', 'wide/run.py', 'wide/fit.json'}
    for ship in (10, 21):
        wanted |= {f'wide/ship-{ship:02d}/plans.json', f'wide/ship-{ship:02d}/report.json',
                   f'v831/warm-reuse/ship-{ship:02d}/plans.json'}
    for hardware in ('local', 'h100'):
        archive_path = POOL / (hardware+'.tar.gz')
        manifest_path = POOL / (hardware+'-files.json')
        for path in (archive_path, manifest_path):
            assert sha(path.read_bytes()) == top[path.name], path.name
            pins[path.relative_to(ROOT).as_posix()] = top[path.name]
        manifest = read(manifest_path)
        found = {}
        with tarfile.open(archive_path, 'r|gz') as archive:
            for member in archive:
                if member.name not in wanted:
                    continue
                assert member.isfile()
                value = archive.extractfile(member).read()
                assert {'sha256': sha(value), 'bytes': len(value)} == manifest[member.name]
                found[member.name] = value
                members[hardware+'/'+member.name] = manifest[member.name]
        assert set(found) == wanted
        reports[hardware] = json.loads(found['wide/report.json'])
        assert reports[hardware]['complete'] and reports[hardware]['success']
        for ship in (10, 21):
            all_plans[hardware, ship] = json.loads(found[f'wide/ship-{ship:02d}/plans.json'])
            all_narrow[hardware, ship] = json.loads(found[f'v831/warm-reuse/ship-{ship:02d}/plans.json'])
            assert len(all_plans[hardware, ship]) == (1020 if ship == 10 else 940)
            assert len(all_narrow[hardware, ship]) == (517 if ship == 10 else 472)
    old_package = ROOT / 'results/lambda/2026-09-09/gpu-regeneration-v799'
    old_map = read(old_package / 'sha256.json')
    bonus_archive = old_package / 'local.tar.gz'
    assert sha(bonus_archive.read_bytes()) == old_map['local.tar.gz']
    with tarfile.open(bonus_archive) as archive:
        bonus = archive.extractfile('runtime/bonus_coefficients.txt').read()
    assert sha(bonus) == BONUS_SHA
    weights = {i+1: Decimal(row.split()[0].decode()) for i, row in enumerate(bonus.splitlines())}
    pins[bonus_archive.relative_to(ROOT).as_posix()] = old_map['local.tar.gz']
    result = (FLEET / 'Result.txt').read_bytes()
    assert sha(result) == FINAL_SHA
    pins[(FLEET / 'Result.txt').relative_to(ROOT).as_posix()] = FINAL_SHA
    outcome_path = ROOT / 'build/performance/fleet-addition-v633b/output/report.json'
    final = read(outcome_path)
    assert final['qualified'] and all(final[k]['ok'] and final[k]['result_sha256'] == FINAL_SHA for k in ('independent', 'official'))
    pins[outcome_path.relative_to(ROOT).as_posix()] = sha(outcome_path.read_bytes())
    attempts_path = ROOT / 'build/performance/frontier-opportunities-v630/attempt-signatures.json'
    attempts = read(attempts_path)
    pins[attempts_path.relative_to(ROOT).as_posix()] = sha(attempts_path.read_bytes())
    failed_return_path = ROOT / 'build/performance/mass-merit-return-v632/inputs/candidate-plan.json'
    failed_return = request(read(failed_return_path))
    failed_return_hash = sha(canonical(failed_return))
    assert failed_return_hash == 'dcfc0573a6d96ca76120347a4e22ba91f33bbd53bfc1c59704c0481a8053a6af'
    pins[failed_return_path.relative_to(ROOT).as_posix()] = sha(failed_return_path.read_bytes())
    with localcontext() as context:
        context.prec = 65
        fleet = fleet_inventory(result, weights)
        baseline_raw = sum((r['raw'] for r in fleet.values()), Decimal(0))
        baseline_weighted = sum((r['weighted'] for r in fleet.values()), Decimal(0))
        threshold = Decimal(6000)*Decimal(12).ln()
        budget = baseline_raw-threshold
        assert abs(float(baseline_raw)-final['independent']['total_mass_kg']) < 1e-8
        assert abs(float(baseline_weighted)-final['independent']['weighted_score_fixed_bonus_kg']) < 1e-8
        owners = defaultdict(set)
        for ship, item in fleet.items():
            for body in item['asteroids']:
                owners[body].add(ship)
        rows, unique, selected_plans, statistics = [], {}, {}, {}
        for hardware in ('local', 'h100'):
            for ship in (10, 21):
                plans = all_plans[hardware, ship]
                narrow = all_narrow[hardware, ship]
                narrow_orders = {tuple(p['asteroids']) for p in narrow}
                narrow_requests = {sha(canonical(request(p))) for p in narrow}
                ship_rows = []
                for rank, plan in enumerate(plans):
                    req = request(plan)
                    key = sha(canonical(req))
                    raw = sum((Decimal(str(v)) for _, v in req['cargo']), Decimal(0))
                    weighted = sum((weights[k]*Decimal(str(v)) for k, v in req['cargo']), Decimal(0))
                    assert abs(raw-Decimal(str(plan['total_collected_kg']))) < Decimal('1e-9')
                    assert plan['feasible_proxy']
                    conflicts = {k: sorted(owners[k]-{ship}) for k in plan['asteroids'] if owners[k]-{ship}}
                    gain, raw_gain = weighted-fleet[ship]['weighted'], raw-fleet[ship]['raw']
                    margin = budget+raw_gain
                    shared_prefix = 0
                    for new, old in zip(req['flights'], failed_return['flights']):
                        if tuple(new) != tuple(old):
                            break
                        shared_prefix += 1
                    row = dict(id=f'{hardware}/wide/ship-{ship:02d}/plans.json#rank{rank:04d}',
                        hardware=hardware, ship=ship, rank=rank, request_sha256=key,
                        canonical_plan_sha256=sha(canonical(plan)), asteroid_order=plan['asteroids'],
                        order_sha256=sha(canonical(plan['asteroids'])),
                        new_order_vs_narrow=tuple(plan['asteroids']) not in narrow_orders,
                        new_request_vs_narrow=key not in narrow_requests,
                        conflicts=conflicts, conflicts_with_new_ship24=sorted(k for k, v in conflicts.items() if 24 in v),
                        unused_asteroids=sorted(k for k in plan['asteroids'] if not owners[k]),
                        weighted_proxy_kg=float(weighted), raw_proxy_kg=float(raw),
                        weighted_delta_kg=float(gain), raw_delta_kg=float(raw_gain),
                        fleet_raw_margin_if_cargo_delivered_kg=float(margin),
                        positive_weighted=gain > Decimal('1e-8'),
                        fits_fleet_raw_rule=margin >= 0,
                        compatible_first_Earth_leg=tuple(req['flights'][0]) == tuple(fleet[ship]['first_leg']),
                        final_mass_proxy_margin_kg=plan['final_mass_proxy_kg']-500.-float(raw),
                        flight_count=len(req['flights']), first_flight=list(req['flights'][0]), last_flight=list(req['flights'][-1]),
                        same_failed_return_request=key == failed_return_hash,
                        shared_exact_flight_prefix_with_failed_ship10=shared_prefix,
                        same_failed_return_schedule=tuple(req['flights'][-1]) == tuple(failed_return['flights'][-1]),
                        exact_historical_attempt_ids=[a['id'] for a in attempts if a['request_sha256'] == key],
                        certified_by_this_analysis=False)
                    rows.append(row)
                    ship_rows.append(row)
                    unique.setdefault((ship, key), []).append(row)
                    if hardware == 'local':
                        selected_plans[row['id']] = plan
                statistics[hardware+'/'+str(ship)] = dict(candidates=len(plans), narrow_candidates=len(narrow),
                    distinct_orders=len({tuple(p['asteroids']) for p in plans}),
                    new_orders=len({tuple(p['asteroids']) for p in plans}-narrow_orders),
                    positive=sum(r['positive_weighted'] for r in ship_rows),
                    positive_nonconflicting=sum(r['positive_weighted'] and not r['conflicts'] for r in ship_rows),
                    positive_nonconflicting_raw_eligible=sum(r['positive_weighted'] and not r['conflicts'] and r['fits_fleet_raw_rule'] for r in ship_rows),
                    new_order_positive_nonconflicting_raw_eligible=sum(r['new_order_vs_narrow'] and r['positive_weighted'] and not r['conflicts'] and r['fits_fleet_raw_rule'] for r in ship_rows),
                    conflicting=sum(bool(r['conflicts']) for r in ship_rows),
                    conflicting_new_ship24=sum(bool(r['conflicts_with_new_ship24']) for r in ship_rows),
                    new_order_best=max((r for r in ship_rows if r['new_order_vs_narrow']), key=lambda r:r['weighted_delta_kg']),
                    best=max(ship_rows, key=lambda r:r['weighted_delta_kg']))
        representatives = [min(group, key=lambda r:(r['hardware'] != 'local', r['rank'])) | {'aliases':[r['id'] for r in group]}
                           for group in unique.values()]
        positives = sorted([r for r in representatives if r['positive_weighted']], key=lambda r:-r['weighted_delta_kg'])
        eligible = [r for r in positives if not r['conflicts'] and r['fits_fleet_raw_rule']]
        new_feasible = sorted([r for r in representatives if r['new_order_vs_narrow'] and not r['conflicts'] and r['fits_fleet_raw_rule']],
                              key=lambda r:-r['weighted_delta_kg'])
        diverse, seen_orders = [], set()
        for row in new_feasible:
            if row['order_sha256'] not in seen_orders:
                diverse.append(row)
                seen_orders.add(row['order_sha256'])
            if len(diverse) == 8:
                break
        selections = {r['id']:selected_plans[r['id']] for r in eligible+diverse if r['id'] in selected_plans}
        finding = dict(passed=True, mode='saved data only; no recomputation of trajectory or forward proxy',
            current_Result_sha256=FINAL_SHA, current_raw_kg=str(baseline_raw), current_weighted_kg=str(baseline_weighted),
            raw_24ship_threshold_kg=str(threshold), raw_budget_kg=str(budget),
            statistics=statistics, distinct_fixed_cargo_requests=len(unique),
            local_h100_same_request_set=all({r['request_sha256'] for r in rows if r['hardware']=='local' and r['ship']==s}
               == {r['request_sha256'] for r in rows if r['hardware']=='h100' and r['ship']==s} for s in (10,21)),
            positive_distinct_requests=len(positives), eligible_positive_distinct_requests=len(eligible),
            eligible_positive=eligible, top_diverse_new_orders_fitting_raw_rule=diverse,
            source_sha256=pins, archive_members=members, exact_bonus_sha256=BONUS_SHA,
            calls=dict(ephemeris=0, Lambert=0, search=0, propagation=0, optimization=0, GPU=0))
        write('findings.json', finding)
        write('all-candidate-metrics.json', rows)
        write('selected-saved-plans.json', selections)
        write('current-ships.json', {str(k):{'raw_kg':str(v['raw']), 'weighted_kg':str(v['weighted']),
              'asteroids':sorted(v['asteroids']), 'first_leg':v['first_leg']} for k,v in fleet.items()})
    print(json.dumps({k:v for k,v in finding.items() if k not in ('source_sha256','archive_members','top_diverse_new_orders_fitting_raw_rule','eligible_positive','statistics')},indent=2))
    for key, value in statistics.items():
        print(key, {k:v for k,v in value.items() if k not in ('new_order_best','best')})
        print('BEST',json.dumps(value['best']))
        print('NEW_BEST',json.dumps(value['new_order_best']))


if __name__ == '__main__':
    main()
