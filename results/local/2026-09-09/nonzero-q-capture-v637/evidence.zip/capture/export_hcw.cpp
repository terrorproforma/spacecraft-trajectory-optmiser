// Standalone HOST capture of the unchanged native HCW N20 SOC recipe.
// No CUDA headers, native solver, backend, optimizer, or factorization is linked.
// This executable must not be built/run until the capture protocol is reviewed.
#include "spacepdhcg/transcription/hcw_rendezvous.hpp"

#include <bit>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <locale>
#include <sstream>
#include <stdexcept>

#ifndef CAPTURE_SOURCE_SHA256
#error CAPTURE_SOURCE_SHA256 must bind this exact source at compilation
#endif
#ifndef CAPTURE_HEADER_MAP_SHA256
#error CAPTURE_HEADER_MAP_SHA256 must bind the four frozen header files
#endif

namespace fs = std::filesystem;
namespace tr = spacepdhcg::transcription;
namespace dy = spacepdhcg::dynamics;
using Clock = std::chrono::steady_clock;

static void require(bool ok, const char* why) {
    if (!ok) throw std::runtime_error(why);
}
static double elapsed(Clock::time_point a) {
    return std::chrono::duration<double>(Clock::now() - a).count();
}
static void number(std::ostream& out, double x) {
    require(!std::isnan(x), "NaN capture value");
    if (std::isinf(x)) out << (x < 0 ? "\"-Infinity\"" : "\"Infinity\"");
    else if (x == 0 && std::signbit(x)) out << "-0.0";
    else out << std::setprecision(17) << x;
}
template<class Range> static void array(std::ostream& out, const Range& x) {
    out << '['; bool first = true;
    for (auto v : x) { if (!first) out << ','; first = false; number(out, v); }
    out << ']';
}
template<class Range> static void text_vector(std::ostream& out, const Range& x) {
    out << x.size(); for (auto v : x) out << ' ' << std::setprecision(17) << v; out << '\n';
}
static void save(const fs::path& p, const std::string& bytes) {
    FILE* f = std::fopen(p.string().c_str(), "wbx");
    require(f != nullptr, "exclusive output creation failed");
    const bool wrote = std::fwrite(bytes.data(), 1, bytes.size(), f) == bytes.size();
    const bool closed = std::fclose(f) == 0;
    require(wrote && closed, "capture output write failed");
}
static void matrix(std::ostream& out, const spacepdhcg::core::CscPattern& p,
                   const std::vector<double>& values) {
    out << "{\"rows\":" << p.rows << ",\"columns\":" << p.columns << ",\"offsets\":";
    array(out, p.offsets); out << ",\"indices\":"; array(out, p.indices);
    out << ",\"values\":"; array(out, values); out << '}';
}

int main(int argc, char** argv) try {
    require(argc == 2, "usage: export_hcw NEW_OUTPUT_DIRECTORY");
    std::locale::global(std::locale::classic());
    require(fs::create_directory(argv[1]), "output directory must not exist; parent must exist");
    const fs::path outdir = fs::canonical(argv[1]);
    const auto start = Clock::now();
    tr::HcwRendezvousConfig config;
    config.intervals = 20; config.step_seconds = 10.0;
    require(config.control_set == tr::HcwControlSet::second_order_cone,
            "native HCW default control set changed");
    require(config.mean_motion == 1.13e-3 && config.maximum_acceleration == 0.05,
            "native HCW physical defaults changed");
    const dy::HcwState initial{0.1, -0.05, 0.02, 1e-4, -2e-4, 5e-5};
    const dy::HcwState target{};
    const tr::HcwRendezvousCqp problem(config); // exactly one native host assembly
    const auto values = problem.values(initial, target);
    const auto& shape = problem.structure();
    require(shape.variables() == 186 && shape.scalar_rows() == 132 && shape.affine_rows() == 80,
            "HCW dimensions changed");
    require(shape.quadratic.nonzeros() == 186 && shape.scalar_constraint.nonzeros() == 1212
            && shape.affine_cone && shape.affine_cone->nonzeros() == 60
            && shape.affine_cones.size() == 20 && shape.variable_cones.empty(), "HCW topology changed");
    for (int j = 0; j < 186; ++j) {
        require(shape.quadratic.offsets[j] == j && shape.quadratic.indices[j] == j
                && std::isfinite(values.quadratic[j]) && values.quadratic[j] > 0, "nonpositive/non-diagonal Q");
        const double expected = j < 126 ? (j % 6 < 3 ? 2e-4 : 2e-2) : 2.0;
        require(values.quadratic[j] == expected, "native HCW quadratic coefficients changed");
        require(values.variable_lower[j] == -INFINITY && values.variable_upper[j] == INFINITY,
                "unexpected finite variable bound");
    }
    for (int r = 0; r < 132; ++r)
        require(std::isfinite(values.scalar_lower[r]) && values.scalar_lower[r] == values.scalar_upper[r],
                "unexpected scalar inequality");
    std::vector<dy::HcwState> states(21); states.front() = initial;
    std::vector<dy::HcwControl> controls(20);
    for (int k = 0; k < 20; ++k)
        states[k + 1] = dy::hcw_step(problem.discrete_dynamics(), states[k], controls[k]);
    const double assembly_seconds = elapsed(start);

    const auto mapping_start = Clock::now();
    // HCW has only equality scalar rows and free variables. Retain every A
    // structural entry and its represented value, including signed zeros.
    // Native SOC order [u0,u1,u2,t] -> QOCO [t,u0,u1,u2].
    // G=-perm(F), h=perm(offset), so h-Gx=perm(Fx+offset).
    auto gp = *shape.affine_cone;
    std::vector<double> gv = values.affine_cone, h(80);
    std::vector<int> qoco_row_to_native(80);
    for (int k = 0; k < 20; ++k) {
        const auto& cone = shape.affine_cones[k];
        require(cone.kind == spacepdhcg::ConeKind::second_order && cone.start == 4 * k
                && cone.vector_dimension == 2, "unexpected native SOC layout");
        for (int a = 0; a < 4; ++a) {
            const int native = 4 * k + (a == 0 ? 3 : a - 1);
            qoco_row_to_native[4 * k + a] = native; h[4 * k + a] = values.affine_offset[native];
        }
    }
    // Every F column in this recipe contains at most one element; the row
    // permutation cannot disturb CSC ordering or create duplicates.
    for (int j = 0; j < 186; ++j) {
        require(gp.offsets[j + 1] - gp.offsets[j] <= 1, "HCW F column not singleton");
        for (int k = gp.offsets[j]; k < gp.offsets[j + 1]; ++k) {
            const int r = gp.indices[k]; gp.indices[k] = 4 * (r / 4) + (r % 4 == 3 ? 0 : r % 4 + 1);
            gv[k] = -gv[k];
        }
    }
    gp.validate();
    const double mapping_seconds = elapsed(mapping_start);
    const auto serialize_start = Clock::now();
    std::ostringstream native;
    native << "{\"schema\":\"native-hcw-cqp-v1\",\"canonical_objective_constant\":0,\"Q\":";
    matrix(native, shape.quadratic, values.quadratic); native << ",\"A\":";
    matrix(native, shape.scalar_constraint, values.scalar_constraint); native << ",\"F\":";
    matrix(native, *shape.affine_cone, values.affine_cone);
    for (const auto& item : std::vector<std::pair<const char*, const std::vector<double>*>>{
        {"c", &values.linear_objective}, {"scalar_lower", &values.scalar_lower},
        {"scalar_upper", &values.scalar_upper}, {"affine_offset", &values.affine_offset},
        {"variable_lower", &values.variable_lower}, {"variable_upper", &values.variable_upper}}) {
        native << ",\"" << item.first << "\":"; array(native, *item.second);
    }
    native << ",\"affine_cones\":[";
    for (int k = 0; k < 20; ++k) {
        if (k) native << ',';
        native << "{\"kind\":\"second_order\",\"start\":" << 4*k
               << ",\"vector_dimension\":2,\"slots\":4,\"order\":\"vector_then_scalar\"}";
    }
    native << "],\"variable_cones\":[]}\n"; save(outdir / "native.json", native.str());

    std::ostringstream snapshot;
    snapshot << "SPACEPDHCG_QOCO_QP_V1\n186 132 80 186 1212 60 0 20 0\n";
    // Exact non-low-thrust native-adapter policy at tolerance=1e-8/Ruiz=0.
    // These are declared experiment settings, not inherited GTOC12 settings.
    snapshot << "200 0 5 0\n1e-6 1e-13 1e-8 1e-13 1e-11 1e-8 1e-8 1e-5 1e-5\n";
    for (const auto* p : std::array<const spacepdhcg::core::CscPattern*, 3>{
            &shape.quadratic, &shape.scalar_constraint, &gp}) {
        text_vector(snapshot, p->offsets); text_vector(snapshot, p->indices);
    }
    text_vector(snapshot, std::vector<int>(20, 4));
    std::vector<double> original;
    for (const auto* v : std::array<const std::vector<double>*, 6>{
            &values.quadratic, &values.scalar_constraint, &gv,
            &values.linear_objective, &values.scalar_lower, &h})
        original.insert(original.end(), v->begin(), v->end());
    text_vector(snapshot, original); snapshot << "0\n0\n0\n";
    save(outdir / "snapshot.txt", snapshot.str());

    std::ostringstream context;
    context << "{\"schema\":\"hcw-reference-v1\",\"intervals\":20,\"step_seconds\":10,\"mean_motion\":0.00113,"
            << "\"maximum_acceleration\":0.05,\"initial_state\":"; array(context, initial);
    context << ",\"target_state\":"; array(context, target);
    context << ",\"times_seconds\":"; std::vector<double> times(21);
    for (int k = 0; k <= 20; ++k) times[k] = 10.0 * k;
    array(context, times); context << ",\"reference_states\":[";
    for (int k = 0; k <= 20; ++k) { if (k) context << ','; array(context, states[k]); }
    context << "],\"reference_controls\":[";
    for (int k = 0; k < 20; ++k) { if (k) context << ','; array(context, controls[k]); }
    context << "],\"tracking_reference_states\":[";
    double tracking_constant = 0;
    for (int k = 0; k <= 20; ++k) {
        dy::HcwState ref{}; const double fraction = double(k) / 20;
        for (int j = 0; j < 6; ++j) {
            ref[j] = (1.0 - fraction) * initial[j] + fraction * target[j];
            tracking_constant += config.state_weights[j] * ref[j] * ref[j];
        }
        if (k) context << ','; array(context, ref);
    }
    context << "],\"state_weights\":"; array(context, config.state_weights);
    context << ",\"control_weights\":"; array(context, config.control_weights);
    context << ",\"discrete_state_row_major\":"; array(context, problem.discrete_dynamics().state);
    context << ",\"discrete_control_row_major\":"; array(context, problem.discrete_dynamics().control);
    context << ",\"qoco_row_to_native_affine\":"; array(context, qoco_row_to_native);
    context << ",\"canonical_objective_constant\":0,\"physical_tracking_constant_fp64_metadata_only\":";
    number(context, tracking_constant);
    context << ",\"physical_constant_used_by_solver_or_original_audit\":false,\"reference_used_as_solver_seed\":false,"
            << "\"cold_point_role\":\"declared zero candidate, not an observed backend-generated initial iterate\",\"cold_x\":";
    array(context, std::vector<double>(186)); context << ",\"cold_y\":"; array(context, std::vector<double>(132));
    context << ",\"cold_z\":"; array(context, std::vector<double>(80)); context << ",\"cold_s\":"; array(context, h);
    context << ",\"final_vectors\":null,\"final_vector_status\":\"not_run; later solver records own full x/y/z/s\"}\n";
    save(outdir / "context.json", context.str());
    std::ostringstream report;
    report << "{\"complete\":true,\"passed\":true,\"source_sha256\":\"" << CAPTURE_SOURCE_SHA256
           << "\",\"header_map_sha256\":\"" << CAPTURE_HEADER_MAP_SHA256
           << "\",\"compiler\":\"" << __VERSION__ << "\",\"cpp\":" << __cplusplus
           << ",\"assembly_calls\":1,\"reference_rollout_intervals\":20,\"optimizer_calls\":0,\"gpu_calls\":0,"
           << "\"assembly_and_reference_seconds\":" << std::setprecision(17) << assembly_seconds
           << ",\"mapping_seconds\":" << mapping_seconds << ",\"serialization_seconds\":" << elapsed(serialize_start)
           << ",\"whole_capture_seconds\":" << elapsed(start) << ",\"objective_constant\":0}\n";
    save(outdir / "capture-report.json", report.str()); std::cout << report.str(); return 0;
} catch (const std::exception& e) {
    std::cerr << "HCW_CAPTURE_FAILURE: " << e.what() << '\n'; return 1;
}
