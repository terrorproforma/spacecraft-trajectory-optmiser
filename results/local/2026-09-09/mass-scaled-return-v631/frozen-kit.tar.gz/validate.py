"""Retain CPU-only construction evidence; never load a native library."""

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

KIT = Path(__file__).resolve().parent
assert __debug__ and os.environ.get("CUDA_VISIBLE_DEVICES") == ""
output = KIT / (sys.argv[1] if len(sys.argv) > 1 else "validation")
output.mkdir()
stages = []
for name, args in (
    ("pytest", ["-m", "pytest", "-q", str(KIT / "test_prepare.py"), "--tb=short"]),
    (
        "ruff",
        [
            "-m",
            "ruff",
            "check",
            str(KIT / "prepare.py"),
            str(KIT / "test_prepare.py"),
            str(KIT / "validate.py"),
        ],
    ),
    ("prepare", [str(KIT / "prepare.py")]),
):
    begin = time.monotonic()
    result = subprocess.run([sys.executable, "-B", *args], cwd=KIT, capture_output=True, timeout=60)
    payload = result.stdout + result.stderr
    (output / f"{name}.log").write_bytes(payload)
    stages.append(
        {
            "name": name,
            "args": args,
            "exit_code": result.returncode,
            "seconds": time.monotonic() - begin,
            "log_sha256": hashlib.sha256(payload).hexdigest(),
        }
    )
    if result.returncode != 0:
        break
report = {
    "passed": all(x["exit_code"] == 0 for x in stages),
    "GPU_calls": 0,
    "propagation_calls": 0,
    "stages": stages,
}
(output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(0 if report["passed"] else 1)
