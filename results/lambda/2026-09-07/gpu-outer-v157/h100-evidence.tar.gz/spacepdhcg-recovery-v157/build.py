from pathlib import Path
import subprocess,json,os,shutil,hashlib,time
root=Path('/home/ubuntu/spacepdhcg-recovery-v157');os.chdir(root);os.nice(10)
old='/home/ubuntu/spacepdhcg/v1'
cmake=old+'/.venv/bin/cmake'
commands=[['git','-C',old,'fetch','https://github.com/terrorproforma/spacecraft-trajectory-optmiser.git','codex/gpu-outer-loop-v156'],['git','-C',old,'worktree','add','--detach',str(root/'repo'),'dcdb812fceda00041db52a2764377e0d1c165414'],[cmake,'-S',str(root/'repo/cpp'),'-B',str(root/'core-build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSPACEPDHCG_BUILD_CUDA=ON','-DSPACEPDHCG_BUILD_NATIVE_TESTS=OFF','-DBUILD_TESTING=ON','-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=90','-DSPACEPDHCG_PDHCG_SOURCE_ROOT='+old+'/_upstream/pdhcg'],[cmake,'--build',str(root/'core-build'),'--target','spacepdhcg_cuda','device_scvx_integration_test','native_qoco_conversion_test','qoco_gpu_audit_test','qoco_gpu_conversion_test','gtoc12_scvx_test','gtoc12_device_refresh_test','-j','3']]
report=dict(start=time.time(),commit='dcdb812fceda00041db52a2764377e0d1c165414',commands=commands,stages=[])
try:
 for cmd in commands:
  start=time.time();r=subprocess.run(cmd);report['stages'].append(dict(returncode=r.returncode,seconds=time.time()-start));(root/'build-status.json').write_text(json.dumps(report,indent=2));r.check_returncode()
 out=root/'final';out.mkdir(exist_ok=False)
 sources=[Path('/home/ubuntu/spacepdhcg-outer-v156/build/libqoco.so'),root/'core-build/cuda/libspacepdhcg_cuda.so']+[root/'core-build/cuda-tests'/name for name in ['device_scvx_integration_test','native_qoco_conversion_test','qoco_gpu_audit_test','qoco_gpu_conversion_test','gtoc12_scvx_test','gtoc12_device_refresh_test']]
 for source in sources:shutil.copy2(source,out/source.name);(out/source.name).chmod(0o555)
 report['success']=True;report['runtime_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}
except Exception as error:report['success']=False;report['error']=str(error)
report['end']=time.time();(root/'build-status.json').write_text(json.dumps(report,indent=2))
