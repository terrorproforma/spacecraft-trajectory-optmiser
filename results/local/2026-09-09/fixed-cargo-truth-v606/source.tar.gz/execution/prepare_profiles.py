"""Record alternative validated hosts and actual v595 source newline equivalence."""

import hashlib
import shutil
import tarfile

import common

repo = common.ROOT.parents[2]
reference = common.ROOT / "reference"
for name in ("report.json", "orbitweaver.diff"):
    shutil.copy2(
        repo / "build/performance/truth-set-native-compatibility-v606" / name,
        reference / ("h100-native-compatibility-" + name),
    )
previous = common.read(reference / "v595-report.json")
previous_manifest = common.read(
    repo / "results/local/2026-09-09/orphan-recovery-v595/source-sha256.json"
)
archive = repo / "results/local/2026-09-09/orphan-recovery-v595/source.tar.gz"
rows = {}
with tarfile.open(archive, "r:gz") as source:
    members = {member.name.removeprefix("source/"): member for member in source.getmembers()}
    for name in common.read(common.ROOT / "preparation.json")["identical_source_files"]:
        old = source.extractfile(members[name]).read()
        new = (common.ROOT / "source" / name).read_bytes()
        old_hash = hashlib.sha256(old).hexdigest()
        assert old_hash == previous_manifest[name]
        if name in previous["source_sha256"]:
            assert old_hash == previous["source_sha256"][name]
        assert old.replace(b"\r\n", b"\n") == new.replace(b"\r\n", b"\n")
        rows[name] = {
            "v595_raw_sha256": old_hash,
            "v606_raw_sha256": hashlib.sha256(new).hexdigest(),
            "normalized_LF_sha256": hashlib.sha256(new.replace(b"\r\n", b"\n")).hexdigest(),
            "v595_CRLF_count": old.count(b"\r\n"),
            "v606_CRLF_count": new.count(b"\r\n"),
            "normalized_exact_equal": True,
        }
        if name.startswith("src/spacepdhcg/gtoc12/") and name.rsplit("/", 1)[-1] in (
            "pipeline.py",
            "gpu_scvx.py",
            "low_thrust.py",
            "verifier.py",
            "solution.py",
        ):
            destination = reference / "v595-python" / name.rsplit("/", 1)[-1]
            destination.parent.mkdir(exist_ok=True)
            destination.write_bytes(old)
common.write(
    reference / "v595-python-compatibility.json",
    {
        "scope": (
            "actual successful v595 archive versus frozen v606 source; CRLF normalized to LF only"
        ),
        "v595_source_archive_sha256": common.sha(archive),
        "files_compared": len(rows),
        "all_normalized_exact_equal": True,
        "files": rows,
    },
)
local = common.read(common.ROOT / "preparation.json")["native_libraries"]
common.write(
    common.ROOT / "profiles.json",
    {
        "budget_scope": (
            "one selected host only; profiles are alternatives, "
            "at most four whole-route refinements overall"
        ),
        "preferred_profile": "h100",
        "common_environment": {
            "SPACEPDHCG_TEST_GTOC12_PARALLEL_DIRECTIONS": "0",
            "SPACEPDHCG_TEST_GTOC12_JOINT_BATCH": "0",
            "SPACEPDHCG_TEST_GTOC12_JOINT_DEVICE_SELECTION": "0",
            "OPENBLAS_NUM_THREADS": "1",
            "OMP_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "PYTHONHASHSEED": "0",
            "PYTHONDONTWRITEBYTECODE": "1",
        },
        "profiles": {
            "local": {
                "python": "/home/angus/worktrees/spacepdhcg-literature-venv/bin/python",
                "data": "/home/angus/worktrees/spacepdhcg-release/benchmarks/gtoc12/data",
                "lock": "/home/angus/.spacepdhcg-gpu.lock",
                "native_libraries": local,
                "LD_LIBRARY_PATH": (
                    "/home/angus/build-qoco-scaled-pool-v540/final:"
                    "/home/angus/cudss-isolated-0.8.0.10/nvidia/cu12/lib:"
                    "/usr/local/cuda-12.8/lib64"
                ),
                "validation_reference": "reference/v595-report.json",
            },
            "h100": {
                "python": "/home/ubuntu/spacepdhcg/v1/.venv/bin/python",
                "data": "/home/ubuntu/spacepdhcg/gtoc12/benchmarks/gtoc12/data",
                "lock": "/home/ubuntu/.spacepdhcg-gpu.lock",
                "native_libraries": {
                    "SPACEPDHCG_GTOC12_CUDA_LIBRARY": {
                        "path": (
                            "/home/ubuntu/spacepdhcg-joint-selection-v632/build/cuda/"
                            "libspacepdhcg_cuda.so"
                        ),
                        "sha256": (
                            "29a6b10b6349a21fd49f3b2d3f425cdca0d4e3acc4d97fd14cd16c42de54b44e"
                        ),
                    },
                    "SPACEPDHCG_QOCO_LIBRARY": {
                        "path": "/home/ubuntu/spacepdhcg-scaled-pool-v545/final/libqoco.so",
                        "sha256": (
                            "b50d61903921659c1f431b7c2f3472e0f353e5e5a72159e4164d7d282d27c906"
                        ),
                    },
                },
                "LD_LIBRARY_PATH": (
                    "/home/ubuntu/spacepdhcg-scaled-pool-v545/final:"
                    "/home/ubuntu/spacepdhcg-recovery-v152/cudss/lib:/usr/local/cuda/lib64"
                ),
                "validation_reference": "reference/h100-native-compatibility-report.json",
                "source_compatibility_report_sha256": common.sha(
                    reference / "h100-native-compatibility-report.json"
                ),
                "scope": (
                    "352/355 native files identical; remaining joint APIs unused; "
                    "parallel direction dispatch forced off; fresh control solves still required"
                ),
            },
        },
    },
)
print({"profiles": ["local", "h100"], "normalized_source_files": len(rows), "GPU_calls": 0})
