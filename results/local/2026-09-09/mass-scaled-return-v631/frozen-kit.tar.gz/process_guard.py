"""Own and reap this supervisor's Linux descendants, even after leader exit."""
import ctypes
import os
from pathlib import Path
import signal
import time


def enable_subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # Linux PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), "PR_SET_CHILD_SUBREAPER")


def process_record(pid):
    try:
        raw = (Path("/proc") / str(pid) / "stat").read_text()
        fields = raw[raw.rfind(")") + 2:].split()
        return {"pid": int(pid), "state": fields[0], "ppid": int(fields[1]),
                "start_ticks": int(fields[19])}
    except FileNotFoundError:
        return None


def descendants():
    records = {}
    for path in Path("/proc").iterdir():
        if path.name.isdigit():
            record = process_record(int(path.name))
            if record is not None:
                records[record["pid"]] = record
    parents = {os.getpid()}
    found = {}
    while True:
        children = {pid: item for pid, item in records.items()
                    if pid not in parents and item["ppid"] in parents}
        if not children:
            return list(found.values())
        found.update(children)
        parents.update(children)


def direct_children():
    children = set()
    for task in (Path("/proc") / str(os.getpid()) / "task").iterdir():
        children.update(int(p) for p in (task / "children").read_text().split())
    return children


def signal_owned(records, kind):
    for saved in records:
        current = process_record(saved["pid"])
        if current is None or current["start_ticks"] != saved["start_ticks"]:
            continue
        try:
            os.kill(saved["pid"], kind)
        except ProcessLookupError:
            pass


def cleanup(child, term_seconds=10, kill_seconds=30):
    # Subreaper adoption keeps double-forked targets in this ownership tree.
    # Repeated interrupt signals cannot skip the finally cleanup or unlock early.
    for kind in (signal.SIGHUP, signal.SIGTERM, signal.SIGINT):
        signal.signal(kind, signal.SIG_IGN)
    actions = []
    for kind, seconds in ((signal.SIGTERM, term_seconds), (signal.SIGKILL, kill_seconds)):
        deadline = time.monotonic() + seconds
        while True:
            if child is not None:
                child.poll()
            owned = descendants()
            for item in owned:
                if item["ppid"] == os.getpid() and item["state"] == "Z":
                    try:
                        os.waitpid(item["pid"], os.WNOHANG)
                    except ChildProcessError:
                        pass
            owned = descendants()
            direct = direct_children()
            if not owned and not direct and not descendants() and not direct_children():
                return {"verified_empty": True, "actions": actions, "survivors": []}
            # Cover adoption during the non-atomic full /proc traversal.
            seen = {item["pid"] for item in owned}
            for pid in direct - seen:
                item = process_record(pid)
                if item is not None:
                    owned.append(item)
            signal_owned(owned, kind)
            actions.append({"signal": int(kind), "processes": owned})
            if time.monotonic() >= deadline:
                break
            time.sleep(0.05)
    return {"verified_empty": False, "actions": actions, "survivors": descendants()}
