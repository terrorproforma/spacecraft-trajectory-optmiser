"""CPU construction guards: exact ZOH mapping and explicit mass infeasibility."""

from types import SimpleNamespace

import numpy as np
import pytest
from prepare import map_zoh, mass_scaling, roundoff_comparison


def arc(t0, tf, value=(0.3, 0.0, 0.0), final=None):
    samples = [
        SimpleNamespace(thrust=np.asarray(value), line_number=10),
        SimpleNamespace(thrust=np.asarray(value if final is None else final), line_number=11),
    ]
    return SimpleNamespace(start=t0, end=tf, interior=samples, samples=samples)


def test_exact_constant_arcs_preserve_coast_and_inactive_final_control():
    epochs = np.array([10.0, 12.0, 14.0, 16.0, 18.0])
    thrust, used, mapping = map_zoh([arc(10.0, 12.0), arc(14.0, 18.0, (0.0, 0.2, 0.0))], epochs)
    np.testing.assert_array_equal(
        thrust, [[0.3, 0, 0], [0, 0, 0], [0, 0.2, 0], [0, 0.2, 0], [0, 0, 0]]
    )
    np.testing.assert_array_equal(used, [True, False, True, True])
    assert mapping[1]["exclusive_last_interval"] == 4


@pytest.mark.parametrize(
    "arcs,message",
    [
        ([arc(10.0, 13.0)], "boundary absent"),
        ([arc(9.0, 12.0)], "crosses"),
        ([arc(10.0, 12.0, final=(0.31, 0.0, 0.0))], "not an exact constant"),
        ([arc(10.0, 14.0), arc(12.0, 16.0)], "overlapping"),
    ],
)
def test_invalid_mapping_never_interpolates_or_truncates(arcs, message):
    with pytest.raises(ValueError, match=message):
        map_zoh(arcs, [10.0, 12.0, 14.0, 16.0])


@pytest.mark.parametrize("epochs", [[10.0, 10.0, 12.0], [10.0, float("nan"), 12.0], [12.0, 10.0]])
def test_bad_node_grid_is_rejected(epochs):
    with pytest.raises(ValueError, match="grid"):
        map_zoh([], epochs)


def test_lower_mass_seed_is_not_misrepresented_as_a_feasible_candidate():
    report = mass_scaling(1472.1728669809, 1193.9107054807, 1438.8883038351994, 1177.2073921971253)
    assert report["scale"] == pytest.approx(0.9773908595299954, abs=1e-15)
    assert report["required_fuel_reduction_kg"] == pytest.approx(10.289981565280641, abs=1e-11)
    assert not report["seed_satisfies_final_mass"]
    assert report["reference_final_mass_kg"] + report["reference_propellant_kg"] == pytest.approx(
        1438.8883038351994
    )


def test_original_mass_control_does_not_change_the_mass_ledger():
    report = mass_scaling(1472.1728669809, 1193.9107054807, 1472.1728669809, 1171.4579055442)
    assert report["scale"] == 1.0
    assert report["reference_final_mass_kg"] == 1193.9107054807
    assert report["seed_satisfies_final_mass"]


def test_homothety_preserves_acceleration_and_fractional_mass_flow_algebraically():
    mass = 1472.1728669809
    factor = 1438.8883038351994 / mass
    thrust = np.array([0.27, -0.11, 0.05])
    np.testing.assert_allclose((thrust * factor) / (mass * factor), thrust / mass, rtol=2e-16)
    exhaust = 4000.0 * 9.80665
    assert np.linalg.norm(thrust * factor) / exhaust == pytest.approx(
        factor * np.linalg.norm(thrust) / exhaust, rel=2e-16
    )


@pytest.mark.parametrize(
    "masses", [(1.0, 2.0, 1.0, 0.5), (2.0, 1.0, 0.5, 1.0), (2.0, 1.0, float("nan"), 0.5)]
)
def test_invalid_mass_input_is_not_a_seed(masses):
    with pytest.raises(ValueError):
        mass_scaling(*masses)


def test_serialization_guard_does_not_hide_a_real_position_change():
    generated = np.array([-4e8, -1e8, -1e6])
    tiny = generated.copy()
    tiny[0] += 1e-6
    assert roundoff_comparison(tiny, generated)["within_representation_guard"]
    displaced = generated.copy()
    displaced[0] += 0.001
    assert not roundoff_comparison(displaced, generated)["within_representation_guard"]
