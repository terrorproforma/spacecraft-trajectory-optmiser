"""Select the first independently qualified reference point from each existing capture."""

import hashlib
import importlib.util
import json
import shutil
from pathlib import Path

import numpy as np

workspace = Path(__file__).resolve().parents[2]
baseline = workspace / "build/performance/persistent-replay-20260909"
output = workspace / "build/performance/known-point-replay-v606"
output.mkdir(exist_ok=False)
(output / "inputs").mkdir()
(output / "source").mkdir()
auditor = workspace / "scripts/gpu/audit_persistent_snapshot.py"
shutil.copyfile(auditor, output / "source/audit_persistent_snapshot.py")
shutil.copyfile(__file__, output / "source" / Path(__file__).name)
spec = importlib.util.spec_from_file_location("audit", auditor)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


baseline_report = json.loads((baseline / "run/report.json").read_text())
assert baseline_report["complete"]
manifest = {
    "complete": False,
    "gpu_calls": 0,
    "selection": "first independently qualified repeat in original recorded order",
    "purpose": "known-point mapping and stopping diagnostic; not a cold-solve benchmark",
    "auditor_sha256": sha(auditor),
    "baseline_report_sha256": sha(baseline / "run/report.json"),
    "points": [],
}
for label in ("conditioning", "difficult"):
    snapshot = baseline / "inputs" / (label + ".txt")
    log = baseline / "run" / (label + "-qoco.log")
    case = next(r for r in baseline_report["cases"]
                if r["label"] == label and r["backend"] == "qoco")
    assert sha(snapshot) == case["input_sha256"] and sha(log) == case["log_sha256"]
    problem = audit.load_snapshot(snapshot)
    checked = audit.audit_log(problem, log, sha(snapshot), backend="qoco",
                              coordinates="translated", record_prefix="QP_REPLAY")
    assert checked == case["audits"]
    records = [json.loads(line.removeprefix("QP_REPLAY ")) for line in log.read_text().splitlines()
               if line.startswith("QP_REPLAY ")]
    selected = next(i for i, result in enumerate(checked) if result["qualified"])
    record = records[selected]
    x = np.asarray(record["x"], dtype=np.float64)
    if problem["shift"]:
        x = x + problem["origin"].astype(np.float64)
    original_record = {**record, "x": x.tolist()}
    original_quality = audit.audit(problem, original_record, backend="qoco", coordinates="original")
    assert original_quality["qualified"]
    point = {
        "scope": "reference vectors; not yet encoded for native warm-start",
        "snapshot_sha256": sha(snapshot),
        "reference_log_sha256": sha(log),
        "reference_backend": "qoco",
        "reference_repeat": record["repeat"],
        "reference_status": record["status"],
        "reference_coordinates": "translated",
        "x_translated": record["x"],
        "x_original": x.tolist(),
        "y_original": record["y"],
        "z_original": record["z"],
        "s_original": record["s"],
        "independent_original_audit": original_quality,
    }
    target = output / "inputs" / (label + "-point.json")
    target.write_text(json.dumps(point, indent=2, allow_nan=False) + "\n")
    shutil.copyfile(snapshot, output / "inputs" / snapshot.name)
    shutil.copyfile(log, output / "inputs" / log.name)
    manifest["points"].append({
        "label": label,
        "point_sha256": sha(target),
        "snapshot_sha256": sha(snapshot),
        "reference_log_sha256": sha(log),
        "reference_repeat": record["repeat"],
        "independent_original_audit": original_quality,
    })
manifest["complete"] = True
(output / "preparation.json").write_text(json.dumps(manifest, indent=2, allow_nan=False) + "\n")
print(json.dumps(manifest))
