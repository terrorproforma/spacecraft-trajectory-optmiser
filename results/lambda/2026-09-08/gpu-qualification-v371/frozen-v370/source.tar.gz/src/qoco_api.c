/**
 * @file qoco_api.c
 * @author Govind M. Chari <govindchari1@gmail.com>
 *
 * @section LICENSE
 *
 * Copyright (c) 2024, Govind M. Chari
 * This source code is licensed under the BSD 3-Clause License
 */

#include "qoco_api.h"
void qoco_gpu_reset_control(QOCOSolver*);
void qoco_gpu_ir_reset_counts(QOCOSolver*, int);
void qoco_gpu_ir_report_counts(QOCOSolver*);
void qoco_gpu_ir_finish_step(QOCOSolver*);
int qoco_gpu_ipm_loop(QOCOSolver*);
int qoco_gpu_ipm_initialization_enabled(void);
void qoco_gpu_ipm_allocate_control(QOCOSolver*);
void qoco_gpu_free_control(QOCOWorkspace*);
#include "amd.h"
#include "backend.h"
extern QOCOMatrix* qoco_gpu_transpose_deferred(QOCOMatrix*, QOCOInt*);

QOCOInt qoco_setup(QOCOSolver* solver, QOCOInt n, QOCOInt m, QOCOInt p,
                   QOCOCscMatrix* P, QOCOFloat* c, QOCOCscMatrix* A,
                   QOCOFloat* b, QOCOCscMatrix* G, QOCOFloat* h, QOCOInt l,
                   QOCOInt nsoc, QOCOInt* q, QOCOSettings* settings)
{
  // Start setup timer.
  QOCOTimer setup_timer;
  start_timer(&setup_timer);

  // Validate problem data.
  if (qoco_validate_data(P, c, A, b, G, h, l, nsoc, q)) {
    return qoco_error(QOCO_DATA_VALIDATION_ERROR);
  }

  // Validate settings.
  if (qoco_validate_settings(settings)) {
    return qoco_error(QOCO_SETTINGS_VALIDATION_ERROR);
  }

  solver->settings = copy_settings(settings);

  // Allocate workspace.
  solver->work = qoco_malloc(sizeof(QOCOWorkspace));
  QOCOWorkspace* work = solver->work;
  work->gpu_control = NULL;
  work->stopping_origin = NULL;
  work->stopping_offset = NULL;
  work->stopping_origin_locked = 0;
  work->gpu_device_io = 0;
  work->gpu_primal_saved = 0;

  // Allocate problem data.
  solver->work->data = qoco_malloc(sizeof(QOCOProblemData));
  QOCOProblemData* data = solver->work->data;

  // Copy problem data.
  data->m = m;
  data->n = n;
  data->p = p;
  data->A = new_qoco_matrix(A);
  data->G = new_qoco_matrix(G);
  data->q = new_qoco_vectori(q, nsoc);
  data->c = new_qoco_vectorf(c, n);
  data->b = new_qoco_vectorf(b, p);
  data->h = new_qoco_vectorf(h, m);
  data->l = l;
  data->nsoc = nsoc;

  // Copy P.
  if (P) {
    data->P = new_qoco_matrix(P);
  }
  else {
    data->P = NULL;
  }

  // Equilibrate data.
  QOCOInt Annz = A ? get_nnz(data->A) : 0;
  QOCOInt Gnnz = G ? get_nnz(data->G) : 0;

  work->scaling = qoco_malloc(sizeof(QOCOScaling));
  work->scaling->delta = new_qoco_vectorf(NULL, n + p + m);
  work->scaling->Druiz = new_qoco_vectorf(NULL, n);
  work->scaling->Eruiz = new_qoco_vectorf(NULL, p);
  work->scaling->Fruiz = new_qoco_vectorf(NULL, m);
  work->scaling->Dinvruiz = new_qoco_vectorf(NULL, n);
  work->scaling->Einvruiz = new_qoco_vectorf(NULL, p);
  work->scaling->Finvruiz = new_qoco_vectorf(NULL, m);
  work->data->AtoAt = Annz > 0 ? qoco_malloc(Annz * sizeof(QOCOInt)) : NULL;
  work->data->GtoGt = Gnnz > 0 ? qoco_malloc(Gnnz * sizeof(QOCOInt)) : NULL;

  data->At = qoco_gpu_transpose_deferred(data->A, data->AtoAt);
  data->Gt = qoco_gpu_transpose_deferred(data->G, data->GtoGt);

  // Compute scaling statistics before equilibration and regularization.
  compute_scaling_statistics(data);

  ruiz_equilibration(data, work->scaling, solver->settings->ruiz_iters);

  // Regularize P.
  set_cpu_mode(1);
  data->Pnzadded_idx = qoco_calloc(n, sizeof(QOCOInt));
  if (P) {
    QOCOCscMatrix* Pcsc = get_csc_matrix(data->P);
    QOCOInt num_diagP = count_diag(Pcsc);
    data->Pnum_nzadded = n - num_diagP;
    // Create a copy of the CSC matrix since regularize_P will free it
    QOCOCscMatrix* Pcsc_copy = new_qoco_csc_matrix(Pcsc);
    QOCOCscMatrix* Preg =
        regularize_P(num_diagP, Pcsc_copy, solver->settings->kkt_static_reg_P,
                     data->Pnzadded_idx);
    free_qoco_matrix(data->P);
    data->P = new_qoco_matrix(Preg);
    free_qoco_csc_matrix(Preg);
  }
  else {
    QOCOCscMatrix* Pid =
        construct_identity(n, solver->settings->kkt_static_reg_P);
    data->P = new_qoco_matrix(Pid);
    free_qoco_csc_matrix(Pid);
    data->Pnum_nzadded = n;
  }
  set_cpu_mode(0);

  // Compute number of nonzeros in upper triangular NT scaling matrix.
  QOCOInt Wsoc_nnz = 0;
  for (QOCOInt i = 0; i < nsoc; ++i) {
    Wsoc_nnz += q[i] * q[i] - q[i];
  }
  Wsoc_nnz /= 2;
  QOCOInt Wnnz = m + Wsoc_nnz;
  work->Wnnz = Wnnz;

  QOCOInt* nt_scaling_soc_idx = NULL;
  QOCOInt* soc_idx = NULL;
  if (nsoc > 0) {
    nt_scaling_soc_idx = (QOCOInt*)qoco_malloc(nsoc * sizeof(QOCOInt));
    soc_idx = (QOCOInt*)qoco_malloc(nsoc * sizeof(QOCOInt));
    nt_scaling_soc_idx[0] = l;
    soc_idx[0] = l;
    for (QOCOInt i = 1; i < nsoc; ++i) {
      nt_scaling_soc_idx[i] = nt_scaling_soc_idx[i - 1] + q[i - 1] + 1;
      soc_idx[i] = soc_idx[i - 1] + q[i - 1];
    }
  }
  work->nt_scaling_soc_idx = new_qoco_vectori(nt_scaling_soc_idx, nsoc);
  work->soc_idx = new_qoco_vectori(soc_idx, nsoc);
  qoco_free(nt_scaling_soc_idx);
  qoco_free(soc_idx);

  solver->linsys = &backend;

  // Set up linear system data.
  QOCOFloat analysis_time_sec = 0.0;
  solver->linsys_data = solver->linsys->linsys_setup(data, solver->settings,
                                                     Wnnz, &analysis_time_sec);
  if (!solver->linsys_data) {
    return QOCO_SETUP_ERROR;
  }

  // Allocate primal and dual variables.
  work->x = new_qoco_vectorf(NULL, n);
  work->x0 = new_qoco_vectorf(NULL, n);
  work->use_x0 = 0;
  work->s = new_qoco_vectorf(NULL, m);
  work->y = new_qoco_vectorf(NULL, p);
  work->z = new_qoco_vectorf(NULL, m);
  work->mu = 0.0;
  work->ir_iters = 0;

  // Best-iterate tracking buffers (scaled space).
  work->best_x = new_qoco_vectorf(NULL, n);
  work->best_s = new_qoco_vectorf(NULL, m);
  work->best_y = new_qoco_vectorf(NULL, p);
  work->best_z = new_qoco_vectorf(NULL, m);
  work->best_pres = 0.0;
  work->best_dres = 0.0;
  work->best_gap = 0.0;
  work->best_obj = 0.0;
  work->best_metric = 0.0;
  work->best_iter = -1;
  work->best_valid = 0;

  // Allocate Nesterov-Todd scalings and scaled variables.
  QOCOInt nt_scaling_nnz = data->l;
  set_cpu_mode(1);
  for (QOCOInt i = 0; i < data->nsoc; ++i) {
    nt_scaling_nnz += get_element_vectori(data->q, i) + 1;
  }
  set_cpu_mode(0);

  work->W = new_qoco_vectorf(NULL, work->Wnnz);
  work->nt_scaling = new_qoco_vectorf(NULL, nt_scaling_nnz);
  work->nt_scaling_nnz = nt_scaling_nnz;
  work->Winv = new_qoco_vectorf(NULL, work->Wnnz);
  work->WtW = new_qoco_vectorf(NULL, work->Wnnz);
  work->lambda = new_qoco_vectorf(NULL, m);

  // For serial implementations of compute_nt scaling, sbar/zbar only need to be
  // of length max(q), since we process one SOC at a time, but for concurrent
  // implementations, we need each the kth SOC to have its own buffer of length
  // q[k].
  work->sbar = new_qoco_vectorf(NULL, m);
  work->zbar = new_qoco_vectorf(NULL, m);

  work->xbuff = new_qoco_vectorf(NULL, n);
  work->ybuff = new_qoco_vectorf(NULL, p);
  work->ubuff1 = new_qoco_vectorf(NULL, m);
  work->ubuff2 = new_qoco_vectorf(NULL, m);
  work->ubuff3 = new_qoco_vectorf(NULL, m);
  work->Ds = new_qoco_vectorf(NULL, m);
  work->rhs = new_qoco_vectorf(NULL, n + m + p);
  work->kktres = new_qoco_vectorf(NULL, n + m + p);
  work->xyz = new_qoco_vectorf(NULL, n + m + p);
  work->xyzbuff1 = new_qoco_vectorf(NULL, n + m + p);

  // Allocate solution struct.
  solver->sol = qoco_malloc(sizeof(QOCOSolution));
  solver->sol->x = qoco_malloc(n * sizeof(QOCOFloat));
  solver->sol->s = qoco_malloc(m * sizeof(QOCOFloat));
  solver->sol->y = qoco_malloc(p * sizeof(QOCOFloat));
  solver->sol->z = qoco_malloc(m * sizeof(QOCOFloat));
  solver->sol->iters = 0;
  solver->sol->ir_iters = 0;
  solver->sol->status = QOCO_UNSOLVED;
  solver->sol->analysis_time_sec = analysis_time_sec;

  stop_timer(&setup_timer);
  solver->sol->setup_time_sec = get_elapsed_time_sec(&setup_timer);

  return QOCO_NO_ERROR;
}

void qoco_set_csc(QOCOCscMatrix* A, QOCOInt m, QOCOInt n, QOCOInt Annz,
                  QOCOFloat* Ax, QOCOInt* Ap, QOCOInt* Ai)
{
  A->m = m;
  A->n = n;
  A->nnz = Annz;
  A->x = Ax;
  A->p = Ap;
  A->i = Ai;
}

void set_default_settings(QOCOSettings* settings)
{
  settings->max_iters = 200;
  settings->ruiz_iters = 0;
  settings->max_ir_iters = 5;
  settings->ir_tol = 1e-6;
  settings->kkt_static_reg_P = 1e-13;
  settings->kkt_static_reg_A = 1e-8;
  settings->kkt_static_reg_G = 1e-13;
  settings->kkt_dynamic_reg = 1e-11;
  settings->abstol = 1e-7;
  settings->reltol = 1e-7;
  settings->abstol_inacc = 1e-5;
  settings->reltol_inacc = 1e-5;
  settings->verbose = 0;
}

QOCOInt qoco_update_settings(QOCOSolver* solver,
                             const QOCOSettings* new_settings)
{
  if (qoco_validate_settings(new_settings)) {
    return qoco_error(QOCO_SETTINGS_VALIDATION_ERROR);
  }

  solver->settings->max_iters = new_settings->max_iters;
  solver->settings->ruiz_iters = new_settings->ruiz_iters;
  solver->settings->max_ir_iters = new_settings->max_ir_iters;
  solver->settings->ir_tol = new_settings->ir_tol;
  solver->settings->kkt_static_reg_P = new_settings->kkt_static_reg_P;
  solver->settings->kkt_static_reg_A = new_settings->kkt_static_reg_A;
  solver->settings->kkt_static_reg_G = new_settings->kkt_static_reg_G;
  solver->settings->kkt_dynamic_reg = new_settings->kkt_dynamic_reg;
  solver->settings->abstol = new_settings->abstol;
  solver->settings->reltol = new_settings->reltol;
  solver->settings->abstol_inacc = new_settings->abstol_inacc;
  solver->settings->reltol_inacc = new_settings->reltol_inacc;
  solver->settings->verbose = new_settings->verbose;

  return 0;
}

void qoco_update_vector_data(QOCOSolver* solver, QOCOFloat* cnew,
                             QOCOFloat* bnew, QOCOFloat* hnew)
{
  solver->sol->status = QOCO_UNSOLVED;
  QOCOProblemData* data = solver->work->data;
  QOCOScaling* scaling = solver->work->scaling;

  // Copy new data into CPU buffer.
  set_cpu_mode(1);
  if (cnew) {
    copy_arrayf(cnew, get_data_vectorf(data->c), data->n);
  }
  if (bnew) {
    copy_arrayf(bnew, get_data_vectorf(data->b), data->p);
  }
  if (hnew) {
    copy_arrayf(hnew, get_data_vectorf(data->h), data->m);
  }
  QOCOFloat* Druiz_data = get_data_vectorf(scaling->Druiz);
  QOCOFloat* Eruiz_data = get_data_vectorf(scaling->Eruiz);
  QOCOFloat* Fruiz_data = get_data_vectorf(scaling->Fruiz);
  QOCOFloat* cdata = get_data_vectorf(data->c);
  QOCOFloat* bdata = get_data_vectorf(data->b);
  QOCOFloat* hdata = get_data_vectorf(data->h);
  set_cpu_mode(0);

  compute_scaling_statistics(data);

  // Update cost vector on CPU.
  if (cnew) {
    for (QOCOInt i = 0; i < data->n; ++i) {
      cdata[i] = scaling->k * Druiz_data[i] * cdata[i];
    }
  }

  // Update equality constraint vector on CPU.
  if (bnew) {
    for (QOCOInt i = 0; i < data->p; ++i) {
      bdata[i] = Eruiz_data[i] * bdata[i];
    }
  }

  // Update conic constraint vector on CPU.
  if (hnew) {
    for (QOCOInt i = 0; i < data->m; ++i) {
      hdata[i] = Fruiz_data[i] * hdata[i];
    }
  }

  // Sync the new data to the GPU.
  sync_vector_to_device(data->c);
  sync_vector_to_device(data->b);
  sync_vector_to_device(data->h);
}

void qoco_set_x0(QOCOSolver* solver, const QOCOFloat* x0)
{
  QOCOWorkspace* work = solver->work;

  if (!x0) {
    work->use_x0 = 0;
    solver->sol->status = QOCO_UNSOLVED;
    return;
  }

  set_cpu_mode(1);
  work->gpu_primal_saved = 0;
  copy_arrayf(x0, get_data_vectorf(work->x0), work->data->n);
  set_cpu_mode(0);
  sync_vector_to_device(work->x0);

  work->use_x0 = 1;
  solver->sol->status = QOCO_UNSOLVED;
}

void qoco_update_matrix_data(QOCOSolver* solver, QOCOFloat* Pxnew,
                             QOCOFloat* Axnew, QOCOFloat* Gxnew)
{
  solver->sol->status = QOCO_UNSOLVED;
  QOCOProblemData* data = solver->work->data;
  QOCOScaling* scaling = solver->work->scaling;

  set_cpu_mode(1);
  // Undo regularization.
  QOCOCscMatrix* Pcsc = get_csc_matrix(data->P);
  unregularize(Pcsc, solver->settings->kkt_static_reg_P);

  // Unequilibrate P.
  QOCOFloat* Px = Pcsc->x;
  QOCOInt Pnnz = get_nnz(data->P);
  QOCOFloat* Dinvruiz_data = get_data_vectorf(scaling->Dinvruiz);
  scale_arrayf(Px, Px, scaling->kinv, Pnnz);
  row_col_scale(Pcsc, Dinvruiz_data, Dinvruiz_data);

  // Unequilibrate c.
  QOCOFloat* cdata = get_data_vectorf(data->c);
  scale_arrayf(cdata, cdata, scaling->kinv, data->n);
  ew_product(cdata, Dinvruiz_data, cdata, data->n);

  // Unequilibrate A.
  QOCOCscMatrix* Acsc = get_csc_matrix(data->A);
  QOCOFloat* Einvruiz_data = get_data_vectorf(scaling->Einvruiz);
  row_col_scale(Acsc, Einvruiz_data, Dinvruiz_data);

  // Unequilibrate G.
  QOCOCscMatrix* Gcsc = get_csc_matrix(data->G);
  QOCOFloat* Finvruiz_data = get_data_vectorf(scaling->Finvruiz);
  row_col_scale(Gcsc, Finvruiz_data, Dinvruiz_data);

  // Unequilibrate b.
  QOCOFloat* bdata = get_data_vectorf(data->b);
  ew_product(bdata, Einvruiz_data, bdata, data->p);

  // Unequilibrate h.
  QOCOFloat* hdata = get_data_vectorf(data->h);
  ew_product(hdata, Finvruiz_data, hdata, data->m);

  // Update P and avoid nonzeros that were added for regularization.
  if (Pxnew) {
    QOCOInt source = 0, added = 0;
    for (QOCOInt i = 0; i < Pnnz; ++i) {
      if (added < data->Pnum_nzadded && i == data->Pnzadded_idx[added]) {
        Px[i] = 0.0;
        ++added;
      } else {
        Px[i] = Pxnew[source++];
      }
    }
  }

  // Update A.
  if (Axnew) {
    QOCOCscMatrix* Atcsc = get_csc_matrix(data->At);
    QOCOFloat* Ax = Acsc->x;
    QOCOFloat* Atx = Atcsc->x;
    QOCOInt Annz = get_nnz(data->A);
    for (QOCOInt i = 0; i < Annz; ++i) {
      Ax[i] = Axnew[i];
      Atx[data->AtoAt[i]] = Axnew[i];
    }
  }

  // Update G.
  if (Gxnew) {
    QOCOCscMatrix* Gtcsc = get_csc_matrix(data->Gt);
    QOCOFloat* Gx = Gcsc->x;
    QOCOFloat* Gtx = Gtcsc->x;
    QOCOInt Gnnz = get_nnz(data->G);
    for (QOCOInt i = 0; i < Gnnz; ++i) {
      Gx[i] = Gxnew[i];
      Gtx[data->GtoGt[i]] = Gxnew[i];
    }
  }

  compute_scaling_statistics(data);

  // Equilibrate new matrix data.
  ruiz_equilibration(data, scaling, solver->settings->ruiz_iters);

  // Regularize P.
  unregularize(Pcsc, -solver->settings->kkt_static_reg_P);
  set_cpu_mode(0);

  // Sync the new data to the GPU.
  sync_matrix_values_to_device(data->P);
  sync_matrix_values_to_device(data->A);
  sync_matrix_values_to_device(data->G);

  solver->linsys->linsys_update_data(solver->linsys_data, data);
}

int qoco_gpu_ipm_finish_device(QOCOSolver*);
QOCOInt qoco_solve(QOCOSolver* solver)
{
  if (qoco_gpu_ipm_finish_device(solver)) {
    fprintf(stderr, "Pending GPU replay could not complete\n"); exit(1);
  }
  QOCOWorkspace* work = solver->work;
  QOCOProblemData* data = solver->work->data;

  // Best iterates are valid only for this solve's coefficients and scaling.
  // Keep device allocations and the explicitly requested primal warm start.
  work->best_valid = 0;
  work->best_iter = -1;
  work->best_metric = 0.0;
  work->ir_iters = 0;
  solver->sol->iters = 0;
  solver->sol->ir_iters = 0;
  solver->sol->status = QOCO_UNSOLVED;

  start_timer(&(work->solve_timer));

  // Validate settings.
  if (qoco_validate_settings(solver->settings)) {
    return qoco_error(QOCO_SETTINGS_VALIDATION_ERROR);
  }

  if (solver->settings->verbose) {
    print_header(solver);
  }

  // Get initializations for primal and dual variables.
  log_ipm_iter(0);
  if (qoco_gpu_ipm_initialization_enabled()) qoco_gpu_ipm_allocate_control(solver);
  else {
    qoco_gpu_reset_control(solver);
    qoco_gpu_ir_reset_counts(solver, 1);
    initialize_ipm(solver);
  }
  const int gpu_ipm_result = qoco_gpu_ipm_loop(solver);
  if (gpu_ipm_result) {
    stop_timer(&(work->solve_timer));
    if (gpu_ipm_result != 2) {
      if (solver->sol->status == QOCO_NUMERICAL_ERROR || solver->sol->status == QOCO_MAX_ITER)
        restore_best_iterate(solver);
      unscale_variables(work);
    }
    copy_solution(solver);
    qoco_gpu_ir_report_counts(solver);
    return solver->sol->status;
  }
  for (QOCOInt i = 1; i <= solver->settings->max_iters; ++i) {

    // Compute kkt residual.
    compute_kkt_residual(data, work->x, work->y, work->s, work->z, work->kktres,
                         solver->settings->kkt_static_reg_P, work->xyzbuff1,
                         work->xbuff, work->ubuff1);

    // Check stopping criteria.
    if (check_stopping(solver)) {
      stop_timer(&(work->solve_timer));
      // On numerical error, restore the best iterate seen so far. The helper
      // can upgrade the status to QOCO_SOLVED_INACCURATE if the saved
      // iterate satisfies the inaccurate tolerance.
      unsigned char restored = 0;
      if (solver->sol->status == QOCO_NUMERICAL_ERROR) {
        restored = restore_best_iterate(solver);
      }
      unscale_variables(work);
      copy_solution(solver);
  qoco_gpu_ir_report_counts(solver);
      if (solver->settings->verbose) {
        if (restored) {
          printf("Best iterate (%d) restored\n", work->best_iter);
        }
        print_footer(solver->sol, solver->sol->status);
      }
      return solver->sol->status;
    }
    log_ipm_iter(i);

    // Compute Nesterov-Todd scalings.
    compute_nt_scaling(work);

    // Update Nestrov-Todd block of KKT matrix.
    solver->linsys->linsys_update_nt(solver->linsys_data, work->WtW,
                                     solver->settings->kkt_static_reg_G,
                                     data->m);

    // Reset IR iteration counter for this IPM step.
    qoco_gpu_ir_reset_counts(solver, 0);
    work->ir_iters = 0;

    // Perform predictor-corrector.
    predictor_corrector(solver);

    // Update iteration count.
    solver->sol->iters = i;
    qoco_gpu_ir_finish_step(solver);

    // Log solver progress to console if we are solving in verbose mode.
    if (solver->settings->verbose) {
      log_iter(solver);
    }
  }

  stop_timer(&(work->solve_timer));
  solver->sol->status = QOCO_MAX_ITER;
  // Restore the best iterate; if it satisfies the inaccurate tolerance, the
  // status is upgraded to QOCO_SOLVED_INACCURATE inside the helper.
  unsigned char restored = restore_best_iterate(solver);
  unscale_variables(work);
  copy_solution(solver);
  qoco_gpu_ir_report_counts(solver);
  if (solver->settings->verbose) {
    if (restored) {
      printf("Best iterate (%d) restored\n", work->best_iter);
    }
    print_footer(solver->sol, solver->sol->status);
  }
  return solver->sol->status;
}

QOCOInt qoco_cleanup(QOCOSolver* solver)
{

  qoco_gpu_free_control(solver->work);

  // Free problem data.
  free_qoco_matrix(solver->work->data->P);
  free_qoco_matrix(solver->work->data->A);
  free_qoco_matrix(solver->work->data->G);
  free_qoco_matrix(solver->work->data->At);
  free_qoco_matrix(solver->work->data->Gt);

  qoco_free(solver->work->data->AtoAt);
  qoco_free(solver->work->data->GtoGt);
  free_qoco_vectorf(solver->work->data->b);
  free_qoco_vectorf(solver->work->data->c);
  free_qoco_vectorf(solver->work->data->h);
  free_qoco_vectori(solver->work->data->q);
  qoco_free(solver->work->data->Pnzadded_idx);
  qoco_free(solver->work->data);

  // Cleanup linsys.
  solver->linsys->linsys_cleanup(solver->linsys_data);

  // Free primal and dual variables.
  free_qoco_vectorf(solver->work->rhs);
  free_qoco_vectorf(solver->work->kktres);
  free_qoco_vectorf(solver->work->xyz);
  free_qoco_vectorf(solver->work->xyzbuff1);
  free_qoco_vectorf(solver->work->x);
  free_qoco_vectorf(solver->work->x0);
  free_qoco_vectorf(solver->work->s);
  free_qoco_vectorf(solver->work->y);
  free_qoco_vectorf(solver->work->z);
  free_qoco_vectorf(solver->work->best_x);
  free_qoco_vectorf(solver->work->best_s);
  free_qoco_vectorf(solver->work->best_y);
  free_qoco_vectorf(solver->work->best_z);

  // Free Nesterov-Todd scalings and scaled variables.
  free_qoco_vectorf(solver->work->W);
  free_qoco_vectorf(solver->work->nt_scaling);
  free_qoco_vectorf(solver->work->Winv);
  free_qoco_vectorf(solver->work->WtW);
  free_qoco_vectori(solver->work->nt_scaling_soc_idx);
  free_qoco_vectori(solver->work->soc_idx);
  free_qoco_vectorf(solver->work->lambda);
  free_qoco_vectorf(solver->work->sbar);
  free_qoco_vectorf(solver->work->zbar);
  free_qoco_vectorf(solver->work->xbuff);
  free_qoco_vectorf(solver->work->ybuff);
  free_qoco_vectorf(solver->work->ubuff1);
  free_qoco_vectorf(solver->work->ubuff2);
  free_qoco_vectorf(solver->work->ubuff3);
  free_qoco_vectorf(solver->work->Ds);

  // Free scaling struct.
  free_qoco_vectorf(solver->work->scaling->delta);
  free_qoco_vectorf(solver->work->scaling->Druiz);
  free_qoco_vectorf(solver->work->scaling->Eruiz);
  free_qoco_vectorf(solver->work->scaling->Fruiz);
  free_qoco_vectorf(solver->work->scaling->Dinvruiz);
  free_qoco_vectorf(solver->work->scaling->Einvruiz);
  free_qoco_vectorf(solver->work->scaling->Finvruiz);
  qoco_free(solver->work->scaling);

  // Free solution struct.
  qoco_free(solver->sol->x);
  qoco_free(solver->sol->s);
  qoco_free(solver->sol->y);
  qoco_free(solver->sol->z);
  qoco_free(solver->sol);

  qoco_free(solver->work);
  qoco_free(solver->settings);
  qoco_free(solver);

  return 1;
}