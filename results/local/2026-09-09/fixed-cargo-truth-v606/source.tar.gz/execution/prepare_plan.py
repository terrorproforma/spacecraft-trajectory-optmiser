"""Freeze the four prescribed schedules with native-library loading blocked."""

import ctypes
import os
from unittest.mock import patch

import common

common.activate_source()
os.environ["SPACEPDHCG_GTOC12_DATA"] = (
    "/home/angus/worktrees/spacepdhcg-release/benchmarks/gtoc12/data"
)
from plan import make_plan  # noqa: E402

from spacepdhcg.gtoc12.data import load_bonus_table, load_catalogue  # noqa: E402

with patch.object(ctypes, "CDLL", side_effect=AssertionError("no native work in CPU preparation")):
    summaries, audit, _ = common.load_inputs()
    catalogue, bonus = load_catalogue(), load_bonus_table()
    assert catalogue.source_sha256 == common.DATA_SHA and bonus.source_sha256 == common.BONUS_SHA
    weights = {int(body): float(bonus.for_asteroid(int(body))) for body in catalogue.ids}
    plan = make_plan(summaries, audit, weights)
directory = common.ROOT / "plan"
directory.mkdir(exist_ok=False)
common.write(directory / "plan.json", plan)
common.write(
    directory / "report.json",
    {
        "status": "CPU_prepared_no_GPU",
        "GPU_calls": 0,
        "plan_sha256": common.sha(directory / "plan.json"),
        "cases": len(plan["cases"]),
        "maximum_leg_calls": plan["maximum_leg_calls"],
    },
)
print({"cases": len(plan["cases"]), "maximum_leg_calls": plan["maximum_leg_calls"], "GPU_calls": 0})
