from pathlib import Path
import os,subprocess,json,time,fcntl,hashlib
root=Path('/home/ubuntu/spacepdhcg-verification-v176');repo=root/'repo'
lock=open('/home/ubuntu/.spacepdhcg-gpu.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
report=dict(start=time.time(),pid=os.getpid(),steps=[])
env=os.environ.copy();env.update(PYTHONPATH=str(repo/'src'),SPACEPDHCG_GTOC12_CUDA_LIBRARY=str(root/'libverify.so'),SPACEPDHCG_GTOC12_GPU_TESTS='1')
python='/home/ubuntu/spacepdhcg/v1/.venv/bin/python'
def run(name,cmd,timeout=240):
 start=time.time()
 with (root/(name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 report['steps'].append(dict(name=name,command=cmd,returncode=r.returncode,seconds=time.time()-start));(root/'report.json').write_text(json.dumps(report,indent=2));return r.returncode
run('hardware',['nvidia-smi','--query-gpu=name,utilization.gpu,memory.used','--format=csv'])
code=run('build',['/usr/local/cuda/bin/nvcc','-std=c++20','-arch=sm_90','--fmad=false','-lineinfo','-shared','-Xcompiler=-fPIC,-Wall,-Wextra,-Werror','-Icpp/cuda/include','-Icpp/cuda/internal','cpp/cuda/src/gtoc12_verification.cu','-o',str(root/'libverify.so')])
if code==0:
 report['runtime_sha256']=hashlib.sha256((root/'libverify.so').read_bytes()).hexdigest()
 boot="import sys,runpy;sys.meta_path=[f for f in sys.meta_path if f.__class__.__module__!='_editable_skbc_spacepdhcg'];runpy.run_module('pytest',run_name='__main__')"
 run('tests',[python,'-c',boot,'tests/test_gtoc12_gpu_verifier.py','tests/test_gtoc12_verifier.py','-q','--tb=short'])
 benchmark="import sys,runpy;sys.meta_path=[f for f in sys.meta_path if f.__class__.__module__!='_editable_skbc_spacepdhcg'];sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name='__main__')"
 run('fleet',[python,'-c',benchmark,'scripts/gpu/benchmark_gtoc12_verifier.py','results/lambda/2026-09-06/fleet_master_v11/fleet/Result.txt',str(root/'fleet.json'),'--cpu-legs','413'])
 run('memcheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','98',python,'-c',boot,'tests/test_gtoc12_gpu_verifier.py','-q','--tb=short'])
report['end']=time.time();report['complete']=True;(root/'report.json').write_text(json.dumps(report,indent=2))
