
__global__ void qoco_ipm_update_guard(const QocoIpmParameters* p,
    cudaGraphConditionalHandle handle,QocoGpuCompletion* result) {
    cudaGraphSetConditional(handle,!p->update_invalid);
    if (p->update_invalid) *result={1,QOCO_NUMERICAL_ERROR,0,0,0,0,
        INFINITY,INFINITY,INFINITY,NAN,p->dynamic_reg};
}
// SPDX-License-Identifier: Apache-2.0
// Experimental whole-IPM graph. Requires --default-stream per-thread and the
// retained factor/IR/control/count extensions. Setup and terminal reports are host work.
struct QocoIpmCapture {
    cudaGraph_t graph{};
    cudaGraph_t linear{};
    QocoIpmParameters* parameters{};
    std::vector<cudaGraphNode_t> dependencies;
};
static thread_local QocoIpmCapture* qoco_ipm_current = nullptr;
extern "C" int qoco_gpu_ipm_capturing() { return qoco_ipm_current != nullptr; }
extern "C" void qoco_gpu_ipm_prepare(QOCOSolver*);
extern "C" void qoco_gpu_ipm_check(QOCOSolver*, const int*, cudaGraphConditionalHandle,
                                    cudaGraphConditionalHandle, const QocoIpmParameters*);
extern "C" void qoco_gpu_ipm_advance(QOCOSolver*, int*, cudaGraphConditionalHandle, const QocoIpmParameters*);
extern "C" void qoco_gpu_sync_control(QOCOSolver*);
extern "C" void qoco_gpu_ipm_terminal(QOCOSolver*, const QocoIpmParameters*);
extern "C" void qoco_gpu_ipm_completion(QOCOSolver*, const int*, const int*, const int*, QocoGpuCompletion*);

static void qoco_ipm_pause() {
    auto& c = *qoco_ipm_current;
    cudaStreamCaptureStatus status;
    const cudaGraphNode_t* dependencies = nullptr;
    size_t count = 0;
    CUDA_CHECK(cudaStreamGetCaptureInfo(cudaStreamPerThread, &status, nullptr, &c.graph,
                                       &dependencies, &count));
    c.dependencies.assign(dependencies, dependencies + count);
    cudaGraph_t ended;
    CUDA_CHECK(cudaStreamEndCapture(cudaStreamPerThread, &ended));
    if (ended != c.graph) { fprintf(stderr, "IPM capture graph mismatch\n"); exit(1); }
}
static void qoco_ipm_resume() {
    auto& c = *qoco_ipm_current;
    CUDA_CHECK(cudaStreamBeginCaptureToGraph(cudaStreamPerThread, c.graph,
        c.dependencies.data(), nullptr, c.dependencies.size(), cudaStreamCaptureModeThreadLocal));
}
static void qoco_ipm_child(cudaGraph_t child) {
    qoco_ipm_pause();
    auto& c = *qoco_ipm_current;
    cudaGraphNode_t node;
    CUDA_CHECK(cudaGraphAddChildGraphNode(&node, c.graph, c.dependencies.data(),
                                          c.dependencies.size(), child));
    c.dependencies = {node};
    qoco_ipm_resume();
}
static void qoco_ipm_factor(LinSysData* s) {
    if (!s->ir->factor_memory->factor_graph) {
        fprintf(stderr, "IPM requires primed retained factorization\n"); exit(1);
    }
    qoco_ipm_child(s->ir->factor_memory->factor_graph);
}
static void qoco_ipm_linear(LinSysData* s, QOCOWorkspace* work, const double* b,
                            double* x, double tolerance, int maximum) {
    auto& c = *qoco_ipm_current;
    auto* runtime = s->ir;
    const int count = s->Kn;
    const size_t bytes = count * sizeof(double);
    auto* norm = runtime->norm_scratch + 256;
    auto* best = get_data_vectorf(work->xyzbuff1);
    CUDA_CHECK(cudaMemcpyAsync(s->d_rhs_matrix_data, b, bytes, cudaMemcpyDeviceToDevice));
    CUDA_CHECK(cudaMemsetAsync(s->d_xyz_matrix_data, 0, bytes));
    qoco_kkt_equilibration::rhs(s,cudaStreamPerThread);
    qoco_ipm_child(c.linear);
    qoco_kkt_equilibration::solution(s,cudaStreamPerThread);
    CUDA_CHECK(cudaMemcpyAsync(x, s->d_xyz_matrix_data, bytes, cudaMemcpyDeviceToDevice));

    // Emit the refinement conditional into the parent; conditional graphs cannot
    // be cloned as ordinary child graphs. All arithmetic matches the retained IR path.
    qoco_ipm_pause();
    cudaGraphConditionalHandle handle;
    CUDA_CHECK(cudaGraphConditionalHandleCreate(&handle, c.graph, 0, cudaGraphCondAssignDefault));
    qoco_ipm_resume();
    (void)tolerance; (void)maximum;
    qoco_ipm_ir_parameters<<<1, 1>>>(runtime->cache.parameters, c.parameters);
    compute_linsys_residual(s, work, b, x, s->d_xyz_matrix_data, false);
    qoco_ir_device_norm(s->d_xyz_matrix_data, count, runtime->norm_scratch, cudaStreamPerThread);
    CUDA_CHECK(cudaMemcpyAsync(best, x, bytes, cudaMemcpyDeviceToDevice));
    qoco_ir_initial<<<1, 1>>>(runtime->state, norm, handle, runtime->cache.parameters);
    CUDA_CHECK(cudaGetLastError());
    qoco_ipm_pause();
    const auto parent = c.graph;
    cudaGraphNodeParams params{};
    params.type = cudaGraphNodeTypeConditional;
    params.conditional.handle = handle;
    params.conditional.type = cudaGraphCondTypeWhile;
    params.conditional.size = 1;
    cudaGraphNode_t conditional;
    CUDA_CHECK(cudaGraphAddNode(&conditional, parent, c.dependencies.data(),
                                 c.dependencies.size(), &params));
    c.graph = params.conditional.phGraph_out[0];
    c.dependencies.clear();
    qoco_ipm_resume();
    CUDA_CHECK(cudaMemcpyAsync(s->d_rhs_matrix_data, s->d_xyz_matrix_data, bytes, cudaMemcpyDeviceToDevice));
    CUDA_CHECK(cudaMemsetAsync(s->d_xyz_matrix_data, 0, bytes));
    qoco_kkt_equilibration::rhs(s,cudaStreamPerThread);
    qoco_ipm_child(c.linear);
    qoco_kkt_equilibration::solution(s,cudaStreamPerThread);
    qoco_axpy(s->d_xyz_matrix_data, x, x, 1.0, count);
    compute_linsys_residual(s, work, b, x, s->d_xyz_matrix_data, false);
    qoco_ir_device_norm(s->d_xyz_matrix_data, count, runtime->norm_scratch, cudaStreamPerThread);
    qoco_ir_decide<<<1, 1>>>(runtime->state, norm, handle, runtime->cache.parameters);
    qoco_ir_save_or_restore<<<(count + 255) / 256, 256>>>(runtime->state, x, best, count);
    CUDA_CHECK(cudaGetLastError());
    qoco_ipm_pause();
    c.graph = parent;
    c.dependencies = {conditional};
    qoco_ipm_resume();
    qoco_ir_add_count_kernel<<<1, 1>>>(runtime->counts, runtime->state);
    CUDA_CHECK(cudaGetLastError());
}

#include "qoco_ipm_warmstart.cuh"
extern "C" void qoco_gpu_ipm_initial_control(QOCOSolver*, const QocoIpmParameters*);
extern "C" int qoco_gpu_ipm_initialization_enabled() {
    const char* enabled = getenv("SPACEPDHCG_TEST_QOCO_IPM_GRAPH");
    return enabled && enabled[0] == '1' && !getenv("SPACEPDHCG_TEST_QOCO_IPM_INIT_DISABLE");
}

__global__ void qoco_ipm_reset_nested(int* iterations,cudaGraphConditionalHandle loop) {
    *iterations=0;
    cudaGraphSetConditional(loop,1);
}
static cudaGraphNode_t qoco_ipm_emit_body(QOCOSolver* solver,QocoIpmCapture& capture,
    bool initialization,bool terminal) {
    auto* s=solver->linsys_data;
    auto* work=solver->work;
    auto* data=work->data;
    auto& cache=s->ir->ipm;
    const auto root=capture.graph;
    cudaGraphConditionalHandle valid_update;
    CUDA_CHECK(cudaGraphConditionalHandleCreate(&valid_update,root,1,cudaGraphCondAssignDefault));
    qoco_ipm_current = &capture;
    qoco_ipm_resume();
    qoco_ipm_update_guard<<<1,1>>>(cache.parameters,valid_update,cache.completion);
    qoco_ipm_pause();
    cudaGraphNodeParams guard_params{};
    guard_params.type=cudaGraphNodeTypeConditional;
    guard_params.conditional.handle=valid_update;
    guard_params.conditional.type=cudaGraphCondTypeIf;
    guard_params.conditional.size=1;
    cudaGraphNode_t guard_node;
    CUDA_CHECK(cudaGraphAddNode(&guard_node,root,capture.dependencies.data(),capture.dependencies.size(),&guard_params));
    const auto solve_graph=guard_params.conditional.phGraph_out[0];
    capture.graph=solve_graph; capture.dependencies.clear();
    if (initialization) {
        qoco_ipm_resume();
        qoco_gpu_ipm_initial_control(solver, cache.parameters);
        qoco_gpu_ir_reset_counts(solver, 1);
        initialize_ipm(solver);
        qoco_ipm_pause();
    }
    int* iterations = cache.iterations;
    cudaGraphConditionalHandle loop, step;
    CUDA_CHECK(cudaGraphConditionalHandleCreate(&loop, solve_graph, 1, cudaGraphCondAssignDefault));
    qoco_ipm_resume();
    qoco_ipm_reset_nested<<<1,1>>>(iterations,loop);
    qoco_ipm_pause();
    cudaGraphNodeParams params{};
    params.type = cudaGraphNodeTypeConditional;
    params.conditional.handle = loop;
    params.conditional.type = cudaGraphCondTypeWhile;
    params.conditional.size = 1;
    cudaGraphNode_t node;
    CUDA_CHECK(cudaGraphAddNode(&node, solve_graph, capture.dependencies.data(),
        capture.dependencies.size(), &params));
    const auto loop_node = node;
    const auto body = params.conditional.phGraph_out[0];
    CUDA_CHECK(cudaGraphConditionalHandleCreate(&step, body, 0, cudaGraphCondAssignDefault));
    capture.graph = body;
    capture.dependencies.clear();
    qoco_ipm_current = &capture;
    qoco_ipm_resume();
    compute_kkt_residual(data, work->x, work->y, work->s, work->z, work->kktres,
        solver->settings->kkt_static_reg_P, work->xyzbuff1, work->xbuff, work->ubuff1);
    qoco_gpu_ipm_check(solver, iterations, loop, step, cache.parameters);
    qoco_ipm_pause();
    params = {};
    params.type = cudaGraphNodeTypeConditional;
    params.conditional.handle = step;
    params.conditional.type = cudaGraphCondTypeIf;
    params.conditional.size = 1;
    CUDA_CHECK(cudaGraphAddNode(&node, body, capture.dependencies.data(),
                                 capture.dependencies.size(), &params));
    capture.graph = params.conditional.phGraph_out[0];
    capture.dependencies.clear();
    qoco_ipm_resume();
    compute_nt_scaling(work);
    solver->linsys->linsys_update_nt(s, work->WtW, solver->settings->kkt_static_reg_G, data->m);
    qoco_gpu_ir_reset_counts(solver, 0);
    predictor_corrector(solver);
    qoco_gpu_ir_finish_step(solver);
    qoco_gpu_ipm_advance(solver, iterations, loop, cache.parameters);
    qoco_ipm_pause();
    if (terminal) {
        capture.graph = solve_graph;
        capture.dependencies = {loop_node};
        qoco_ipm_resume();
        qoco_gpu_ipm_terminal(solver, cache.parameters);
        qoco_gpu_ipm_completion(solver, cache.iterations, &s->ir->counts->step,
            &s->ir->counts->total, cache.completion);
        qoco_ipm_pause();
    }
    qoco_ipm_current = nullptr;
    return guard_node;
}

extern "C" int qoco_gpu_ipm_loop(QOCOSolver* solver) {
    const char* enabled = getenv("SPACEPDHCG_TEST_QOCO_IPM_GRAPH");
    if (!enabled || enabled[0] != '1') return 0;
    if (!solver->work->gpu_control || !qoco_ir_counts_enabled() || solver->settings->verbose ||
        getenv("SPACEPDHCG_TEST_QOCO_DEVICE_STEPS_COMPARE") ||
        getenv("SPACEPDHCG_TEST_QOCO_COMBINED_RHS_COMPARE") ||
        getenv("SPACEPDHCG_TEST_QOCO_DEVICE_CONTROL_COMPARE")) {
        fprintf(stderr, "IPM graph requires GPU controls/counting and non-verbose, unaudited execution\n"); exit(1);
    }
    const bool initialization = qoco_gpu_ipm_initialization_enabled();
    const bool terminal = !getenv("SPACEPDHCG_TEST_QOCO_IPM_TERMINAL_DISABLE");
    if (initialization && getenv("SPACEPDHCG_TEST_QOCO_HOST_INITIAL_CONE")) {
        fprintf(stderr, "GPU initialisation requires device cone shifts\n"); exit(1);
    }
    auto* s = solver->linsys_data;
    auto* work = solver->work;
    auto* data = work->data;
    auto& cache = s->ir->ipm;
    cache.resources = qoco_gpu_ipm_resources_enter(cache.resources);
    if (!cache.parameters) {
        CUDA_CHECK(cudaMalloc(&cache.parameters, sizeof(QocoIpmParameters)));
        CUDA_CHECK(cudaMalloc(&cache.iterations, sizeof(int)));
        CUDA_CHECK(cudaMalloc(&cache.completion, sizeof(QocoGpuCompletion)));
    }
    auto* settings = solver->settings;
    const QocoIpmParameters parameters{work->scaling->k, work->scaling->kinv,
        settings->abstol, settings->reltol, settings->abstol_inacc, settings->reltol_inacc,
        settings->ir_tol, settings->max_iters, settings->max_ir_iters,
        settings->kkt_dynamic_reg, int(work->use_x0)};
    qoco_ipm_parameters_set<<<1, 1>>>(cache.parameters, parameters);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaMemsetAsync(cache.iterations, 0, sizeof(int)));
    // QOCO's fixed-topology workspace owns every captured operand. Static
    // regularisation changes are rare and invalidate rather than freeze a value.
    if (cache.executable && (cache.terminal != terminal || cache.initialization != initialization || cache.work != work || cache.control != work->gpu_control ||
        cache.static_p != settings->kkt_static_reg_P || cache.static_a != settings->kkt_static_reg_A ||
        cache.static_g != settings->kkt_static_reg_G || cache.linsys_static_p != s->kkt_static_reg_P)) {
        CUDA_CHECK(cudaDeviceSynchronize());
        qoco_ipm_cache_clear(cache);
    }
    if (!cache.executable) {
    // Prime vendor analysis/factor/SOLVE kernels once before graph capture.
    if (initialization) initialize_ipm(solver);
    qoco_ir_prepare_sparse(data);
    compute_kkt_residual(data, work->x, work->y, work->s, work->z, work->kktres,
        solver->settings->kkt_static_reg_P, work->xyzbuff1, work->xbuff, work->ubuff1);
    qoco_gpu_ipm_prepare(solver);
    CUDA_CHECK(cudaDeviceSynchronize());
    QocoIpmCapture capture;
    capture.parameters = cache.parameters;
    const auto stream = s->ir->stream;
    CUDA_CHECK(cudaStreamBeginCapture(stream, cudaStreamCaptureModeThreadLocal));
    CUDSS_CHECK(g_cuda_funcs.cudssExecute(s->handle, CUDSS_PHASE_SOLVE, s->config, s->data,
                                         s->K_csr, s->d_xyz_matrix, s->d_rhs_matrix));
    CUDA_CHECK(cudaStreamEndCapture(stream, &capture.linear));
    qoco_ir_snapshot_ranges(capture.linear, s->ir, s->Kn);
    CUDA_CHECK(cudaGraphCreate(&capture.graph, 0));
    const auto root = capture.graph;
    qoco_ipm_emit_body(solver,capture,initialization,terminal);
    cudaGraphExec_t executable;
    cudaGraphNode_t error_node = nullptr;
    char error_log[8192] = {};
    const auto instantiate_status = cudaGraphInstantiate(&executable, root, &error_node,
                                                         error_log, sizeof(error_log));
    if (instantiate_status != cudaSuccess) {
        cudaGraphNodeType type = cudaGraphNodeTypeEmpty;
        if (error_node) cudaGraphNodeGetType(error_node, &type);
        fprintf(stderr, "IPM instantiate error node=%p type=%d log=%s\n",
                static_cast<void*>(error_node), int(type), error_log);
        const char* dump = getenv("SPACEPDHCG_TEST_QOCO_IPM_DOT");
        if (dump) cudaGraphDebugDotPrint(root, dump, cudaGraphDebugDotFlagsVerbose);
    }
    CUDA_CHECK(instantiate_status);
    cache.initialization = initialization;
    cache.terminal = terminal;
    cache.executable = executable;
    cache.graph = root; cache.linear = capture.linear;
    cache.work = work; cache.control = work->gpu_control;
    cache.static_p = settings->kkt_static_reg_P; cache.static_a = settings->kkt_static_reg_A;
    cache.static_g = settings->kkt_static_reg_G; cache.linsys_static_p = s->kkt_static_reg_P;
    ++cache.builds;
    }
    CUDA_CHECK(cudaGraphLaunch(cache.executable, cudaStreamPerThread));
    ++cache.launches;
    CUDA_CHECK(cudaMemcpy(&solver->sol->iters, cache.iterations, sizeof(int), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaStreamSynchronize(cudaStreamPerThread));
    qoco_gpu_sync_control(solver);
    qoco_gpu_ipm_resources_leave(cache.resources);
    if (getenv("SPACEPDHCG_TEST_QOCO_IPM_CACHE_DISABLE")) qoco_ipm_cache_clear(cache);
    return terminal ? 2 : 1;
}

#include "qoco_ipm_replay.cuh"

#include "qoco_ipm_outer_graph.cuh"
