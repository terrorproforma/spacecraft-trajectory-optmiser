from pathlib import Path
import os,subprocess,json,fcntl,time
root=Path('/home/ubuntu/spacepdhcg-diagnose-v171');repo=root/'repo';os.chdir(repo)
assert json.loads((root/'report.json').read_text()).get('completed')
out=root/'capture-ruiz0-v172';out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith('SPACEPDHCG_TEST_')}
env.update(SPACEPDHCG_GTOC12_CUDA_LIBRARY=str(root/'final/libspacepdhcg_cuda.so'),SPACEPDHCG_QOCO_LIBRARY=str(root/'final/libqoco.so'),SPACEPDHCG_GTOC12_GPU_TESTS='1',PYTHONPATH=str(repo/'src'),LD_LIBRARY_PATH=str(root/'final')+':/home/ubuntu/spacepdhcg-recovery-v152/cudss/lib:/usr/local/cuda/lib64',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',SPACEPDHCG_TEST_QOCO_IPM_GRAPH='1',SPACEPDHCG_TEST_GTOC12_DEVICE_SCHEDULING='0',SPACEPDHCG_TEST_GTOC12_DEFERRED_REPORTS='1',SPACEPDHCG_TEST_GTOC12_STATE_ORIGIN='0',TEST_RUIZ='0')
py='/home/ubuntu/spacepdhcg/v1/.venv/bin/python'
prefix="import sys;sys.meta_path=[f for f in sys.meta_path if f.__class__.__module__!='_editable_skbc_spacepdhcg'];"
rows=[]
with Path('/home/ubuntu/.spacepdhcg-gpu.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for repetition in range(16):
  capture=out/f'leg-{repetition}';capture.mkdir();result=capture/'trajectory.json'
  env['SPACEPDHCG_QOCO_SNAPSHOT_DIRECTORY']=str(capture)
  command=[py,'-c',prefix+"import runpy;sys.argv=['build/performance/diagnose_outer_leg_v158.py',sys.argv[1]];runpy.run_path(sys.argv[0],run_name='__main__')",str(result)]
  start=time.time();r=subprocess.run(command,env=env,capture_output=True,text=True,timeout=90)
  row=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.time()-start,result=json.loads(result.read_text()) if result.exists() else None)
  rows.append(row);(out/'report.json').write_text(json.dumps(rows,indent=2));print(repetition,r.returncode,r.stdout[-1000:],flush=True)
  if not row['result'] or not row['result']['qualified']:break
(out/'completed').write_text('done\n')
