#include "kkt.h"
/**
 * @file utils.c
 * @author Govind M. Chari <govindchari1@gmail.com>
 *
 * @section LICENSE
 *
 * Copyright (c) 2024, Govind M. Chari
 * This source code is licensed under the BSD 3-Clause License
 */

#include "qoco_utils.h"
void qoco_gpu_sync_control(QOCOSolver*);

void print_qoco_csc_matrix(QOCOCscMatrix* M)
{
  printf("\nPrinting CSC Matrix:\n");
  printf("m: %d\n", M->m);
  printf("n: %d\n", M->n);
  printf("nnz: %d\n", M->nnz);
  printf("Data: {");
  for (QOCOInt i = 0; i < M->nnz; ++i) {
    printf("%" QOCOFloat_PRINT_FORMAT, QOCOFloat_PRINT_ARG(M->x[i]));
    if (i != M->nnz - 1) {
      printf(",");
    }
  }
  printf("}\n");

  printf("Row Indices: {");
  for (QOCOInt i = 0; i < M->nnz; ++i) {
    printf("%d", M->i[i]);
    if (i != M->nnz - 1) {
      printf(",");
    }
  }
  printf("}\n");

  printf("Column Pointers: {");
  for (QOCOInt i = 0; i < M->n + 1; ++i) {
    printf("%d", M->p[i]);
    if (i != M->n) {
      printf(",");
    }
  }
  printf("}\n");
}

void print_arrayf(QOCOFloat* x, QOCOInt n)
{
  printf("{");
  for (QOCOInt i = 0; i < n; ++i) {
    printf("%" QOCOFloat_PRINT_FORMAT, QOCOFloat_PRINT_ARG(x[i]));
    if (i != n - 1) {
      printf(", ");
    }
  }
  printf("}\n");
}

void print_arrayi(QOCOInt* x, QOCOInt n)
{
  printf("{");
  for (QOCOInt i = 0; i < n; ++i) {
    printf("%d", x[i]);
    if (i != n - 1) {
      printf(", ");
    }
  }
  printf("}\n");
}

void compute_scaling_statistics(QOCOProblemData* data)
{
  // This function runs on the CPU.
  set_cpu_mode(1);

  // Initialize min/max values
  data->obj_range_min = QOCOFloat_MAX;
  data->obj_range_max = 0.0;
  data->constraint_range_min = QOCOFloat_MAX;
  data->constraint_range_max = 0.0;
  data->rhs_range_min = QOCOFloat_MAX;
  data->rhs_range_max = 0.0;

  // Compute Objective range: P (prior to regularization) and c
  // Note: This is called before regularization, so P is in its original form
  if (data->P) {
    QOCOCscMatrix* Pcsc = get_csc_matrix(data->P);
    data->obj_range_min = min_abs_val(Pcsc->x, Pcsc->nnz);
    data->obj_range_max = inf_norm(Pcsc->x, Pcsc->nnz);
  }

  // Add c to objective range
  QOCOFloat* cdata = get_data_vectorf(data->c);
  data->obj_range_min =
      qoco_min(data->obj_range_min, min_abs_val(cdata, data->n));
  data->obj_range_max = qoco_max(data->obj_range_max, inf_norm(cdata, data->n));

  // Compute Constraint range: A and G
  if (data->A && get_nnz(data->A) > 0) {
    QOCOCscMatrix* Acsc = get_csc_matrix(data->A);
    data->constraint_range_min = min_abs_val(Acsc->x, Acsc->nnz);
    data->constraint_range_max = inf_norm(Acsc->x, Acsc->nnz);
  }

  if (data->G && get_nnz(data->G) > 0) {
    QOCOCscMatrix* Gcsc = get_csc_matrix(data->G);
    data->constraint_range_min =
        qoco_min(data->constraint_range_min, min_abs_val(Gcsc->x, Gcsc->nnz));
    data->constraint_range_max =
        qoco_max(data->constraint_range_max, inf_norm(Gcsc->x, Gcsc->nnz));
  }

  // Compute RHS range: b and h
  if (data->p > 0) {
    QOCOFloat* bdata = get_data_vectorf(data->b);
    data->rhs_range_min = min_abs_val(bdata, data->p);
    data->rhs_range_max = inf_norm(bdata, data->p);
  }

  if (data->m > 0) {
    QOCOFloat* hdata = get_data_vectorf(data->h);
    data->rhs_range_min =
        qoco_min(data->rhs_range_min, min_abs_val(hdata, data->m));
    data->rhs_range_max =
        qoco_max(data->rhs_range_max, inf_norm(hdata, data->m));
  }
  // Handle case where all values are zero or value is -0.0 (set to 0.0)
  if (data->obj_range_min == QOCOFloat_MAX || data->obj_range_min == 0.0) {
    data->obj_range_min = 0.0;
  }
  if (data->obj_range_max == QOCOFloat_MAX || data->obj_range_max == 0.0) {
    data->obj_range_max = 0.0;
  }
  if (data->constraint_range_min == QOCOFloat_MAX ||
      data->constraint_range_min == 0.0) {
    data->constraint_range_min = 0.0;
  }
  if (data->constraint_range_max == QOCOFloat_MAX ||
      data->constraint_range_max == 0.0) {
    data->constraint_range_max = 0.0;
  }
  if (data->rhs_range_min == QOCOFloat_MAX || data->rhs_range_min == 0.0) {
    data->rhs_range_min = 0.0;
  }
  if (data->rhs_range_max == QOCOFloat_MAX || data->rhs_range_max == 0.0) {
    data->rhs_range_max = 0.0;
  }
  set_cpu_mode(0);
}

void print_header(QOCOSolver* solver)
{
  QOCOProblemData* data = solver->work->data;
  QOCOSettings* settings = solver->settings;

  // clang-format off
  printf("\n");
  printf("+-------------------------------------------------------+\n");
  printf("|     QOCO - Quadratic Objective Conic Optimizer        |\n");
  printf("|                        v%i.%i.%i                         |\n", QOCO_VERSION_MAJOR, QOCO_VERSION_MINOR, QOCO_VERSION_PATCH);
  printf("|             (c) Govind M. Chari, 2025                 |\n");
  printf("|    University of Washington Autonomous Controls Lab   |\n");
  printf("+-------------------------------------------------------+\n");
  printf("| Problem Data:                                         |\n");
  printf("|     variables:        %-9d                       |\n", data->n);
  printf("|     constraints:      %-9d                       |\n", data->l + data->p + data->nsoc);
  printf("|     eq constraints:   %-9d                       |\n", data->p);
  printf("|     ineq constraints: %-9d                       |\n", data->l);
  printf("|     soc constraints:  %-9d                       |\n", data->nsoc);
  printf("|     nnz(P):           %-9d                       |\n", (data->P ? get_nnz(data->P) : 0) - solver->work->data->Pnum_nzadded);
  printf("|     nnz(A):           %-9d                       |\n", get_nnz(data->A));
  printf("|     nnz(G):           %-9d                       |\n", get_nnz(data->G));
  printf("| Scaling Statistics:                                   |\n");
  printf("|     Objective range      [%.0e, %.0e]               |\n", (double)data->obj_range_min, (double)data->obj_range_max);
  printf("|     Constraint range     [%.0e, %.0e]               |\n", (double)data->constraint_range_min, (double)data->constraint_range_max);
  printf("|     RHS range            [%.0e, %.0e]               |\n", (double)data->rhs_range_min, (double)data->rhs_range_max);
  printf("| Solver Settings:                                      |\n");
  printf("|     algebra: %-27s              |\n", solver->linsys->linsys_name());
  printf("|     max_iters: %-3d abstol: %3.2e reltol: %3.2e  |\n", settings->max_iters, (double)settings->abstol, (double)settings->reltol);
  printf("|     abstol_inacc: %3.2e reltol_inacc: %3.2e     |\n", (double)settings->abstol_inacc, (double)settings->reltol_inacc);
  printf("|     kkt_static_reg_P: %3.2e ruiz_iters: %-2d         |\n", (double)settings->kkt_static_reg_P, settings->ruiz_iters);
  printf("|     kkt_static_reg_A: %3.2e max_ir_iters: %-2d       |\n", (double)settings->kkt_static_reg_A, settings->max_ir_iters);
  printf("|     kkt_static_reg_G: %3.2e ir_tol: %3.2e       |\n", (double)settings->kkt_static_reg_G, (double)settings->ir_tol);
  printf("|     kkt_dynamic_reg: %3.2e                         |\n", (double)settings->kkt_dynamic_reg);
  printf("+-------------------------------------------------------+\n");
  printf("\n");
  printf("+--------+-----------+------------+------------+------------+-----------+------+-----------+\n");
  printf("|  Iter  |   Pcost   |    Pres    |    Dres    |     Gap    |     Mu    |  IR  |    Step   |\n");
  printf("+--------+-----------+------------+------------+------------+-----------+------+-----------+\n");
  // clang-format on
}

void log_iter(QOCOSolver* solver)
{
  // clang-format off
  printf("|  %3d   | %+.2e | %+.3e | %+.3e | %+.3e | %+.2e |  %2d  |   %.3f   |\n",
         solver->sol->iters, (double)solver->sol->obj, (double)solver->sol->pres, (double)solver->sol->dres, (double)solver->sol->gap, (double)solver->work->mu, solver->work->ir_iters, (double)solver->work->a);
  printf("+--------+-----------+------------+------------+------------+-----------+------+-----------+\n");
  // clang-format on
}

void print_footer(QOCOSolution* solution, enum qoco_solve_status status)
{
  printf("\n");
  printf("status:                %s\n", QOCO_SOLVE_STATUS_MESSAGE[status]);
  printf("number of iterations:  %d\n", solution->iters);
  printf("objective:             %+.3f\n", (double)solution->obj);
  printf("setup time:            %.2e sec\n", (double)solution->setup_time_sec);
  printf("solve time:            %.2e sec\n", (double)solution->solve_time_sec);
  printf("\n");
}

double qoco_gpu_reference_origin_offset(QOCOSolver* solver);

void qoco_reference_stopping_metrics(QOCOSolver* solver, QOCOFloat* out)
{
  QOCOWorkspace* work = solver->work;
  QOCOProblemData* data = work->data;
  QOCOFloat* xbuff = get_data_vectorf(work->xbuff);
  QOCOFloat* ybuff = get_data_vectorf(work->ybuff);
  QOCOFloat* ubuff1 = get_data_vectorf(work->ubuff1);
  QOCOFloat* ubuff2 = get_data_vectorf(work->ubuff2);
  QOCOFloat* ubuff3 = get_data_vectorf(work->ubuff3);
  QOCOFloat* kktres = get_data_vectorf(work->kktres);

  QOCOFloat* Einvruiz_data = get_data_vectorf(work->scaling->Einvruiz);
  QOCOFloat* bdata = get_data_vectorf(data->b);
  ew_product(Einvruiz_data, bdata, ybuff, data->p);
  QOCOFloat binf = data->p > 0 ? inf_norm(ybuff, data->p) : 0;

  QOCOFloat* Fruiz_data = get_data_vectorf(work->scaling->Fruiz);
  QOCOFloat* sdata = get_data_vectorf(work->s);
  ew_product(get_data_vectorf(work->scaling->Finvruiz), sdata, ubuff1, data->m);
  QOCOFloat sinf = data->m > 0 ? inf_norm(ubuff1, data->m) : 0;

  QOCOFloat* Dinvruiz_data = get_data_vectorf(work->scaling->Dinvruiz);
  QOCOFloat* xdata = get_data_vectorf(work->x);
  ew_product(Dinvruiz_data, get_data_vectorf(data->c), xbuff, data->n);
  QOCOFloat cinf = inf_norm(xbuff, data->n);

  QOCOFloat* Finvruiz_data = get_data_vectorf(work->scaling->Finvruiz);
  QOCOFloat* hdata = get_data_vectorf(data->h);
  ew_product(Finvruiz_data, hdata, ubuff3, data->m);
  QOCOFloat hinf = data->m > 0 ? inf_norm(ubuff3, data->m) : 0;

  // Compute ||A^T * y||_\infty. If equality constraints aren't present, A->m =
  // A->n = 0 and SpMtv is a nullop.
  QOCOFloat* ydata = get_data_vectorf(work->y);
  SpMtv(data->A, ydata, xbuff);
  ew_product(xbuff, Dinvruiz_data, xbuff, data->n);
  QOCOFloat Atyinf = data->p ? inf_norm(xbuff, data->n) : 0;

  // Compute ||G^T * z||_\infty. If inequality constraints aren't present, G->m
  // = G->n = 0 and SpMtv is a nullop.
  QOCOFloat* zdata = get_data_vectorf(work->z);
  SpMtv(data->G, zdata, xbuff);
  ew_product(xbuff, Dinvruiz_data, xbuff, data->n);
  QOCOFloat Gtzinf = data->m > 0 ? inf_norm(xbuff, data->n) : 0;

  // Compute ||P * x||_\infty
  USpMv(data->P, xdata, xbuff);
  qoco_axpy(xdata, xbuff, xbuff, -solver->settings->kkt_static_reg_P, data->n);
  QOCOFloat xPx = qoco_dot(xdata, xbuff, work->data->n);
  ew_product(xbuff, Dinvruiz_data, xbuff, data->n);
  QOCOFloat Pxinf = inf_norm(xbuff, data->n);

  // Compute ||A * x||_\infty
  SpMv(data->A, xdata, ybuff);
  ew_product(ybuff, Einvruiz_data, ybuff, data->p);
  QOCOFloat Axinf = data->p ? inf_norm(ybuff, data->p) : 0;

  // Compute ||G * x||_\infty
  SpMv(data->G, xdata, ubuff1);
  ew_product(ubuff1, Finvruiz_data, ubuff1, data->m);
  QOCOFloat Gxinf = data->m ? inf_norm(ubuff1, data->m) : 0;

  // Compute primal residual.
  ew_product(&kktres[data->n], Einvruiz_data, ybuff, data->p);
  QOCOFloat eq_res = inf_norm(ybuff, data->p);

  ew_product(&kktres[data->n + data->p], Finvruiz_data, ubuff1, data->m);
  QOCOFloat conic_res = inf_norm(ubuff1, data->m);

  QOCOFloat pres = qoco_max(eq_res, conic_res);

  // Compute dual residual.
  ew_product(kktres, Dinvruiz_data, xbuff, data->n);
  scale_arrayf(xbuff, xbuff, work->scaling->kinv, data->n);
  QOCOFloat dres = inf_norm(xbuff, data->n);
  QOCOFloat origin_dual = work->stopping_origin ?
      qoco_dot(work->stopping_origin, xbuff, data->n) : 0.0;

  // Compute complementary slackness residual.
  QOCOFloat gap = qoco_abs(qoco_dot(sdata, zdata, data->m) * work->scaling->kinv);

  // Compute max{Axinf, binf, Gxinf, hinf, sinf}.
  QOCOFloat pres_rel = qoco_max(Axinf, binf);
  pres_rel = qoco_max(pres_rel, Gxinf);
  pres_rel = qoco_max(pres_rel, hinf);
  pres_rel = qoco_max(pres_rel, sinf);

  // Compute max{Pxinf, Atyinf, Gtzinf, cinf}.
  QOCOFloat dres_rel = qoco_max(Pxinf, Atyinf);
  dres_rel = qoco_max(dres_rel, Gtzinf);
  dres_rel = qoco_max(dres_rel, cinf);
  dres_rel *= work->scaling->kinv;

  // Compute max{1, abs(pobj), abs(dobj)}.
  QOCOFloat* cdata = get_data_vectorf(work->data->c);
  QOCOFloat ctx = qoco_dot(cdata, xdata, work->data->n);
  QOCOFloat bty = qoco_dot(bdata, ydata, work->data->p);
  QOCOFloat htz = qoco_dot(hdata, zdata, work->data->m);
  QOCOFloat pobj = (0.5 * xPx + ctx) * work->scaling->kinv;
  QOCOFloat dobj = (-0.5 * xPx - bty - htz) * work->scaling->kinv;
  gap = qoco_max(gap, qoco_abs(pobj - dobj + origin_dual));
  QOCOFloat gamma = qoco_gpu_reference_origin_offset(solver);
  pobj += gamma; dobj += gamma - origin_dual;

  pobj = qoco_abs(pobj);
  dobj = qoco_abs(dobj);

  QOCOFloat gap_rel = qoco_max(1, pobj);
  gap_rel = qoco_max(gap_rel, dobj);

  out[0] = pres; out[1] = dres; out[2] = gap;
  out[3] = pres_rel; out[4] = dres_rel; out[5] = gap_rel;
}

void qoco_gpu_stopping_metrics(QOCOSolver* solver, double* out);

void qoco_gpu_iteration_metrics(QOCOSolver* solver, double* out);

unsigned char qoco_host_check_stopping(QOCOSolver* solver)
{
  QOCOWorkspace* work = solver->work;
  QOCOFloat eabs = solver->settings->abstol;
  QOCOFloat erel = solver->settings->reltol;
  QOCOFloat eabsinacc = solver->settings->abstol_inacc;
  QOCOFloat erelinacc = solver->settings->reltol_inacc;
  QOCOFloat metrics[8];
  qoco_gpu_iteration_metrics(solver, metrics);
  const char* compare = getenv("SPACEPDHCG_TEST_QOCO_BATCHED_STOPPING_COMPARE");
  if (compare && compare[0] == '1') {
    QOCOFloat reference[8];
    qoco_reference_stopping_metrics(solver, reference);
    reference[6] = compute_objective(work->data, work->x, work->xbuff,
        solver->settings->kkt_static_reg_P, work->scaling->k);
    reference[7] = compute_mu(work->s, work->z, work->data->m);
    for (int i = 0; i < 8; ++i) {
      if (!isfinite(metrics[i]) || !isfinite(reference[i]) ||
          fabs(metrics[i] - reference[i]) > 2e-12 * fmax(1.0, fabs(reference[i]))) {
        fprintf(stderr, "QOCO batched stopping metric %d mismatch %.17g %.17g\n",
                i, metrics[i], reference[i]);
        exit(1);
      }
    }
  }
  QOCOFloat pres = metrics[0], dres = metrics[1], gap = metrics[2];
  QOCOFloat pres_rel = metrics[3], dres_rel = metrics[4], gap_rel = metrics[5];
  solver->sol->pres = pres; solver->sol->dres = dres; solver->sol->gap = gap;

  solver->sol->obj = metrics[6]; work->mu = metrics[7];

  // Composite progress metric in inaccurate-tolerance units. metric <= 1.0
  // means the current iterate satisfies the inaccurate stopping criterion.
  // We track the best iterate seen so far so we can restore it on numerical
  // error / max-iter exits.
  QOCOFloat pres_inacc_thresh = eabsinacc + erelinacc * pres_rel;
  QOCOFloat dres_inacc_thresh = eabsinacc + erelinacc * dres_rel;
  QOCOFloat gap_inacc_thresh = eabsinacc + erelinacc * gap_rel;
  QOCOFloat metric =
      qoco_max(pres / pres_inacc_thresh, dres / dres_inacc_thresh);
  metric = qoco_max(metric, solver->sol->gap / gap_inacc_thresh);
  if (isfinite(metric) && (!work->best_valid || metric < work->best_metric)) {
    copy_arrayf(get_data_vectorf(work->x), get_data_vectorf(work->best_x),
                work->data->n);
    copy_arrayf(get_data_vectorf(work->s), get_data_vectorf(work->best_s),
                work->data->m);
    copy_arrayf(get_data_vectorf(work->y), get_data_vectorf(work->best_y),
                work->data->p);
    copy_arrayf(get_data_vectorf(work->z), get_data_vectorf(work->best_z),
                work->data->m);
    work->best_pres = pres;
    work->best_dres = dres;
    work->best_gap = solver->sol->gap;
    work->best_obj = solver->sol->obj;
    work->best_metric = metric;
    work->best_iter = solver->sol->iters;
    work->best_valid = 1;
  }

  // If the solver stalled (stepsize = 0), increase dynamic regularization by
  // one order of magnitude and retry. If kkt_dynamic_reg would exceed
  // kkt_reg_max=1e-6, stop with an error.
  if (solver->work->a < 1e-8) {
    solver->settings->kkt_dynamic_reg *= 10.0;
#ifdef QOCO_LOGGING
    {
      FILE* log_f = fopen("qoco_log.txt", "a");
      if (log_f) {
        fprintf(log_f, "kkt_dynamic_reg changed to %e\n",
                (double)solver->settings->kkt_dynamic_reg);
        fclose(log_f);
      }
    }
#endif
    if (solver->settings->kkt_dynamic_reg > 1e-6) {
      if (pres < eabsinacc + erelinacc * pres_rel &&
          dres < eabsinacc + erelinacc * dres_rel &&
          solver->sol->gap < eabsinacc + erelinacc * gap_rel) {
        solver->sol->status = QOCO_SOLVED_INACCURATE;
        return 1;
      }
      solver->sol->status = QOCO_NUMERICAL_ERROR;
      return 1;
    }
    return 0;
  }

  if (pres < eabs + erel * pres_rel && dres < eabs + erel * dres_rel &&
      solver->sol->gap < eabs + erel * gap_rel) {
    solver->sol->status = QOCO_SOLVED;
    return 1;
  }
  return 0;
}

unsigned char qoco_host_restore_best_iterate(QOCOSolver* solver)
{
  QOCOWorkspace* work = solver->work;
  QOCOProblemData* data = work->data;
  if (!work->best_valid) {
    return 0;
  }

  // Copy best iterate (still in scaled space) back into the live workspace
  // variables so that unscale_variables / copy_solution operate on it.
  copy_arrayf(get_data_vectorf(work->best_x), get_data_vectorf(work->x),
              data->n);
  copy_arrayf(get_data_vectorf(work->best_s), get_data_vectorf(work->s),
              data->m);
  copy_arrayf(get_data_vectorf(work->best_y), get_data_vectorf(work->y),
              data->p);
  copy_arrayf(get_data_vectorf(work->best_z), get_data_vectorf(work->z),
              data->m);
  solver->sol->pres = work->best_pres;
  solver->sol->dres = work->best_dres;
  solver->sol->gap = work->best_gap;
  solver->sol->obj = work->best_obj;

  // If the best iterate meets the inaccurate tolerance, upgrade the status.
  if (work->best_metric <= 1.0 &&
      (solver->sol->status == QOCO_NUMERICAL_ERROR ||
       solver->sol->status == QOCO_MAX_ITER)) {
    solver->sol->status = QOCO_SOLVED_INACCURATE;
  }
  return 1;
}

void qoco_reference_copy_solution(QOCOSolver* solver)
{
  // Copy optimization variables from device to host (CUDA backend).
  // No-op for builtin backend.
  sync_vector_to_host(solver->work->x);
  sync_vector_to_host(solver->work->s);
  sync_vector_to_host(solver->work->y);
  sync_vector_to_host(solver->work->z);

  // Set cpu mode to 1 so get_data_vectorf returns host pointer.
  set_cpu_mode(1);
  copy_arrayf(get_data_vectorf(solver->work->x), solver->sol->x,
              solver->work->data->n);
  copy_arrayf(get_data_vectorf(solver->work->s), solver->sol->s,
              solver->work->data->m);
  copy_arrayf(get_data_vectorf(solver->work->y), solver->sol->y,
              solver->work->data->p);
  copy_arrayf(get_data_vectorf(solver->work->z), solver->sol->z,
              solver->work->data->m);
  set_cpu_mode(0);

  solver->sol->solve_time_sec =
      get_elapsed_time_sec(&(solver->work->solve_timer));
}

void log_ipm_iter(QOCOInt iter)
{
#ifdef QOCO_LOGGING
  FILE* log_f = fopen("qoco_log.txt", iter == 0 ? "w" : "a");
  if (log_f) {
    fprintf(log_f, "Iteration: %d\n", iter);
    fclose(log_f);
  }
#else
  (void)iter;
#endif
}

QOCOSettings* copy_settings(QOCOSettings* settings)
{
  QOCOSettings* new_settings = malloc(sizeof(QOCOSettings));
  new_settings->abstol = settings->abstol;
  new_settings->abstol_inacc = settings->abstol_inacc;
  new_settings->max_ir_iters = settings->max_ir_iters;
  new_settings->ir_tol = settings->ir_tol;
  new_settings->max_iters = settings->max_iters;
  new_settings->kkt_static_reg_P = settings->kkt_static_reg_P;
  new_settings->kkt_static_reg_A = settings->kkt_static_reg_A;
  new_settings->kkt_static_reg_G = settings->kkt_static_reg_G;
  new_settings->kkt_dynamic_reg = settings->kkt_dynamic_reg;
  new_settings->reltol = settings->reltol;
  new_settings->reltol_inacc = settings->reltol_inacc;
  new_settings->ruiz_iters = settings->ruiz_iters;
  new_settings->verbose = settings->verbose;

  return new_settings;
}
int qoco_gpu_finish_device_solution(QOCOSolver* solver);
void copy_solution(QOCOSolver* solver) {
  const int device = qoco_gpu_finish_device_solution(solver);
  if (device < 0) { fprintf(stderr, "QOCO device solution completion failed\n"); exit(1); }
  if (!device) qoco_reference_copy_solution(solver);
  else solver->sol->solve_time_sec = get_elapsed_time_sec(&(solver->work->solve_timer));
}

unsigned char qoco_gpu_check_stopping(QOCOSolver*);
unsigned char check_stopping(QOCOSolver* solver) {
  if (!solver->work->gpu_control) return qoco_host_check_stopping(solver);
  const char* audit = getenv("SPACEPDHCG_TEST_QOCO_DEVICE_CONTROL_COMPARE");
  const char* metrics = getenv("SPACEPDHCG_TEST_QOCO_BATCHED_STOPPING_COMPARE");
  if (!((audit && audit[0]=='1') || (metrics && metrics[0]=='1'))) return qoco_gpu_check_stopping(solver);
  int incoming = solver->sol->status;
  qoco_gpu_sync_control(solver);
  solver->sol->status = incoming;
  unsigned char expected = qoco_host_check_stopping(solver);
  QOCOWorkspace* w = solver->work;
  double reference[] = {solver->settings->kkt_dynamic_reg, solver->sol->pres,
    solver->sol->dres, solver->sol->gap, solver->sol->obj, w->mu, w->a,
    w->best_metric, w->best_pres, w->best_dres, w->best_gap, w->best_obj};
  int status=solver->sol->status, best_iter=w->best_iter, best_valid=w->best_valid;
  solver->sol->status = incoming;
  unsigned char actual = qoco_gpu_check_stopping(solver);
  double result[] = {solver->settings->kkt_dynamic_reg, solver->sol->pres,
    solver->sol->dres, solver->sol->gap, solver->sol->obj, w->mu, w->a,
    w->best_metric, w->best_pres, w->best_dres, w->best_gap, w->best_obj};
  int bad = expected!=actual || status!=solver->sol->status
    || best_iter!=w->best_iter || best_valid!=w->best_valid;
  for (int i=0;i<12;++i)
    if (!(result[i]==reference[i] || (isnan(result[i]) && isnan(reference[i]))
      || (isfinite(result[i]) && isfinite(reference[i])
          && fabs(result[i]-reference[i])<=2e-12*fmax(1.0,fabs(reference[i]))))) bad=1;
  if (bad) { fprintf(stderr, "QOCO device control audit mismatch\n"); exit(1); }
  return actual;
}

unsigned char qoco_gpu_restore_best(QOCOSolver*);
unsigned char restore_best_iterate(QOCOSolver* solver) {
  if (!solver->work->gpu_control) return qoco_host_restore_best_iterate(solver);
  const char* audit = getenv("SPACEPDHCG_TEST_QOCO_DEVICE_CONTROL_COMPARE");
  const char* metrics = getenv("SPACEPDHCG_TEST_QOCO_BATCHED_STOPPING_COMPARE");
  if (!((audit && audit[0]=='1') || (metrics && metrics[0]=='1'))) return qoco_gpu_restore_best(solver);
  int incoming = solver->sol->status;
  qoco_gpu_sync_control(solver);
  solver->sol->status = incoming;
  unsigned char expected = qoco_host_restore_best_iterate(solver);
  QOCOWorkspace* w = solver->work;
  double reference[] = {solver->settings->kkt_dynamic_reg, solver->sol->pres,
    solver->sol->dres, solver->sol->gap, solver->sol->obj, w->mu, w->a,
    w->best_metric, w->best_pres, w->best_dres, w->best_gap, w->best_obj};
  int status=solver->sol->status, best_iter=w->best_iter, best_valid=w->best_valid;
  solver->sol->status = incoming;
  unsigned char actual = qoco_gpu_restore_best(solver);
  double result[] = {solver->settings->kkt_dynamic_reg, solver->sol->pres,
    solver->sol->dres, solver->sol->gap, solver->sol->obj, w->mu, w->a,
    w->best_metric, w->best_pres, w->best_dres, w->best_gap, w->best_obj};
  int bad = expected!=actual || status!=solver->sol->status
    || best_iter!=w->best_iter || best_valid!=w->best_valid;
  for (int i=0;i<12;++i)
    if (!(result[i]==reference[i] || (isnan(result[i]) && isnan(reference[i]))
      || (isfinite(result[i]) && isfinite(reference[i])
          && fabs(result[i]-reference[i])<=2e-12*fmax(1.0,fabs(reference[i]))))) bad=1;
  if (bad) { fprintf(stderr, "QOCO device control audit mismatch\n"); exit(1); }
  return actual;
}
