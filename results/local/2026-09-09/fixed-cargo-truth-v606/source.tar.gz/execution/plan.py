"""Build exactly the four prescribed schedules from independently verified retained evidence."""

from __future__ import annotations

import dataclasses

import common
import numpy as np


def replacement_plan(original, probe):
    from spacepdhcg.gtoc12 import constants as C
    from spacepdhcg.gtoc12.retiming import visits_of
    from spacepdhcg.gtoc12.search import PlannedLeg, RoutePlan

    pieces = probe["case"].split("_")
    old, new = int(pieces[3]), int(pieces[5])
    mode = probe["mode"].split("_")
    deploy_shift, collect_shift = float(mode[1]), float(mode[3])
    visits, arr, dep = visits_of(original)
    arr, dep = np.array(arr), np.array(dep)
    original_visits = visits
    visits = [
        dataclasses.replace(visit, body=new) if visit.body == old else visit for visit in visits
    ]
    if old in (original_visits[1].body, original_visits[-2].body) or new in [
        v.body for v in original_visits
    ]:
        raise ValueError("replacement violates fixed endpoint or duplicate-body constraint")
    for j, visit in enumerate(visits):
        if visit.body != new:
            continue
        if visit.deploy:
            arr[j] += deploy_shift
            if not visit.collect:
                dep[j] += deploy_shift
        if visit.collect:
            dep[j] += collect_shift
            if not visit.deploy:
                arr[j] += collect_shift
    changed = {j: row for row in probe["ranking_estimate"]["incident_legs"] for j in [row["leg"]]}
    original_flown = [leg for leg in original.legs if leg.role != "camp"]
    if len(original_flown) != len(visits) - 1 or len(changed) != 4:
        raise ValueError("prescribed replacement must have exactly four incident legs")
    legs = []
    for j, visit in enumerate(visits[:-1]):
        if dep[j] > arr[j] + 1e-9:
            legs.append(
                PlannedLeg(visit.body, visit.body, float(arr[j]), float(dep[j]), 0.0, 1.0, "camp")
            )
        previous = original_flown[j]
        if j in changed:
            row = changed[j]
            if (row["from"], row["to"], row["departure"], row["arrival"]) != (
                visit.body,
                visits[j + 1].body,
                float(dep[j]),
                float(arr[j + 1]),
            ):
                raise ValueError("saved GPU window does not match proposed exact schedule")
            cost, inflation = row["lambert_km_s"], 1.0
        else:
            if (
                previous.from_id,
                previous.to_id,
                previous.departure_epoch,
                previous.arrival_epoch,
            ) != (visit.body, visits[j + 1].body, float(dep[j]), float(arr[j + 1])):
                raise ValueError("an unrecorded leg changed")
            cost, inflation = previous.delta_v_proxy_km_s, previous.inflation
        legs.append(
            PlannedLeg(
                visit.body,
                visits[j + 1].body,
                float(dep[j]),
                float(arr[j + 1]),
                cost,
                inflation,
                visit.role_out,
            )
        )
    deploy = {v.body: float(arr[j]) for j, v in enumerate(visits) if v.deploy}
    collect = {v.body: float(dep[j]) for j, v in enumerate(visits) if v.collect}
    cargo = {body: C.maximum_collected_mass(collect[body] - deploy[body]) for body in collect}
    propellant = probe["ranking_estimate"]["mass_projection"]["propellant_kg"]
    final = C.MAX_INITIAL_MASS_KG - C.MINER_MASS_KG * len(deploy) + sum(cargo.values()) - propellant
    return RoutePlan(tuple(legs), deploy, collect, cargo, propellant, final), cargo


def make_plan(summaries, audit, weights):
    from fixed_refine import validate_prescription

    from spacepdhcg.gtoc12.pipeline import plan_from_route_summary

    hypothesis = common.read(common.ROOT / "reference/next-hypothesis.json")
    occupied = {
        int(body)
        for summary in summaries.values()
        for phase in ("deploy_epochs", "collect_epochs")
        for body in summary["plan"][phase]
    }
    cases = []
    for ship, probe in zip((2, 7), hypothesis["candidate_probes"], strict=True):
        original = plan_from_route_summary(summaries[ship])
        own_cargo = {int(a): float(m) for a, m in summaries[ship]["collected_mass_kg"].items()}
        before_weighted = common.weighted(own_cargo, weights)
        before_raw = sum(own_cargo.values())
        control_id = f"control_ship_{ship:02d}"
        validate_prescription(original, own_cargo)
        candidate, cargo = replacement_plan(original, probe)
        validate_prescription(candidate, cargo)
        old, new = int(probe["case"].split("_")[3]), int(probe["case"].split("_")[5])
        if new in occupied:
            raise ValueError("replacement overlaps the retained full-fleet footprint")
        if set(candidate.deploy_epochs) != {
            new if body == old else body for body in original.deploy_epochs
        }:
            raise ValueError("miner inventory changed")
        for kind, identifier, plan, prescribed in (
            ("control", control_id, original, own_cargo),
            ("probe", probe["case"], candidate, cargo),
        ):
            raw = sum(prescribed.values())
            score = common.weighted(prescribed, weights)
            if kind == "probe":
                estimate = probe["ranking_estimate"]
                if (
                    abs(raw - estimate["mining_raw_kg_estimate"]) > 1e-7
                    or abs(score - before_weighted - estimate["mining_weighted_gain_kg_estimate"])
                    > 1e-7
                ):
                    raise ValueError("prescribed cargo differs from saved truth-set hypothesis")
                if (
                    score <= before_weighted + 0.5
                    or audit["independent"]["total_mass_kg"] - before_raw + raw
                    < common.FLEET_RAW_FLOOR + 1e-6
                ):
                    raise ValueError("probe does not preserve fleet cargo/weighted opportunity")
            cases.append(
                {
                    "kind": kind,
                    "id": identifier,
                    "ship": ship,
                    "requires_control": None if kind == "control" else control_id,
                    "plan": plan.summary(),
                    "prescribed_cargo_kg": prescribed,
                    "prescribed_raw_kg": raw,
                    "prescribed_weighted_kg": score,
                    "raw_gain_kg": raw - before_raw,
                    "weighted_gain_kg": score - before_weighted,
                    "maximum_leg_calls": sum(leg.role != "camp" for leg in plan.legs),
                    "proxy_prediction": None if kind == "control" else probe["ranking_estimate"],
                    "original_certified_propellant_kg": sum(
                        float(leg["mass_before"]) - float(leg["mass_after"])
                        for leg in summaries[ship]["legs"]
                    ),
                }
            )
    return {
        "kind": "prepared_only_fixed_schedule_cargo_truth_set",
        "source_commit": common.read(common.ROOT / "preparation.json")["source_commit"],
        "maximum_whole_route_refinements": 4,
        "maximum_leg_calls": sum(case["maximum_leg_calls"] for case in cases),
        "control_failure_policy": "skip_corresponding_probe_and_do_not_interpret_proxy_failure",
        "cargo_resizing_allowed": False,
        "retiming_allowed": False,
        "positive_controls_use_actual_native_solver": True,
        "cases": cases,
    }
