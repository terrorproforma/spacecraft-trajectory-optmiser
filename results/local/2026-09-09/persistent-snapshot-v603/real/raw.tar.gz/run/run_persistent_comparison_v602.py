"""Run bounded cold real-QP diagnostics with explicit independent qualification."""
from pathlib import Path
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent/'persistent-replay-20260909'
output = root/'run'
persistent_root = Path('/home/angus/spacepdhcg-persistent-replay-v603')
persistent = persistent_root/'build/cuda-tests/persistent_snapshot_replay'
core = persistent_root/'build/cuda/libspacepdhcg_cuda.so'
qoco = Path('/home/angus/build-qoco-scaled-pool-v540/final/libqoco.so')
reference = root/'qoco_snapshot_replay'
expected = [(persistent,'1b57509b5ff8aa9870232a92d1f47660d1412629062281568831b817dca21016'),
            (core,'d4b0bea9672bb0cea612b7d4e8db5d448f1b79b9831be5710723276edd128633'),
            (qoco,'0cc27a1d8bde1edd74f7ef00e04ec64c2d6c0f8fe526a1d94b04d509a74b3315'),
            (reference,'16691294e69a8b5056d3cd9caa11119708d6dca7c4ffbdac327ba8bdc5346777')]
for path, digest in expected:
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, str(path)
tiny = json.loads((persistent_root/'tiny-retry1/report.json').read_text())
assert tiny.get('complete'), 'tiny fixture run must complete first'
spec = importlib.util.spec_from_file_location('independent_audit', root/'source/audit_persistent_snapshot.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
environment = {k:v for k,v in os.environ.items() if not k.startswith(('SPACEPDHCG_','QOCO_REPLAY_'))}
environment.update(LD_LIBRARY_PATH=f'{core.parent}:{qoco.parent}:/home/angus/cudss-isolated-0.8.0.10/nvidia/cu12/lib:/usr/local/cuda-12.8/lib64',
                   OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
report = dict(complete=False, pid=os.getpid(), scope='diagnostic cold captured conic LP comparison; not a timing crossover or trajectory certificate',
              execution_files=len(expected), libraries={str(p):h for p,h in expected},
              cases=[], initial_persistent_iteration_budget=100000, persistent_deadline_seconds=30,
              audit_tolerance=1e-9, cone_tolerance=1e-8, source_pin='cf71faaaecaa01b4d3c8d9f6e1ba37a489cb75a2')
def save():
    path=output/'report.tmp'
    path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    path.replace(output/'report.json')

with Path('/home/angus/.spacepdhcg-gpu.lock').open('a') as lock:
    print(json.dumps({'pid':os.getpid(),'stage':'waiting_for_shared_gpu_lock','gpu_calls':0}),flush=True)
    fcntl.flock(lock,fcntl.LOCK_EX)
    output.mkdir(exist_ok=False)
    shutil.copyfile(__file__,output/Path(__file__).name)
    report['gpu']=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version,memory.total',
                                  '--format=csv,noheader'],capture_output=True,text=True,check=True).stdout.strip()
    save()
    for label in ('conditioning','difficult'):
        snapshot=root/'inputs'/(label+'.txt')
        problem=audit.load_snapshot(snapshot)
        digest=hashlib.sha256(snapshot.read_bytes()).hexdigest()
        for backend in ('qoco','persistent'):
            command=([str(reference),str(snapshot),'3'] if backend=='qoco' else
                     [str(persistent),str(snapshot),'--tolerance','1e-9','--iterations','100000',
                      '--deadline-seconds','30','--repeats','1','--mode','cold'])
            log=output/(label+'-'+backend+'.log')
            row=dict(label=label,backend=backend,command=command,input_sha256=digest,
                     quadratic_numerical_nonzeros=problem['quadratic_numerical_nonzeros'])
            report.update(stage=label+'-'+backend)
            save()
            began=time.perf_counter()
            with log.open('x') as stream:
                try:
                    result=subprocess.run(command,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
                    row.update(returncode=result.returncode,timed_out=False)
                except subprocess.TimeoutExpired:
                    row.update(returncode=None,timed_out=True)
            row['process_seconds']=time.perf_counter()-began
            row['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
            prefix='PERSISTENT_REPLAY' if backend=='persistent' else 'QP_REPLAY'
            row['records']=[json.loads(line[len(prefix)+1:]) for line in log.read_text().splitlines()
                            if line.startswith(prefix+' ')]
            # The full vectors stay in the raw log; compact report stores independent evidence.
            raw_records=row.pop('records')
            try:
                row['audits']=audit.audit_log(problem,log,digest,backend=backend,
                    coordinates='original' if backend=='persistent' else 'translated',record_prefix=prefix)
            except (ValueError,KeyError) as error:
                row['audit_error']=str(error)
                row['audits']=[]
            row['qualified']=sum(r['qualified'] for r in row['audits'])
            row['raw_record_count']=len(raw_records)
            row['solver_reports']=[{k:v for k,v in r.items() if k not in ('x','x_solver','y','z','s')}
                                   for r in raw_records]
            if backend=='persistent' and row['audits']:
                fields={'primal':'primal','dual':'dual','gap':'gap','objective':'objective',
                        'dual_objective':'dual_objective',
                        'block_complementarity_normalized':'complementarity_max_relative'}
                row['independent_native_audit_agrees']=all(
                    native['kkt_qualified_original']==independent['passes_common_kkt_gate']
                    and all(math.isclose(native['audit'][nk],independent[ik],rel_tol=1e-9,abs_tol=1e-12)
                            for nk,ik in fields.items())
                    for native,independent in zip(raw_records,row['audits'],strict=True))
            report['cases'].append(row)
            save()
            print(json.dumps({k:row[k] for k in ('label','backend','returncode','process_seconds','qualified','raw_record_count')}) ,flush=True)
    report.update(complete=True,stage='complete')
    save()
print(json.dumps({'complete':True,'report':str(output/'report.json')}),flush=True)
