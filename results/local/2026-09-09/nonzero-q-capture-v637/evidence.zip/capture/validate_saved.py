"""Validate an exported HCW view from saved bytes only; no model or solver imports."""
import hashlib
import json
import math
from pathlib import Path
import struct


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bits(values):
    return b"".join(struct.pack("<d", float(v)) for v in values)


def snapshot(path):
    tokens = Path(path).read_text().split()
    it = iter(tokens)
    require(next(it) == "SPACEPDHCG_QOCO_QP_V1", "snapshot magic")
    dims = [int(next(it)) for _ in range(9)]
    require(dims == [186, 132, 80, 186, 1212, 60, 0, 20, 0], "snapshot dimensions")
    si = [int(next(it)) for _ in range(4)]
    sf = [float(next(it)) for _ in range(9)]
    require(si == [200, 0, 5, 0], "settings integers")
    require(sf == [1e-6, 1e-13, 1e-8, 1e-13, 1e-11, 1e-8, 1e-8, 1e-5, 1e-5], "settings values")
    def vector(cast, expected):
        require(int(next(it)) == expected, "snapshot vector size")
        return [cast(next(it)) for _ in range(expected)]
    mats = []
    for rows, nnz in ((186, 186), (132, 1212), (80, 60)):
        ptr, idx = vector(int, 187), vector(int, nnz)
        require(ptr[0] == 0 and ptr[-1] == nnz, "CSC endpoints")
        for j in range(186):
            require(0 <= ptr[j] <= ptr[j+1] <= nnz, "CSC pointer bounds")
            part = idx[ptr[j]:ptr[j+1]]
            require(part == sorted(set(part)) and all(0 <= x < rows for x in part), "CSC rows")
        mats.append({"rows": rows, "columns": 186, "offsets": ptr, "indices": idx})
    require(vector(int, 20) == [4] * 20, "SOC inventory")
    original = vector(float, 1856)
    require(all(math.isfinite(x) for x in original), "nonfinite coefficient")
    require(vector(float, 0) == vector(float, 0) == [], "unexpected shift/origin")
    require(float(next(it)) == 0, "objective offset")
    require(next(it, None) is None, "trailing snapshot data")
    at = 0
    for m, n in zip(mats, (186, 1212, 60)):
        m["values"] = original[at:at+n]
        at += n
    return {"P": mats[0], "A": mats[1], "G": mats[2], "c": original[at:at+186],
            "b": original[at+186:at+318], "h": original[at+318:]}


def validate(directory):
    directory = Path(directory)
    q = snapshot(directory / "snapshot.txt")
    native = json.loads((directory / "native.json").read_text())
    ctx = json.loads((directory / "context.json").read_text())
    report = json.loads((directory / "capture-report.json").read_text())
    for lhs, rhs in ((q["P"], native["Q"]), (q["A"], native["A"])):
        require(all(lhs[k] == rhs[k] for k in ("rows", "columns", "offsets", "indices")), "native topology")
        require(bits(lhs["values"]) == bits(rhs["values"]), "native Q/A values changed")
    require(all(x > 0 for x in q["P"]["values"]), "actual Q not positive")
    expected = [2e-4 if j % 6 < 3 else 2e-2 for j in range(126)] + [2.] * 60
    require(bits(expected) == bits(q["P"]["values"]), "Q recipe")
    require(bits(q["c"]) == bits(native["c"]), "linear objective changed")
    require(bits(q["b"]) == bits(native["scalar_lower"]) == bits(native["scalar_upper"]), "equality bounds")
    require(native["variable_lower"] == ["-Infinity"] * 186 and native["variable_upper"] == ["Infinity"] * 186,
            "variable bounds changed")
    perm = [4*k + j for k in range(20) for j in (3, 0, 1, 2)]
    require(ctx["qoco_row_to_native_affine"] == perm, "row map")
    require(bits(q["h"]) == bits([native["affine_offset"][r] for r in perm]), "cone offset")
    require(q["G"]["offsets"] == native["F"]["offsets"], "F/G column map")
    require(q["G"]["indices"] == [4*(r//4) + (0 if r % 4 == 3 else r % 4 + 1)
                                     for r in native["F"]["indices"]], "F/G row map")
    require(bits(q["G"]["values"]) == bits([-x for x in native["F"]["values"]]), "F/G sign")
    require(native["canonical_objective_constant"] == ctx["canonical_objective_constant"] == 0,
            "canonical objective constant changed")
    require(ctx["physical_constant_used_by_solver_or_original_audit"] is False, "physical constant included")
    require(ctx["initial_state"] == [.1, -.05, .02, 1e-4, -2e-4, 5e-5]
            and ctx["target_state"] == [0]*6 and ctx["times_seconds"] == list(range(0, 201, 10)), "recipe boundary/time")
    require(len(ctx["reference_states"]) == 21 and all(len(v) == 6 for v in ctx["reference_states"]), "reference states")
    require(ctx["reference_states"][0] == ctx["initial_state"]
            and ctx["reference_controls"] == [[0]*3 for _ in range(20)], "reference initial/control")
    require(ctx["cold_x"] == [0]*186 and ctx["cold_y"] == [0]*132 and ctx["cold_z"] == [0]*80
            and bits(ctx["cold_s"]) == bits(q["h"]), "declared cold point")
    require(ctx["final_vectors"] is None and ctx["reference_used_as_solver_seed"] is False, "false solved/seeded claim")
    require(report["complete"] and report["passed"] and report["assembly_calls"] == 1
            and report["reference_rollout_intervals"] == 20 and report["optimizer_calls"] == report["gpu_calls"] == 0,
            "capture execution scope")
    return {"passed": True, "scope": "saved coefficient/map/serialization only; no dynamics recalculation",
            "files": {p.name: {"bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(directory.iterdir()) if p.is_file()},
            "actual_positive_P_values": 186, "scalar_equalities": 132, "soc4_blocks": 20,
            "native_Q_A_c_bit_preserved": True, "cone_permutation_and_sign_verified": True,
            "canonical_objective_constant": 0, "final_vectors_available": False,
            "model_evaluations": 0, "optimizer_calls": 0, "gpu_calls": 0}


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("optimized Python is forbidden")
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(validate(args.directory), indent=2, sort_keys=True))
