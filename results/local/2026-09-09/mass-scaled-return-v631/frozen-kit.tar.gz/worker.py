"""Two fixed-date returns: archive control, then candidate, then fleet verification."""

from __future__ import annotations

import os
import time
import traceback
from types import SimpleNamespace

import common as C
import numpy as np

COUNTERS = (
    "native_solves_started",
    "native_solves_returned",
    "native_iterations",
    "flight_certificate_calls",
    "wait_certificate_calls",
    "seeded_calls_started",
    "cold_calls_started",
    "full_fleet_CPU_checks",
    "full_fleet_official_checks",
)


def main():
    if not __debug__ or os.environ.get("SPACEPDHCG_ROUTE_SUPERVISED") != str(os.getppid()):
        raise RuntimeError("Use the single-use foreground supervisor")
    C.activate()
    from check_fleet import check
    from observe import Observer, save_solution
    from runtime import boundary_for, emit_candidate, load_prefix

    from spacepdhcg.gtoc12.fixed_refinement import FrozenLegRunner
    from spacepdhcg.gtoc12.gpu_execution import using_gpu_execution
    from spacepdhcg.gtoc12.low_thrust import ScvxSettings
    from spacepdhcg.gtoc12.refinement_admission import FixedCargoRequest, FleetBudgetContext
    from spacepdhcg.gtoc12.search import RoutePlan
    from spacepdhcg.gtoc12.trajectory_seed import ZohTrajectorySeed

    output = C.KIT / "output"
    report = dict.fromkeys(COUNTERS, 0) | {
        "complete": False,
        "status": "running",
        "cases": [],
        "standalone_inspection_calls": 0,
        "whole_route_reruns": 0,
        "Lambert_calls": 0,
        "fresh_prefix_propagations": 0,
        "incumbent_promoted": False,
    }
    started = time.perf_counter()
    deadline = started + 220.0

    def save():
        for key in COUNTERS[:7]:
            report[key] = sum(case[key] for case in report["cases"])
        C.current(output / "report.json", report)

    save()
    try:
        protocol = C.read(C.KIT / "protocol.json")
        settings = ScvxSettings(**C.read(C.BASE / "settings.json"))
        assert settings.max_iterations == 40 and settings.polish_iterations == 4
        plan = RoutePlan.from_summary(C.read(C.BASE / "candidate-plan.json"))
        identity = plan.summary()
        cargo = dict(plan.collected_mass)
        request = FixedCargoRequest.from_summary(identity, cargo)
        assert request.sha256 == protocol["candidate_request_sha256"]
        catalogue, bonus = C.catalogue_and_bonus()
        weights = {i + 1: float(x) for i, x in enumerate(bonus.coefficient)}
        binding = C.read(C.BASE / "checker-binding.json")
        context = FleetBudgetContext.from_verified_result(
            (C.CURRENT / "Result.txt").read_bytes(),
            independent=binding["independent"],
            official=binding["official"],
            weights=weights,
        )
        budget = context.replacement(10, request)
        assert not budget.blocker
        assert abs(budget.objective_gain_kg - protocol["prescribed_weighted_gain_kg"]) <= 1e-8
        assert abs(budget.raw_gain_kg - protocol["prescribed_raw_gain_kg"]) <= 1e-8
        expected = {
            "raw_kg": binding["independent"]["total_mass_kg"] + budget.raw_gain_kg,
            "weighted_kg": binding["independent"]["weighted_score_fixed_bonus_kg"]
            + budget.objective_gain_kg,
            "asteroids": 199,
        }
        C.write(
            output / "prescribed-fleet-budget.json",
            {
                "budget": budget,
                "expected_if_both_checkers_pass": expected,
                "candidate_request_sha256": request.sha256,
            },
        )
        prefix = load_prefix(plan)
        report.update(saved_prefix_flight_certificates=17, saved_prefix_wait_certificates=1)
        with np.load(C.BASE / "archived-return.npz", allow_pickle=False) as archive:
            seed_arrays = {key: archive[key].copy() for key in archive.files}
        assert seed_arrays["source_sha256"].item() == C.RESULT_SHA
        source_bits = {key: value.tobytes() for key, value in seed_arrays.items()}
        return_leg = [leg for leg in plan.legs if leg.role != "camp"][-1]
        assert (
            return_leg.from_id,
            return_leg.to_id,
            return_leg.departure_epoch,
            return_leg.arrival_epoch,
        ) == (17126, 0, 69263.0, 69713.0)
        candidate_item = None
        with using_gpu_execution(
            SimpleNamespace(gpu_execution="graph", outer_loop_backend="cuda", workers=1)
        ):
            for control in (True, False):
                if time.perf_counter() >= deadline:
                    raise TimeoutError("Deadline before return initialization")
                name = "original_mass_control" if control else "candidate_mass_return"
                directory = output / name
                (directory / "legs/00").mkdir(parents=True)
                row = dict.fromkeys(COUNTERS, 0) | {"case": name, "certified": False}
                report["cases"].append(row)
                generated, boundary = boundary_for(seed_arrays, settings, control=control)
                C.write(
                    directory / "boundary.json", {"generated": generated, "effective": boundary}
                )
                seed = ZohTrajectorySeed(
                    seed_arrays["node_epochs_mjd"],
                    seed_arrays["initial_state"],
                    seed_arrays["thrust_n"],
                    C.RESULT_SHA,
                    target_initial_mass_kg=boundary.initial_mass,
                )
                assert all(
                    seed_arrays[key].tobytes() == value for key, value in source_bits.items()
                )
                assert seed.initial_state.tobytes() == source_bits["initial_state"]
                assert seed.thrust_n.tobytes() == source_bits["thrust_n"]
                np.savez_compressed(
                    directory / "seed-upload.npz",
                    initial_state=seed.initial_state,
                    thrust_n=seed.thrust_n,
                    node_epochs_mjd=seed.node_epochs_mjd,
                    target_initial_mass_kg=np.array(boundary.initial_mass),
                )
                C.write(
                    directory / "initialization.json",
                    {
                        "kind": "GPU_mass_scaled_archived_ZOH",
                        "source_Result_sha256": C.RESULT_SHA,
                        "source_seed_sha256": C.sha(C.BASE / "archived-return.npz"),
                        "archive_initial_mass_kg": float(seed.initial_state[6]),
                        "target_initial_mass_kg": boundary.initial_mass,
                        "production_Python_thrust_scaling": False,
                        "control_can_promote": False,
                    },
                )
                observer = Observer(directory, row, save, max_flights=1, max_waits=0)
                observer.index = 0
                runner = FrozenLegRunner(settings)
                try:
                    with observer:
                        item, details = runner.solve(return_leg, boundary, 0, seed=seed)
                    if item.solution is not None:
                        save_solution(item.solution, directory / "legs/00", "post-clamp")
                    C.write(directory / "leg-result.json", details)
                    row["certified"] = bool(item.certified and item.certificate is not None)
                    row["status"] = details["status"]
                    if row["certified"]:
                        mass_ok = (
                            item.certificate.final_mass_kg >= boundary.minimum_final_mass - 1e-9
                        )
                        row["fixed_mass_passed"] = mass_ok
                        row["certified_final_mass_kg"] = item.certificate.final_mass_kg
                        row["certified"] = bool(mass_ok)
                    C.write(directory / "case-report.json", row)
                    if not row["certified"]:
                        report["status"] = (
                            "control_failed_candidate_blocked"
                            if control
                            else "candidate_return_failed"
                        )
                        return
                    if not control:
                        candidate_item = item
                finally:
                    runner.close()
                    save()
        assert candidate_item is not None
        assert plan.summary() == identity and plan.collected_mass == cargo
        section, provenance = emit_candidate(plan, prefix, candidate_item)
        destination = output / "candidate-fleet"
        destination.mkdir()
        payload = C.splice((C.CURRENT / "Result.txt").read_bytes(), {10: section})
        (destination / "ship10.txt").write_bytes(section)
        (destination / "Result.txt").write_bytes(payload)
        C.write(destination / "emission.json", provenance)
        original_sections = C.sections((C.CURRENT / "Result.txt").read_bytes())
        final_sections = C.sections(payload)
        assert all(final_sections[i] == original_sections[i] for i in original_sections if i != 10)
        C.write(
            destination / "section-proof.json",
            {
                "retained_ships": [i for i in original_sections if i != 10],
                "retained_sections_byte_identical": True,
                "source_Result_sha256": C.RESULT_SHA,
                "candidate_Result_sha256": C.sha(destination / "Result.txt"),
            },
        )
        report["fleet_acceptance"] = check(
            destination / "Result.txt", catalogue, bonus, report, save, deadline, expected
        )
        report["status"] = (
            "verified_fixed_cargo_improvement"
            if report["fleet_acceptance"]["accepted_improvement"]
            else "full_fleet_check_failed"
        )
    except BaseException as error:
        report.update(
            status="execution_failed", error=repr(error), traceback=traceback.format_exc()
        )
        raise
    finally:
        report.update(complete=True, worker_seconds=time.perf_counter() - started)
        save()


if __name__ == "__main__":
    main()
