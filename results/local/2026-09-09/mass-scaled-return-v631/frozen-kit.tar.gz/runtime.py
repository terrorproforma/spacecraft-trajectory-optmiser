"""Bind known prefix certificates and emit one draft for the original fleet checkers."""

from __future__ import annotations

import dataclasses
import math
from types import SimpleNamespace

import common as C
import numpy as np

CASE = C.PRIOR / "output/local-v794-ship10-rank0000"


def boundary_for(seed_arrays, settings, *, control):
    from spacepdhcg.gtoc12.fixed_refinement import _validate_boundary_representation
    from spacepdhcg.gtoc12.low_thrust import LegBoundary

    del settings
    raw = C.read(C.BASE / "failed-boundary.json")
    for key in ("departure_position", "departure_velocity", "arrival_position", "arrival_velocity"):
        raw[key] = np.asarray(raw[key], dtype=np.float64)
    if control:
        source = C.read(C.KIT / "protocol.json")["control"]
        raw["initial_mass"] = float(seed_arrays["initial_state"][6])
        raw["minimum_final_mass"] = source["minimum_final_mass_kg"]
    generated = LegBoundary(**raw)
    effective = dataclasses.replace(
        generated,
        departure_position=seed_arrays["initial_state"][:3],
        departure_velocity=seed_arrays["initial_state"][3:6],
        arrival_position=seed_arrays["arrival_position"],
    )
    # The archived spacecraft arrival velocity is intentionally not a body target.
    effective = _validate_boundary_representation(generated, effective)
    return generated, effective


def load_prefix(plan):
    """Read only previously accepted legs; never invent an ArcResult or certificate."""
    from spacepdhcg.gtoc12.fixed_refinement import validate_prescription
    from spacepdhcg.gtoc12.low_thrust import LegBoundary, LegSolution

    validate_prescription(plan, plan.collected_mass)
    flown = [leg for leg in plan.legs if leg.role != "camp"]
    assert len(flown) == 18
    old_case = C.read(CASE / "case-report.json")
    assert old_case["flight_certificate_calls"] == 17
    assert old_case["wait_certificate_calls"] == 1
    waits = C.read(CASE / "wait-summary.json")
    assert set(waits) == {"wait-08"} and waits["wait-08"]["passed"]
    items = []
    for index, planned in enumerate(flown[:-1]):
        directory = CASE / "legs" / f"{index:02d}"
        record = C.read(directory / "leg-result.json")
        if not record["certified"] or record["certificate"] is None:
            raise ValueError("uncertified prior leg cannot enter a saved prefix")
        assert [record[k] for k in ("from", "to", "departure", "arrival")] == [
            planned.from_id,
            planned.to_id,
            planned.departure_epoch,
            planned.arrival_epoch,
        ]
        raw = C.read(directory / "boundary.json")["effective"]
        for key in (
            "departure_position",
            "departure_velocity",
            "arrival_position",
            "arrival_velocity",
        ):
            raw[key] = np.asarray(raw[key], dtype=np.float64)
        boundary = LegBoundary(**raw)
        with np.load(directory / "post-clamp.npz", allow_pickle=False) as archive:
            arrays = {
                name: np.frombuffer(archive[name].tobytes(), dtype=archive[name].dtype).reshape(
                    archive[name].shape
                )
                for name in archive.files
            }
        assert all(np.isfinite(a).all() for a in arrays.values())
        assert arrays["epochs"][0] == planned.departure_epoch
        assert arrays["epochs"][-1] == planned.arrival_epoch
        assert boundary.initial_mass == record["initial_mass_kg"]
        # This is an emission view, not a reconstructed optimization result.
        emission = SimpleNamespace(
            boundary=boundary,
            node_epochs_mjd=arrays["epochs"],
            thrust_n=arrays["thrust_n"],
            hold="zoh",
            departure_vinf_km_s=arrays["departure_vinf"],
            arrival_vinf_km_s=arrays["arrival_vinf"],
        )
        emission.burn_arcs = lambda value=emission: LegSolution.burn_arcs(value)
        items.append(
            SimpleNamespace(
                planned=planned,
                boundary=boundary,
                solution=emission,
                certificate=SimpleNamespace(**record["certificate"]),
                known_saved_certificate=True,
                record_sha256=C.sha(directory / "leg-result.json"),
                post_clamp_sha256=C.sha(directory / "post-clamp.npz"),
            )
        )
    assert len(items) == 17
    expected = items[-1].certificate.final_mass_kg + plan.collected_mass[17126]
    assert expected == C.read(C.BASE / "failed-boundary.json")["initial_mass"]
    return items


def emit_candidate(plan, prefix, fresh):
    """Use saved event coordinates and exact controls; final fleet checks decide acceptance."""
    from spacepdhcg.gtoc12.solution import (
        Event,
        ShipTrajectory,
        Solution,
        StateLine,
        format_solution,
    )

    if len(prefix) != 17 or not all(item.known_saved_certificate for item in prefix):
        raise ValueError("exact certified prefix required")
    if not fresh.certified or fresh.certificate is None or fresh.solution is None:
        raise ValueError("new return requires its own independent certificate")
    cargo = dict(plan.collected_mass)
    final_dry = fresh.certificate.final_mass_kg - sum(cargo.values())
    if not math.isfinite(final_dry) or final_dry < 500.0 - 1e-9:
        raise ValueError("fixed cargo cannot be reduced to cover return fuel")
    items = [
        *prefix,
        SimpleNamespace(
            planned=fresh.planned,
            boundary=fresh.solution.boundary,
            solution=fresh.solution,
            certificate=fresh.certificate,
        ),
    ]
    ship = ShipTrajectory(10)
    first = items[0]
    launch = first.boundary
    ship.items.append(
        Event(
            0,
            StateLine(
                launch.departure_epoch,
                launch.departure_position.copy(),
                launch.departure_velocity.copy(),
                launch.initial_mass,
            ),
            StateLine(
                launch.departure_epoch,
                launch.departure_position.copy(),
                launch.departure_velocity + first.solution.departure_vinf_km_s,
                launch.initial_mass,
            ),
        )
    )
    carried = 0.0
    expected_departure_mass = launch.initial_mass
    events = []
    for index, item in enumerate(items):
        leg, boundary = item.planned, item.boundary
        assert boundary.initial_mass == expected_departure_mass
        ship.items.extend(item.solution.burn_arcs())
        before = item.certificate.final_mass_kg
        epoch = leg.arrival_epoch
        if leg.to_id == 0:
            assert index == 17 and abs(carried - sum(cargo.values())) <= 1e-10
            velocity = boundary.arrival_velocity + item.solution.arrival_vinf_km_s
            ship.items.append(
                Event(
                    -3,
                    StateLine(epoch, boundary.arrival_position.copy(), velocity.copy(), before),
                    StateLine(
                        epoch, boundary.arrival_position.copy(), velocity.copy(), before - carried
                    ),
                )
            )
            continue
        body = leg.to_id
        next_item = items[index + 1]
        later_collection = (
            body in plan.collect_epochs
            and plan.collect_epochs[body] == next_item.planned.departure_epoch
            and plan.collect_epochs[body] != epoch
        )
        if plan.deploy_epochs.get(body) == epoch:
            after = before - 40.0
            kind = "deploy"
        elif plan.collect_epochs.get(body) == epoch:
            after = before + cargo[body]
            carried += cargo[body]
            kind = "collect"
        else:
            raise ValueError("saved flight lacks the prescribed real arrival event")
        ship.items.append(
            Event(
                body,
                StateLine(
                    epoch,
                    boundary.arrival_position.copy(),
                    boundary.arrival_velocity.copy(),
                    before,
                ),
                StateLine(
                    epoch, boundary.arrival_position.copy(), boundary.arrival_velocity.copy(), after
                ),
            )
        )
        events.append(
            {
                "body": body,
                "epoch": epoch,
                "kind": kind,
                "mass_before": before,
                "mass_after": after,
                "coordinate_source": f"saved boundary {index:02d}",
            }
        )
        expected_departure_mass = after
        if later_collection:
            assert index == 8 and body == 59079 and next_item.planned.departure_epoch == 67733.0
            after_wait = next_item.boundary
            ship.items.append(
                Event(
                    body,
                    StateLine(
                        after_wait.departure_epoch,
                        after_wait.departure_position.copy(),
                        after_wait.departure_velocity.copy(),
                        after,
                    ),
                    StateLine(
                        after_wait.departure_epoch,
                        after_wait.departure_position.copy(),
                        after_wait.departure_velocity.copy(),
                        after + cargo[body],
                    ),
                )
            )
            events.append(
                {
                    "body": body,
                    "epoch": after_wait.departure_epoch,
                    "kind": "collect",
                    "mass_before": after,
                    "mass_after": after + cargo[body],
                    "coordinate_source": "saved boundary 09 after certified wait-08",
                }
            )
            carried += cargo[body]
            expected_departure_mass += cargo[body]
    assert len(ship.events) == 20 and len(events) == 18
    assert {e["body"]: e["epoch"] for e in events if e["kind"] == "deploy"} == plan.deploy_epochs
    assert {e["body"]: e["epoch"] for e in events if e["kind"] == "collect"} == plan.collect_epochs
    assert abs(ship.events[-1].after.mass - final_dry) <= 1e-9
    text = format_solution(Solution([ship])).encode().rstrip(b"\n")
    return text, {
        "draft_only_until_both_fleet_checks": True,
        "events": events,
        "saved_flight_certificates_reused": 17,
        "saved_wait_certificates_reused": 1,
        "fresh_return_certificates": 1,
        "final_dry_mass_kg": final_dry,
        "new_prefix_body_state_calls": 0,
        "new_prefix_propagations": 0,
        "prefix_sources": [
            {"leg": i, "record_sha256": x.record_sha256, "post_clamp_sha256": x.post_clamp_sha256}
            for i, x in enumerate(prefix)
        ],
    }
