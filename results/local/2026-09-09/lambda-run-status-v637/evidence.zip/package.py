"""Create two finite saved-only v637 packages once; never run archived code or numerical work."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

from verify import CAPTURE_INDEX, canonical, capture_summary, digest, identity, lambda_summary, require, safe, verify

ROOT = Path(__file__).resolve().parents[3]
DEST = ROOT / "results/local/2026-09-09"
HERE = Path(__file__).resolve().parent

CAPTURE_README = """# Nonzero-Q HCW coefficient capture - v637

The existing displaced HCW SOC N20 recipe was assembled once on the CPU and exported with its original coefficients, bounds, cones, reference arrays and settings. The snapshot has 186 variables, 132 equalities and 20 SOC4 blocks. All 186 diagonal P values are positive: 63 at 0.0002, 63 at 0.02 and 60 at 2.

This is coefficient capture, not a native trajectory solve or certification. There were zero optimizer and GPU calls. Final solver vectors are explicitly null. The declared cold zero candidate is separate from the physical reference rollout and is not claimed to be backend-generated initialization.

The native and QOCO views preserve Q/A/c bits. Native affine [vector, scalar] rows are permuted to [scalar, vector], with G = -Pi F and h = Pi offset. The canonical objective constant remains zero. The separate physical tracking reference constant, 9.259516874999995e-6, is metadata and must not enter the original solver gap or its normalization. All original numerical settings and subsequent qualification scopes are recorded in PROTOCOL.md.

The approved action used one compiler process (1.625722 s wall) and one exporter process (0.023756 s wall), with one host assembly and 20 HCW reference-step evaluations. These are capture timings, not solver or GPU throughput. The source, four headers, compiler/executable identities, raw logs and empty cleanup results are retained. A prior prose-writing encoding failure is preserved; no numerical attempt was repeated.

`evidence.zip` contains the entire 25-file sealed kit plus its original index, summary and this packaging source. The exporter executable and persistent/QOCO/cuDSS libraries are excluded; their hashes remain in the original manifest/report. Historical paths are provenance only and are not required for verification. External reference source/runtime dependencies remain hash-linked, not copied or executed here.

Run `python -B verify.py` from this directory, or `python -B verify.py /path/to/package --index-sha256 EXPECTED_HASH`. The standalone stdlib verifier checks every ZIP byte, the four headers, preparation/execution/log bindings, native/QOCO serialization bits, unchanged settings and the unsolved status. It performs no compilation, assembly, dynamics, factorization, solver or GPU work. `verification.json` is the saved portable audit result; trust the independently supplied index hash.

The diagonal Q fixture supports a matched future comparison; it does not by itself establish a quadratic-CG advantage or any integrated speedup. Backend execution requires a separate reviewed protocol.
"""

STATUS_README = """# Retrieved Lambda run status - v637

The already retrieved reports show partial trajectory progress and no certified complete route or fleet gain. Their `success` field describes process completion. Every attempted route has `certified=false`, and all four reports have zero fleet checks.

| Saved run | Process result | Reported trajectory outcome | Native solves | Cache hits | Campaign wall seconds |
|---|---|---|---:|---:|---:|
| v851 | Complete, success | Two initial legs certified; common third flight fails for all three requests | 3 | 6 | 3.233225 |
| v853 | Complete, failure | Cargo/mining validation rejects preparation before any solve | 0 | 0 | 0.847913 |
| v854 | Complete, success | Each retimed attempt certifies 16 of 17 legs; both Earth returns fail | 30 | 4 | 29.574029 |
| v855 | Complete, success | Three extended Earth returns fail; the same 16-flight prefix is reused | 3 | 48 | 41.266340 |

The retained failures include the v851 third-flight defect 4.341414e-4; v854 return defects 1.186157e-3 and 2.444980e-4; and v855 return defects 1.317715e-2, 2.015708e-3 and 7.722101e-1 at arrivals 69578, 69638 and 69698. Native failure labels are not mathematical infeasibility certificates. Qualified inner conic subproblems do not certify a whole trajectory.

There are 36 reported native solves, 58 cache hits and eight actual route attempts across these reports. The two planned v853 requests never became attempts. Cached legs must not be counted as fresh solves or fresh certifications. Per-run wall times include their own cache/preparation scopes and establish no matched performance comparison.

All reports retain incumbent Result SHA256 `1f420928bbef8da91e3a6f8b74d3bf00039c78d4257215c103a484bc55bb22da`. There is no certified replacement or fleet gain evidenced here.

The read-only observation at **2026-09-09 04:19:49.651137 UTC** found the H100 80GB at 0% utilization, 0 MiB reported memory use and an empty compute-process query. This is one observation, not an ongoing idle guarantee. Retrieval completed successfully in 11.364768 s with zero source uploads and zero launches; these are retrieval facts, not trajectory certification.

`evidence.zip` preserves the exact 245,516-byte `lambda-status-v637.json` (SHA256 `f00dd0dc96c70aaff10e633743fe30a02dcad7e241ed4498101410c714fdb493`), including all raw remote reports in `queries[2].stdout`, plus a compact derived summary and this packaging source. The summary records exact request IDs, failure states, timing/call scopes, core/settings identities and the prior preparation failure. Derived parsed-report hashes are labeled separately from original remote file-byte hashes; only the retrieved raw response is byte-pinned here. Source/library hashes are retained dependencies, not newly verified remote artifacts.

Run `python -B verify.py` from this directory, or pass the package path and `--index-sha256 EXPECTED_HASH`. The portable stdlib verifier checks all hashes and recomputes the summary from the saved raw response, including zero fleet checks and failed certification on every attempt. It performs no network, propagation, checker, solver or GPU work. Reported partial-leg certification has not been independently re-propagated in this package. `verification.json` records the saved-only check.
"""


def build(name, payload, summary, readme):
    payload = dict(payload)
    payload["summary.json"] = canonical(summary)
    payload["package.py"] = Path(__file__).read_bytes()
    final = DEST / name
    stage = DEST / (name + ".staging")
    require(not final.exists() and not stage.exists(), "single-use publication target already exists")
    stage.mkdir(parents=True)
    top = {"README.md": readme.encode(), "verify.py": (HERE / "verify.py").read_bytes(),
           ".gitattributes": b"* -text -whitespace\n"}
    for filename, data in top.items():
        (stage / filename).write_bytes(data)
    with zipfile.ZipFile(stage / "evidence.zip", "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for filename, data in sorted(payload.items()):
            safe(filename, data)
            info = zipfile.ZipInfo(filename, (2026, 9, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    index = {"schema": "v637-saved-evidence-v1", "package": name,
             "archive_sha256": digest((stage / "evidence.zip").read_bytes()),
             "file_count": len(payload), "bytes": sum(map(len, payload.values())),
             "files": {n: identity(b) for n, b in sorted(payload.items())},
             "top_files": {n: identity(b) for n, b in sorted(top.items())},
             "verification_scope": "Saved bytes only; historical binaries/dependencies are hashes, not included artifacts."}
    (stage / "index.json").write_bytes(canonical(index))
    result = verify(stage)
    # Copy only public files to an unrelated temporary directory to prove path independence.
    with tempfile.TemporaryDirectory(prefix="v637-saved-audit-") as temporary:
        portable = Path(temporary)
        for filename in ("README.md", "verify.py", ".gitattributes", "evidence.zip", "index.json"):
            (portable / filename).write_bytes((stage / filename).read_bytes())
        command = [sys.executable, "-B", str(portable / "verify.py"), "--index-sha256", result["index_sha256"]]
        checked = subprocess.run(command, cwd=temporary, text=True, capture_output=True, timeout=20)
        require(checked.returncode == 0, "portable audit failure: " + checked.stderr)
        require(json.loads(checked.stdout) == result, "portable audit differs")
    result["fresh_directory_roundtrip_passed"] = True
    (stage / "verification.json").write_bytes(canonical(result))
    # Windows move safety: both fully resolved targets must remain under the named workspace destination.
    checked_root = ROOT.resolve(strict=True)
    checked_destination = DEST.resolve(strict=True)
    checked_stage = stage.resolve(strict=True)
    checked_final = final.resolve(strict=False)
    require(checked_destination.is_relative_to(checked_root) and checked_stage.parent == checked_destination
            and checked_final.parent == checked_destination and not final.exists() and not stage.is_symlink(),
            "publication move escaped intended workspace destination")
    os.rename(checked_stage, checked_final)
    return {**result, "path": final.relative_to(ROOT).as_posix(),
            "archive_bytes": (final / "evidence.zip").stat().st_size}


def main():
    if not __debug__:
        raise RuntimeError("Python -O is forbidden")
    kit = ROOT / "build/performance/nonzero-q-capture-v637"
    source_index = (kit / "sha256.json").read_bytes()
    require(digest(source_index) == CAPTURE_INDEX, "sealed capture changed")
    pins = json.loads(source_index)
    files = {"capture/sha256.json": source_index}
    for name, pin in pins["files"].items():
        data = (kit / name).read_bytes()
        require(identity(data) == pin, "capture file changed")
        files["capture/" + name] = data
    capture = build("nonzero-q-capture-v637", files, capture_summary(files), CAPTURE_README)
    print(json.dumps(capture, sort_keys=True), flush=True)
    raw = (ROOT / "build/performance/lambda-status-v637.json").read_bytes()
    remote = build("lambda-run-status-v637", {"lambda-status-v637.json": raw}, lambda_summary(raw), STATUS_README)
    print(json.dumps(remote, sort_keys=True), flush=True)
    (HERE / "publication.json").write_bytes(canonical({"packages": [capture, remote]}))


if __name__ == "__main__":
    main()
