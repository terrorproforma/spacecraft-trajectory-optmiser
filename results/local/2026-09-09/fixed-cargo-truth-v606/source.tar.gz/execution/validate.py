"""Save exact CPU test/format/audit output and freeze the reviewed runnable input set."""

import datetime
import os
import subprocess
import sys
import time

import common

directory = common.ROOT / "validation"
directory.mkdir(exist_ok=False)
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
scripts = [str(path) for path in sorted(common.ROOT.glob("*.py"))]
commands = [
    (
        "pytest",
        [
            sys.executable,
            "-B",
            "-m",
            "pytest",
            "-q",
            str(common.ROOT / "test_fixed.py"),
            "--junitxml=" + str(directory / "pytest.xml"),
        ],
    ),
    ("ruff-check", [sys.executable, "-B", "-m", "ruff", "check", *scripts]),
    ("ruff-format", [sys.executable, "-B", "-m", "ruff", "format", "--check", *scripts]),
    ("cpu-audit", [sys.executable, "-B", str(common.ROOT / "audit_cpu.py")]),
    ("h100-recipe", [sys.executable, "-B", str(common.ROOT / "launch.py"), "--profile", "h100"]),
    ("local-recipe", [sys.executable, "-B", str(common.ROOT / "launch.py"), "--profile", "local"]),
]
rows = []
for name, command in commands:
    started = time.perf_counter()
    result = subprocess.run(
        command,
        cwd=common.ROOT.parents[2],
        env=environment,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    log = directory / (name + ".log")
    log.write_text(result.stdout)
    row = {
        "name": name,
        "command": command,
        "returncode": result.returncode,
        "seconds": time.perf_counter() - started,
        "log_sha256": common.sha(log),
    }
    rows.append(row)
    common.write(directory / "report.json", {"complete": False, "GPU_calls": 0, "commands": rows})
    print({"name": name, "returncode": result.returncode, "log": str(log)}, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
common.write(directory / "report.json", {"complete": True, "GPU_calls": 0, "commands": rows})
files = {}
for path in sorted(common.ROOT.rglob("*")):
    if not path.is_file() or any(
        part in ("__pycache__", ".pytest_cache", ".ruff_cache") for part in path.parts
    ):
        continue
    name = path.relative_to(common.ROOT).as_posix()
    if name == "ready-manifest.json" or path.suffix == ".pyc":
        continue
    if name in ("launch.json", "run.log") or name.startswith("output/"):
        raise ValueError("unexpected execution evidence in a preparation-only kit")
    files[name] = common.sha(path)
ready = {
    "status": "CPU_validated_ready_for_root_review_no_GPU_execution",
    "created_utc": datetime.datetime.now(datetime.UTC).isoformat(),
    "source_commit": common.read(common.ROOT / "preparation.json")["source_commit"],
    "maximum_whole_route_refinements": 4,
    "maximum_leg_calls": 66,
    "preferred_profile": "h100",
    "profile_budget": "one selected host; alternatives do not multiply the four-route limit",
    "driver_sha256": common.sha(common.ROOT / "run.py"),
    "fixed_wrapper_sha256": common.sha(common.ROOT / "fixed_refine.py"),
    "supervisor_sha256": common.sha(common.ROOT / "launch.py"),
    "files": files,
}
common.write(common.ROOT / "ready-manifest.json", ready)
common.validate_ready()
print(
    {
        "ready_manifest_sha256": common.sha(common.ROOT / "ready-manifest.json"),
        "files": len(files),
        "GPU_calls": 0,
    }
)
