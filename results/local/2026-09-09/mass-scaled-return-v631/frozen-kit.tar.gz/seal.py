"""Seal all immutable inputs after final CPU checks; this never launches the GPU."""

import hashlib
import json
import os
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert __debug__
validation = json.loads((KIT / "validation-harness-final/report.json").read_bytes())
assert validation["passed"] and validation["GPU_calls"] == 0
for name, digest in validation["source_sha256"].items():
    assert sha(KIT / name) == digest, name
host_index = json.loads((KIT / "host-index.json").read_bytes())
assert sha(KIT / "host-index.json") == validation["host_index_sha256"]
for name, digest in host_index.items():
    assert sha(KIT / "host" / name) == digest, name
external = {}
for item in json.loads((KIT / "external-evidence.json").read_bytes()):
    path = ROOT / item["path"]
    assert sha(path) == item["sha256"], item["path"]
    external[os.path.relpath(path, KIT)] = item["sha256"]
profile = json.loads((KIT / "profile.json").read_bytes())
assert profile["scaled_zoh_supported"]
for item in [profile["native_manifest"], *profile["GPU_qualification"]]:
    path = ROOT / item["path"]
    assert sha(path) == item["sha256"]
    external[os.path.relpath(path, KIT)] = item["sha256"]
source_archive = (ROOT / profile["native_manifest"]["path"]).parent / "source.tar.gz"
manifest = json.loads((ROOT / profile["native_manifest"]["path"]).read_bytes())
assert sha(source_archive) == manifest["source_archive_sha256"]
external[os.path.relpath(source_archive, KIT)] = sha(source_archive)
files = {
    str(p.relative_to(KIT)): sha(p)
    for p in sorted(KIT.rglob("*"))
    if p.is_file()
    and not any(x in p.parts for x in ("__pycache__", ".pytest_cache", ".ruff_cache"))
    and p.name != "ready.json"
}
ready = {
    "status": "ready_for_root_single_launch",
    "files": files,
    "external_files": external,
    "file_count": len(files),
    "bytes": sum((KIT / p).stat().st_size for p in files),
    "external_count": len(external),
    "maximum_native_returns": 2,
    "maximum_SCvx_iterations": 88,
    "maximum_fresh_flight_certificates": 2,
    "maximum_full_fleet_checker_pairs": 1,
    "GPU_calls_during_preparation": 0,
}
with (KIT / "ready.json").open("x") as stream:
    json.dump(ready, stream, indent=2)
    stream.write("\n")
print(
    json.dumps(
        {k: v for k, v in ready.items() if k not in ("files", "external_files")}
        | {"ready_sha256": sha(KIT / "ready.json")},
        indent=2,
    )
)
