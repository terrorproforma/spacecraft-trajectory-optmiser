"""Repeated fixed-pattern CW rendezvous benchmark."""

from __future__ import annotations

import argparse
import json
from statistics import fmean, median
from time import perf_counter
from typing import Any

import numpy as np

from spacepdhcg.backends import PersistentOSQP
from spacepdhcg.cqp import CanonicalCQP, independent_canonical_residuals
from spacepdhcg.models import CWRendezvousConfig, CWRendezvousProblem


def run_benchmark(
    *,
    repeats: int = 20,
    intervals: int = 40,
    seed: int = 7,
    tolerance: float = 1.0e-7,
    update_magnitude: float | None = None,
) -> dict[str, Any]:
    """Run repeated numerical updates against one allocated OSQP workspace."""

    if repeats < 2:
        raise ValueError("repeats must be at least two")

    rng = np.random.default_rng(seed)
    config = CWRendezvousConfig(
        intervals=intervals,
        max_component_acceleration=5.0e-2,
    )
    problem = CWRendezvousProblem(config)

    initial_states: list[np.ndarray] = []
    target_states: list[np.ndarray] = []
    if update_magnitude is not None and (
        not np.isfinite(update_magnitude) or update_magnitude < 0.0
    ):
        raise ValueError("update_magnitude must be finite and non-negative")
    base_initial = (
        None
        if update_magnitude is None
        else np.concatenate((rng.uniform(-100.0, 100.0, 3), rng.uniform(-0.05, 0.05, 3)))
    )
    base_target = (
        None
        if update_magnitude is None
        else np.concatenate((rng.uniform(-5.0, 5.0, 3), np.zeros(3)))
    )
    for _ in range(repeats):
        if update_magnitude is None:
            initial = np.concatenate((rng.uniform(-100.0, 100.0, 3), rng.uniform(-0.05, 0.05, 3)))
            target = np.concatenate((rng.uniform(-5.0, 5.0, 3), np.zeros(3)))
        else:
            assert base_initial is not None and base_target is not None
            initial_delta = rng.normal(size=6)
            target_delta = rng.normal(size=6)
            initial_delta /= max(float(np.linalg.norm(initial_delta)), 1.0)
            target_delta /= max(float(np.linalg.norm(target_delta)), 1.0)
            initial = base_initial + update_magnitude * initial_delta
            target = base_target + update_magnitude * target_delta
        initial_states.append(initial)
        target_states.append(target)

    backend = PersistentOSQP(problem.canonical(initial_states[0], target_states[0]))
    update_times: list[float] = []
    solve_times: list[float] = []
    iterations: list[int] = []
    terminal_errors: list[float] = []
    dynamics_defects: list[float] = []
    canonical_primals: list[float] = []
    canonical_duals: list[float] = []
    canonical_naturals: list[float] = []
    objectives: list[float] = []
    previous = None

    for initial, target in zip(initial_states, target_states, strict=True):
        values = problem.values(initial, target)
        update_start = perf_counter()
        backend.update(values)
        update_times.append(perf_counter() - update_start)

        if previous is not None:
            backend.warm_start(previous.primal, previous.dual)

        solution = backend.solve(tolerance=tolerance)
        if not solution.solved:
            raise RuntimeError(f"OSQP failed with status {solution.status!r}")
        diagnostics = problem.diagnostics(solution.primal, initial, target)
        audit = independent_canonical_residuals(
            CanonicalCQP(problem.structure, values),
            solution.primal,
            solution.dual,
        )
        if not diagnostics.feasible(max(1.0e-5, 10.0 * tolerance)):
            raise RuntimeError(f"trajectory failed independent checks: {diagnostics}")

        solve_times.append(solution.solve_seconds)
        iterations.append(solution.iterations)
        terminal_errors.append(diagnostics.terminal_error_inf)
        dynamics_defects.append(diagnostics.dynamics_defect_inf)
        canonical_primals.append(audit.primal)
        canonical_duals.append(audit.dual)
        canonical_naturals.append(audit.natural)
        objectives.append(solution.objective)
        previous = solution

    return {
        "backend": "OSQP persistent CPU reference",
        "repeats": repeats,
        "intervals": intervals,
        "variables": problem.layout.n_variables,
        "constraints": problem.layout.n_constraints,
        "setup_seconds": backend.setup_seconds,
        "mean_update_seconds": fmean(update_times),
        "median_update_seconds": median(update_times),
        "mean_solve_seconds": fmean(solve_times),
        "median_solve_seconds": median(solve_times),
        "mean_iterations": fmean(iterations),
        "maximum_terminal_error": max(terminal_errors),
        "maximum_dynamics_defect": max(dynamics_defects),
        "maximum_canonical_primal_residual": max(canonical_primals),
        "maximum_canonical_dual_residual": max(canonical_duals),
        "maximum_canonical_natural_residual": max(canonical_naturals),
        "maximum_objective": max(objectives),
        "workspace_updates": backend.update_count,
        "explicit_warm_starts": backend.warm_start_count,
        "seed": seed,
        "tolerance": tolerance,
        "update_magnitude": update_magnitude,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repeats", type=int, default=20)
    parser.add_argument("--intervals", type=int, default=40)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--tolerance", type=float, default=1.0e-7)
    arguments = parser.parse_args()
    result = run_benchmark(
        repeats=arguments.repeats,
        intervals=arguments.intervals,
        seed=arguments.seed,
        tolerance=arguments.tolerance,
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
