import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const viewer = resolve(here, '../../../results/lambda/2026-09-06/visualiser');
const manifest = JSON.parse(await readFile(resolve(viewer, 'data/gtoc12-fleet-v633/manifest.json'), 'utf8'));
const paths = ['index.html', 'app.js', 'gtoc12.js', 'replay.js',
  'data/gtoc12-fleet-v633/manifest.json',
  ...Object.keys(manifest.files).filter(name => !name.startsWith('.')).map(name => `data/gtoc12-fleet-v633/${name}`)];
const hashes = {};
for (const path of paths) {
  const response = await fetch(`http://127.0.0.1:4173/${path}`, { signal: AbortSignal.timeout(10000) });
  assert.equal(response.status, 200, path);
  const served = Buffer.from(await response.arrayBuffer());
  assert.deepEqual(served, await readFile(resolve(viewer, path)), `Served bytes differ: ${path}`);
  hashes[path] = { sha256: createHash('sha256').update(served).digest('hex'), bytes: served.length };
}
const app = await readFile(resolve(viewer, 'app.js'), 'utf8');
assert.match(app, /const initialDataset = availableFleets\.has\(datasetParam\) \? datasetParam : "gtoc12-fleet-v633"/);
const report = { passed: true, URL: 'http://127.0.0.1:4173/?dataset=gtoc12-fleet-v633',
  default_dataset: 'gtoc12-fleet-v633', rendered_browser_check: false, served_file_hashes: hashes };
await writeFile(resolve(here, 'http-audit.json'), `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({ passed: true, files: paths.length, url: report.URL }));
