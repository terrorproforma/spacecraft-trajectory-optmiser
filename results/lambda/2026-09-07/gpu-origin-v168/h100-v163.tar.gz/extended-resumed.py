from pathlib import Path
import os,subprocess,json,time,fcntl,signal
root=Path('/home/ubuntu/spacepdhcg-diagnose-v163');repo=root/'repo';out=root/'extended';out.mkdir(exist_ok=True)
base=root/'final';staged=Path('/home/ubuntu/spacepdhcg-recovery-v152')
env=dict(os.environ,SPACEPDHCG_QOCO_LIBRARY=str(base/'libqoco.so'),LD_LIBRARY_PATH=f'{base}:{staged}/cudss/lib:/usr/local/cuda/lib64',PYTHONPATH=str(repo/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
report=json.loads((out/'report.json').read_text()); report.pop('error',None); report['resumed']=time.time()
def run(name,command,timeout=180):
 previous=next((r for r in report['checks'] if r['name']==name),None)
 if previous is not None: return previous
 start=time.time()
 with (out/(name+'.log')).open('x') as log,(out/(name+'.err')).open('x') as err:
  p=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=err,start_new_session=True)
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 row=dict(name=name,command=command,returncode=rc,seconds=time.time()-start)
 report['checks'].append(row);(out/'report.json').write_text(json.dumps(report,indent=2));print(row,flush=True)
 return row
try:
 targets=['device_scvx_integration_test','gtoc12_outer_graph_test','gtoc12_graph_deadline_test','gtoc12_qoco_guard_test','qoco_gpu_audit_test','native_qoco_conversion_test']
 assert run('build',['/home/ubuntu/spacepdhcg/v1/.venv/bin/cmake','--build',str(root/'core-build'),'--target',*targets,'-j','3'])['returncode']==0
 with Path('/home/ubuntu/.spacepdhcg-gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
  for target in targets[1:5]:run(target,[str(root/'core-build/cuda-tests'/target)])
  for ruiz in [0,3]:
   for mode in ['cpu-oracle','device-validation']:
    for origin in ['original','origin']:run(f'native-{ruiz}-{mode}-{origin}',[str(root/'core-build/cuda-tests/native_qoco_conversion_test'),str(ruiz),mode,origin])
  for i in range(6):
   manifest=staged/f'cases/{i}.json';hashes=json.loads((staged/f'cases/{i}-command.json').read_text())[-3:]
   row=run(f'recovery-{i}',[str(root/'core-build/cuda-tests/device_scvx_integration_test'),'--g4-recovery',str(manifest),*hashes,'5'])
   row=dict(row,coordinate=json.loads(manifest.read_text())['coordinate'],records=[json.loads(s) for s in (out/f'recovery-{i}.log').read_text().splitlines() if any(s.startswith('{"case":"'+name+'"') for name in ['g4_sample','production_outer','gpu_recovery_profile','gpu_recovery_failure'])])
   report['recovery'].append(row)
  sanitizer='/usr/local/cuda/bin/compute-sanitizer'
  for target in ['gtoc12_outer_graph_test','gtoc12_qoco_guard_test']:
   run(target+'-memcheck',[sanitizer,'--tool','memcheck','--error-exitcode','98',str(root/'core-build/cuda-tests'/target)],240)
   run(target+'-initcheck-kernel',[sanitizer,'--tool','initcheck','--check-api-memory-access','no','--error-exitcode','98',str(root/'core-build/cuda-tests'/target)],240)
  env['SPACEPDHCG_TEST_QOCO_IPM_GRAPH']='0'
  run('translated-metrics-cache',[str(base/'qoco_equilibrated_stopping_test')])
 report['completed']=True
except Exception as e:report['error']=repr(e);report['completed']=False
report['end']=time.time();(out/'report.json').write_text(json.dumps(report,indent=2))
