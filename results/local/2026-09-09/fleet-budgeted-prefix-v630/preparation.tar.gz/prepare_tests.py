"""Adapt reviewed CPU orchestration checks to the exact three-prefix inventory."""
from pathlib import Path

KIT = Path(__file__).resolve().parent
PRIOR = KIT.parent / "mass-budgeted-frontier-v629"
text = (PRIOR / "test_runtime.py").read_text()
text = text.replace('"batch-protocol.json"', '"protocol.json"').replace('"batch-inputs"', '"inputs"')
a, b = text.index("def test_only_final_four_cases"), text.index('@pytest.mark.parametrize("index", range(4))')
text = text[:a] + '''def test_exact_three_prefixes_and_finite_budget():
    assert [c["id"] for c in PROTOCOL["candidates"]] == [
        "local-v794-ship22-rank0000", "local-v794-ship10-rank0000", "local-v802-ship19-rank0000"]
    assert [c["native_flights"] for c in PROTOCOL["candidates"]] == [16, 18, 16]
    assert sum(c["native_flights"] for c in PROTOCOL["candidates"]) == 50
    assert sum(len(c["waits"]) for c in PROTOCOL["candidates"]) == 3
    assert PROTOCOL["max_outer_iterations"] == 2200
    assert ScvxSettings(**PROTOCOL["settings"]).selected_ephemeris_backend() == "cuda"


''' + text[b:]
text = text.replace('range(4)', 'range(3)').replace('"ship", [8, 19]', '"ship", [22, 10, 19]')
text = text.replace('    value, index, item, raw, rv, calls = coordinator(tmp_path, 0, 0, monkeypatch)\n', '    value, index, item, raw, rv, calls = coordinator(tmp_path, 0, 0, monkeypatch)\n    # Synthetic callback branch check; all three real waits are after deployment.\n    value.case["waits"][0]["kind"] = "before_collection"\n')
text = text.replace('def test_two_ship_splice_preserves_other_21_sections_exactly():', 'def test_three_ship_splice_preserves_other_20_sections_exactly():')
text = text.replace('{8: b"8 new", 19: b"19 new"}', '{22: b"22 new", 10: b"10 new", 19: b"19 new"}')
text = text.replace('s not in (8, 19)', 's not in (22, 10, 19)')
text = text.replace('new[8] == b"8 new\\n" and new[19] == b"19 new\\n"', 'new[22] == b"22 new\\n" and new[10] == b"10 new\\n" and new[19] == b"19 new\\n"')
text = text.replace('expected = {"raw_kg": 14258.672142368949, "weighted_kg": 13005.084630823265, "asteroids": 200}', 'expected = {"raw_kg": baseline["total_mass_kg"] - 1, "weighted_kg": baseline["weighted_score_fixed_bonus_kg"] + 1, "asteroids": 200}')
text += '''

def test_new_production_context_reprices_exact_current_saved_requests():
    from spacepdhcg.gtoc12.refinement_admission import FleetBudgetContext
    from spacepdhcg.gtoc12.bundles import refine_candidates, ClusterPricingSettings
    raw = (C.BASE / "bonus_coefficients.txt").read_bytes()
    weights = {i + 1: float(line.split()[0]) for i, line in enumerate(raw.splitlines())}
    checked = C.read(C.BASE / "checker-binding.json")
    context = FleetBudgetContext.from_verified_result((C.BASE / "Result.txt").read_bytes(),
        independent=checked["independent"], official=checked["official"], weights=weights)
    for index in range(3):
        case, plan = case_and_plan(index)
        before = copy.deepcopy(plan.summary())
        selected = refine_candidates([plan], set(), ClusterPricingSettings(ships=1, refine_top=1),
            fleet_context=context, replacement_ship=case["ship"])
        assert selected == [plan] and before == plan.summary()
        budget = context.replacement(case["ship"], FixedCargoRequest.from_summary(plan.summary()))
        assert abs(budget.raw_gain_kg-case["raw_delta_kg"]) < 1e-8
        assert abs(budget.objective_gain_kg-case["weighted_delta_kg"]) < 1e-8
    assert PROTOCOL["candidates"][0]["raw_delta_kg"] < 0


def test_boundary_batch_telemetry_uses_actual_refined_route_field():
    case, plan = case_and_plan(0)
    route = p.RefinedRoute(plan, [], dict(plan.collected_mass), 500, False, False, 1, 0,
                          {"boundary_ephemeris": {"backend": "cuda", "batches": 1}})
    assert route.scheduler_telemetry["boundary_ephemeris"]["batches"] == 1
    assert 'route.scheduler_telemetry.get("boundary_ephemeris")' in (C.KIT / "worker.py").read_text()
'''
with (KIT / "test_runtime.py").open("x") as stream:
    stream.write(text)
with (KIT / "test_process_guard.py").open("xb") as stream:
    stream.write((PRIOR / "test_process_guard.py").read_bytes())
