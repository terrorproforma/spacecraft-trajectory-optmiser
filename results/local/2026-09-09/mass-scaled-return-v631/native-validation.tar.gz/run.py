"""Finite original/new initializer, controller and memory tests; no optimization."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

LIVE = Path('/mnt/c/Users/Angus/Desktop/projects/spacecraft-trajectory-optmiser')
KIT = LIVE / 'build/performance/gpu-scaled-zoh-v631'
GUARD = LIVE / 'build/performance/dual-profile-v629/process_guard.py'
GUARD_SHA = 'c7039b63b8ba8e1745d77fcb759c83460f6eca309879d304bb60ae3e671f4422'
UUID = 'GPU-4df2f6b5-e866-14a0-eeac-332cb2b757d4'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(expected):
    if not __debug__:
        raise RuntimeError('Assertions required')
    assert sha(KIT / 'manifest.json') == expected and sha(GUARD) == GUARD_SHA
    manifest = json.loads((KIT / 'manifest.json').read_bytes())
    assert manifest['complete'] and manifest['passed'] and manifest['GPU_calls'] == 0
    repo = Path(manifest['root']) / 'repo'
    for name, digest in manifest['sources'].items():
        assert sha(repo / name) == digest, name
    for artifact in manifest['outputs'].values():
        assert sha(Path(artifact['path'])) == artifact['sha256']
    output = KIT / 'gpu-tests-a'
    output.mkdir(exist_ok=False)
    (output / 'run.py').write_bytes(Path(__file__).read_bytes())
    (output / 'process_guard.py').write_bytes(GUARD.read_bytes())
    spec = importlib.util.spec_from_file_location('guard', output / 'process_guard.py')
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    guard.enable_subreaper()
    record = {'complete': False, 'passed': False, 'supervisor_pid': os.getpid(), 'stages': [],
              'manifest_sha256': expected, 'source_tree_sha256': manifest['source_tree_sha256'],
              'runner_sha256': sha(output / 'run.py'), 'process_guard_sha256': GUARD_SHA,
              'process_budget': 4, 'optimizer_calls': 0}

    def persist():
        (output / 'report.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')

    def query(option):
        return subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi', option,
                                        '--format=csv,noheader'], text=True, timeout=10).strip()

    def interrupted(number, _):
        raise InterruptedError(str(number))

    def arm_signals():
        for event in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(event, interrupted)

    child = None
    arm_signals()
    persist()
    try:
        with open('/home/angus/.spacepdhcg-gpu.lock', 'a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            record['gpu_inventory'] = query('--query-gpu=uuid,name,driver_version')
            record['compute_before'] = query('--query-compute-apps=pid,process_name')
            assert UUID in record['gpu_inventory'] and not record['compute_before']
            env = {key: value for key, value in os.environ.items() if not key.startswith(
                ('SPACEPDHCG_', 'QOCO_', 'PDHCG_', 'LD_', 'PYTHONPATH'))}
            env.update(CUDA_VISIBLE_DEVICES=UUID, PYTHONDONTWRITEBYTECODE='1',
                       LD_LIBRARY_PATH='/usr/local/cuda-12.8/lib64',
                       OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
            binary = lambda name: manifest['outputs'][name]['path']
            scaled = binary('gtoc12_scaled_zoh_seed_test')
            commands = [
                ('original-zoh', [binary('gtoc12_zoh_seed_test')], 20, 'PASS: exact ZOH schedule'),
                ('scaled-zoh', [scaled], 20, 'SCALED_ZOH_SEED_PASS'),
                ('controller', [binary('gtoc12_scvx_test')], 20, 'PASS: boundary-corrective acceptance'),
                ('scaled-memcheck', ['/usr/local/cuda-12.8/bin/compute-sanitizer', '--tool',
                  'memcheck', '--error-exitcode', '86', scaled], 40, 'ERROR SUMMARY: 0 errors'),
            ]
            try:
                for name, command, deadline, marker in commands:
                    arm_signals()
                    child = None
                    stage = {'name': name, 'command': command, 'deadline_seconds': deadline}
                    record['stages'].append(stage)
                    started = time.perf_counter()
                    try:
                        with (output / (name + '.log')).open('x') as log:
                            child = subprocess.Popen(command, cwd=repo, env=env, stdout=log,
                                stderr=subprocess.STDOUT, start_new_session=True,
                                pass_fds=(lock.fileno(),))
                            stage['child'] = guard.process_record(child.pid) or {'pid': child.pid}
                            persist()
                            print(json.dumps({'stage': name, 'child_pid': child.pid}), flush=True)
                            stage['exit_code'] = child.wait(timeout=deadline)
                    finally:
                        stage['cleanup'] = guard.cleanup(child, 10, 30)
                        stage['seconds'] = time.perf_counter() - started
                        stage['log_sha256'] = sha(output / (name + '.log'))
                        stage['compute_after'] = query('--query-compute-apps=pid,process_name')
                        persist()
                    assert stage['cleanup']['verified_empty'] and not stage['compute_after']
                    assert stage['exit_code'] == 0, name
                    contents = (output / (name + '.log')).read_text()
                    assert marker in contents
                    if name in ('scaled-zoh', 'scaled-memcheck'):
                        assert 'reference_calls=1 finite_scaled_calls=3 invalid_calls=8 optimizer_calls=0' in contents
                record['passed'] = True
            finally:
                record['final_cleanup'] = guard.cleanup(child, 10, 30)
                record['final_compute_inventory'] = query('--query-compute-apps=pid,process_name')
                record['passed'] = bool(record['passed'] and record['final_cleanup']['verified_empty']
                                        and not record['final_compute_inventory'])
                persist()
    except BaseException:
        record['error'] = traceback.format_exc()
        raise
    finally:
        record['complete'] = True
        persist()
        print(json.dumps(record, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True)
    main(parser.parse_args().manifest_sha256)
