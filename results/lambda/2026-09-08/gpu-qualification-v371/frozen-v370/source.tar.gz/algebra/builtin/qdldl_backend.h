/**
 * @file qdldl_backend.h
 * @author Govind M. Chari <govindchari1@gmail.com>
 *
 * @section LICENSE
 *
 * Copyright (c) 2025, Govind M. Chari
 * This source code is licensed under the BSD 3-Clause License
 *
 * @section DESCRIPTION
 *
 * Defines the qdldl backend.
 */

#ifndef QDLDL_BACKEND_H
#define QDLDL_BACKEND_H

#include "amd.h"
#include "builtin_types.h"
#include "common_linalg.h"
#include "kkt.h"
#include "qdldl.h"
#include "structs.h"

extern LinSysBackend backend;

// No-op for builtin backend (CUDA library loading only needed for CUDA backend)
static inline int load_cuda_libraries(void) { return 1; }

#endif /* #ifndef QDLDL_BACKEND_H */