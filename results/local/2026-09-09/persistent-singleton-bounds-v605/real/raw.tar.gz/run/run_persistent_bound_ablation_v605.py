"""One bounded generic/folded comparison, same adapter and immutable native core."""

import argparse
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import shutil
import subprocess
import time
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--manifest", type=Path, required=True)
parser.add_argument("--manifest-sha256", required=True)
parser.add_argument("--executable", type=Path, required=True)
parser.add_argument("--tiny-report", type=Path, required=True)
args = parser.parse_args()
assert digest(args.manifest) == args.manifest_sha256
manifest = json.loads(args.manifest.read_text())
assert manifest["complete"]
assert digest(args.executable) == manifest["executable_sha256"]
core = Path(manifest["immutable_core_path"])
assert digest(core) == manifest["immutable_core_sha256"]
assert digest(core) == "d4b0bea9672bb0cea612b7d4e8db5d448f1b79b9831be5710723276edd128633"
tiny = json.loads(args.tiny_report.read_text())
assert tiny["complete"], "bounded analytic validation must finish before real captures"

workspace = Path(__file__).resolve().parents[2]
baseline = workspace / "build/performance/persistent-replay-20260909"
output = workspace / "build/performance/persistent-bound-ablation-v605"
auditor = baseline / "source/audit_persistent_snapshot.py"
assert digest(auditor) == digest(workspace / "scripts/gpu/audit_persistent_snapshot.py")
spec = importlib.util.spec_from_file_location("independent_audit", auditor)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
inputs = {
    "conditioning": "1eb1b5a3979c5e86522337dfa94f264e354993163ed44129eff361371e3b49cf",
    "difficult": "14fdc84e9b654df4ac16db71f0bce4fccfa62577f9620ae622ad2196e2f17080",
}
for label, expected in inputs.items():
    assert digest(baseline / "inputs" / (label + ".txt")) == expected

environment = {
    k: v for k, v in os.environ.items() if not k.startswith(("SPACEPDHCG_", "QOCO_REPLAY_"))
}
environment.update(
    LD_LIBRARY_PATH=f"{core.parent}:/usr/local/cuda-12.8/lib64",
    OPENBLAS_NUM_THREADS="1",
    OMP_NUM_THREADS="1",
)
report = dict(
    complete=False,
    pid=os.getpid(),
    scope="single-pair convergence diagnostic per capture; no speedup or nonlinear certificate",
    adapter_manifest_sha256=args.manifest_sha256,
    source_pin=manifest["frozen_commit"],
    executable_sha256=manifest["executable_sha256"],
    library_sha256=digest(core),
    independent_auditor_sha256=digest(auditor),
    tiny_report_sha256=digest(args.tiny_report),
    iteration_budget=100000,
    deadline_seconds=30,
    tolerance=1e-9,
    cone_tolerance=1e-8,
    cases=[],
)


def save():
    pending = output / "report.tmp"
    pending.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    pending.replace(output / "report.json")


with Path("/home/angus/.spacepdhcg-gpu.lock").open("a") as lock:
    print(json.dumps({"pid": os.getpid(), "stage": "waiting_for_shared_gpu_lock"}), flush=True)
    fcntl.flock(lock, fcntl.LOCK_EX)
    output.mkdir(exist_ok=False)
    shutil.copyfile(__file__, output / Path(__file__).name)
    shutil.copyfile(args.manifest, output / "adapter-manifest.json")
    shutil.copyfile(args.tiny_report, output / "tiny-report.json")
    shutil.copyfile(auditor, output / "audit_persistent_snapshot.py")
    shutil.copytree(baseline / "inputs", output / "inputs")
    report["gpu"] = subprocess.run(
        ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    save()
    for label, modes in (("conditioning", (False, True)), ("difficult", (True, False))):
        snapshot = output / "inputs" / (label + ".txt")
        problem = audit.load_snapshot(snapshot)
        for folded in modes:
            name = label + ("-folded" if folded else "-generic")
            command = [
                str(args.executable),
                str(snapshot),
                "--tolerance",
                "1e-9",
                "--iterations",
                "100000",
                "--deadline-seconds",
                "30",
                "--repeats",
                "1",
                "--mode",
                "cold",
            ]
            if folded:
                command.append("--fold-singleton-bounds")
            log = output / (name + ".log")
            row = dict(
                name=name,
                folded=folded,
                label=label,
                command=command,
                input_sha256=inputs[label],
                quadratic_numerical_nonzeros=problem["quadratic_numerical_nonzeros"],
            )
            report["stage"] = name
            save()
            began = time.perf_counter()
            with log.open("x") as stream:
                try:
                    result = subprocess.run(
                        command,
                        env=environment,
                        stdout=stream,
                        stderr=subprocess.STDOUT,
                        timeout=90,
                    )
                    row.update(returncode=result.returncode, timed_out=False)
                except subprocess.TimeoutExpired:
                    row.update(returncode=None, timed_out=True)
            row["process_seconds"] = time.perf_counter() - began
            row["log_sha256"] = digest(log)
            lines = log.read_text().splitlines()
            metadata = [
                json.loads(line.removeprefix("PERSISTENT_REPLAY_META "))
                for line in lines
                if line.startswith("PERSISTENT_REPLAY_META ")
            ]
            raw = [
                json.loads(line.removeprefix("PERSISTENT_REPLAY "))
                for line in lines
                if line.startswith("PERSISTENT_REPLAY ")
            ]
            row["metadata"] = metadata
            row["runtime_identity_matches"] = len(metadata) == 1 and (
                metadata[0]["library_sha256"] == report["library_sha256"]
                and metadata[0]["source_commit"] == report["source_pin"]
                and metadata[0]["source_sha256"] == manifest["compiled_snapshot_source_sha256"]
                and metadata[0]["fold_singleton_bounds"] == folded
            )
            try:
                row["audits"] = audit.audit_log(
                    problem,
                    log,
                    inputs[label],
                    backend="persistent",
                    coordinates="original",
                    record_prefix="PERSISTENT_REPLAY",
                )
            except (ValueError, KeyError) as error:
                row["audit_error"] = str(error)
                row["audits"] = []
            row["qualified"] = sum(r["qualified"] for r in row["audits"])
            row["raw_record_count"] = len(raw)
            row["solver_reports"] = [
                {k: v for k, v in r.items() if k not in ("x", "x_solver", "y", "z", "s")}
                for r in raw
            ]
            fields = {
                "primal": "primal",
                "dual": "dual",
                "gap": "gap",
                "objective": "objective",
                "dual_objective": "dual_objective",
                "block_complementarity_normalized": "complementarity_max_relative",
            }
            row["independent_native_audit_agrees"] = (
                bool(raw)
                and len(raw) == len(row["audits"])
                and all(
                    native["kkt_qualified_original"] == independent["passes_common_kkt_gate"]
                    and all(
                        math.isclose(
                            native["audit"][nk], independent[ik], rel_tol=1e-9, abs_tol=1e-12
                        )
                        for nk, ik in fields.items()
                    )
                    for native, independent in zip(raw, row["audits"], strict=True)
                )
            )
            report["cases"].append(row)
            save()
            print(
                json.dumps(
                    {
                        k: row[k]
                        for k in (
                            "name",
                            "returncode",
                            "qualified",
                            "process_seconds",
                            "runtime_identity_matches",
                            "independent_native_audit_agrees",
                        )
                    }
                ),
                flush=True,
            )
    report.update(complete=True, stage="complete")
    save()
print(json.dumps({"complete": True, "report": str(output / "report.json")}), flush=True)
