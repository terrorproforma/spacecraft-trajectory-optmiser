"""Portable saved-byte and event/display identity audit; no numerical libraries."""

import argparse
import hashlib
import json
import re
from pathlib import Path


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def objects(raw):
    text = raw.decode()
    cursor = re.search(r'  "ships": \[', text).end()
    decoder = json.JSONDecoder()
    result = []
    while True:
        while text[cursor] in " \r\n,":
            cursor += 1
        if text[cursor] == "]":
            return result
        _, end = decoder.raw_decode(text, cursor)
        result.append(text[cursor:end].encode())
        cursor = end


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index-sha256", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    index_raw = (root / "index.json").read_bytes()
    require(sha(index_raw) == args.index_sha256, "Index hash")
    index = json.loads(index_raw)
    for name, pin in index["files"].items():
        path = (root / name).resolve()
        require(path.is_relative_to(root), "Index path escapes artifact")
        data = path.read_bytes()
        require(len(data) == pin["bytes"] and sha(data) == pin["sha256"], f"File differs: {name}")
    final = root / "dataset-b"
    raw = (final / "fleet.json").read_bytes()
    fleet = json.loads(raw)
    mapping = json.loads((final / "source-display-map.json").read_bytes())
    binding = json.loads((final / "checker-binding.json").read_bytes())
    saved = objects(raw)
    require(len(saved) == 24 and len(fleet["asteroids"]) == 208, "Fleet inventory")
    for i in range(23):
        require(sha(saved[i]) == mapping["ship_record_sha256"][str(i + 1)], "Original ship record changed")
    result_sha = "1f420928bbef8da91e3a6f8b74d3bf00039c78d4257215c103a484bc55bb22da"
    require(fleet["source"]["solution_sha256"] == result_sha, "Result binding")
    for item in [binding, binding["official"], binding["independent"]]:
        require(item["result_sha256"] == result_sha, "Checker binding")
    require(binding["official"]["ok"] and binding["independent"]["ok"], "Checker outcome")
    ship = fleet["ships"][23]
    require(ship["display_sample_kind"] == "archived_event_states_only", "Sample label")
    require(ship["replay"]["gap_after_indices"] == list(range(19)), "Display gaps")
    require(ship["replay"]["point_count"] == 20, "Event point count")
    require(ship["final_mass_kg"] == ship["events"][-1]["mass_after_kg"] == 501.4432517332, "Final mass label")
    for event, point, source in zip(ship["events"], ship["replay"]["points_txyz"], mapping["ship24"]["events"], strict=True):
        require(point == list(map(float, source["before_fields"][2:6])), "Event point differs")
        require(event["mass_before_kg"] == float(source["before_fields"][9]), "Before mass")
        require(event["mass_after_kg"] == float(source["after_fields"][9]), "After mass")
    print(json.dumps({"passed": True, "indexed_files": len(index["files"]),
                      "preserved_ship_object_hashes": 23, "event_points": 20,
                      "unsampled_gaps": 19, "Result_sha256": result_sha,
                      "new_propagations": 0, "GPU_calls": 0}))


if __name__ == "__main__":
    main()
