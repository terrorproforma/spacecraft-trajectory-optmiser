"""Assemble one bounded runner from the reviewed v629 harness, without executing it."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
PRIOR = ROOT / "build/performance/mass-budgeted-frontier-v629"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, text):
    with (KIT / name).open("x") as stream:
        stream.write(text)


def main():
    copied = {}
    for name in ("observe.py", "runtime.py", "check_fleet.py", "process_guard.py"):
        text = (PRIOR / name).read_text()
        if name == "runtime.py":
            text = text.replace('"batch-inputs"', '"inputs"')
        write(name, text)
        copied[name] = {"source": str((PRIOR / name).relative_to(ROOT)), "source_sha256": sha(PRIOR / name), "sha256": sha(KIT / name)}
    common = (PRIOR / "common.py").read_text()
    common = common.replace("Frozen v627 runtime and v628 result bindings", "Frozen v630 runtime and v629 result bindings")
    common = common.replace('BASE = ROOT / "results/local/2026-09-09/current-fleet-composition-v628"', 'BASE = KIT / "inputs"')
    common = common.replace('63446ebf3ff1298911bccade7b789a8fb68a0f7db4171906c8e6783a7f174bab', '765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da')
    common = common.replace('_PROFILE = json.loads((KIT / "batch-protocol.json").read_text())["native_profile"]', '_PROFILE = json.loads((KIT / "profile.json").read_text())')
    first, end = common.index("def activate():"), common.index("def sections(")
    common = common[:first] + '''def activate():
    import sys
    if not __debug__:
        raise RuntimeError("Assertions must be enabled")
    assert sha(BASE / "Result.txt") == RESULT_SHA
    for name, expected in read(KIT / "host-index.json").items():
        assert sha(KIT / "host" / name) == expected, name
    sys.meta_path = [f for f in sys.meta_path if f.__class__.__module__ != "_editable_skbc_spacepdhcg"]
    sys.path.insert(0, str(KIT / "host"))
    return sys.modules[__name__]


def catalogue_and_bonus():
    from spacepdhcg.gtoc12.data import load_bonus_table, load_catalogue
    os.environ["SPACEPDHCG_GTOC12_DATA"] = DATA
    catalogue, bonus = load_catalogue(), load_bonus_table()
    assert catalogue.source_sha256 == "99a42cc30d4498d99b8acf507790ab74f040ff2e202ef6c8e90bbb39b6c46675"
    assert bonus.source_sha256 == "e8a3795e599556ed5b66713ab1fa176de93ef37f93cb2a4a87d561539b1caa21"
    return catalogue, bonus


''' + common[end:]
    common = common.replace("import importlib.util\n", "")
    write("common.py", common)
    worker = (PRIOR / "worker.py").read_text()
    worker = worker.replace("Four prescribed routes maximum", "Three prescribed prefixes maximum")
    worker = worker.replace('"batch-protocol.json"', '"protocol.json"').replace('"batch-inputs"', '"inputs"')
    worker = worker.replace('"batch-input-index.json")["files"]', '"input-index.json")')
    worker = worker.replace('C.read(C.KIT / "batch-input-index.json")["files"]', 'C.read(C.KIT / "input-index.json")')
    worker = worker.replace('"whole_routes_started"] <= 4', '"whole_routes_started"] <= 3')
    worker = worker.replace('<= 72', '<= 50').replace('<= 3168', '<= 2200').replace('<= 6', '<= 3').replace('<= 68', '<= 47')
    # The preceding generic replacement can change 68 to 38; enforce the exact cold cap.
    worker = worker.replace('"cold_calls_started"] <= 38', '"cold_calls_started"] <= 47')
    worker = worker.replace('"seeded_calls_started"] <= 4', '"seeded_calls_started"] <= 3')
    worker = worker.replace('from spacepdhcg.gtoc12.refinement_admission import FixedCargoRequest', 'from spacepdhcg.gtoc12.refinement_admission import FixedCargoRequest, FleetBudgetContext\n    from spacepdhcg.gtoc12.bundles import refine_candidates, ClusterPricingSettings')
    needle = '        settings = ScvxSettings(**protocol["settings"])'
    replacement = '''        context = FleetBudgetContext.from_verified_result(
            (C.BASE / "Result.txt").read_bytes(), independent=baseline["independent"],
            official=baseline["official"], weights=weights)
        admission = []
        for case in protocol["candidates"]:
            candidate = RoutePlan.from_summary(C.read(C.KIT / "inputs" / case["input_file"]))
            request = FixedCargoRequest.from_summary(candidate.summary())
            assert request.sha256 == case["request_sha256"]
            chosen = refine_candidates([candidate], set(), ClusterPricingSettings(ships=1, refine_top=1),
                                       fleet_context=context, replacement_ship=case["ship"])
            assert chosen == [candidate]
            budget = context.replacement(case["ship"], request)
            assert not budget.blocker and abs(budget.raw_gain_kg-case["raw_delta_kg"]) <= 1e-8
            assert abs(budget.objective_gain_kg-case["weighted_delta_kg"]) <= 1e-8
            admission.append({"id": case["id"], "request_sha256": request.sha256,
                              "prescribed_budget": C.safe(budget), "production_selector_admitted": True})
        C.write(output / "production-admission.json", admission)
        settings = ScvxSettings(**protocol["settings"])
        assert settings.selected_ephemeris_backend() == "cuda"'''
    assert needle in worker
    worker = worker.replace(needle, replacement)
    worker = worker.replace('                    C.write(directory / "route-result.json", route.summary())', '                    C.write(directory / "route-result.json", route.summary())\n                    record["boundary_ephemeris"] = route.telemetry.get("boundary_ephemeris")')
    worker = worker.replace('"verified v628"', '"verified frontier v629"')
    worker = worker.replace('for ship in [8, 19]', 'for ship in [22, 10, 19]')
    worker = worker.replace('at most nine prescribed combinations', 'at most eight prescribed combinations')
    worker = worker.replace('if raw >= protocol["minimum_raw_kg_for_23_ships"] and (\n                len(footprints) < 2 or not footprints[0] & footprints[1]\n            ):', 'if len(columns[:23]) <= p.C.maximum_ship_count(raw / 23) and all(\n                not a & b for i, a in enumerate(footprints) for b in footprints[i + 1:]\n            ):')
    write("worker.py", worker)
    supervisor = (PRIOR / "supervise.py").read_text()
    supervisor = supervisor.replace("four routes", "three prefixes")
    a, z = supervisor.index('        helper_path = C.SEED / "supervise.py"'), supervisor.index('        (output / "core-manifest.json")')
    supervisor = supervisor[:a] + '''        manifest = C.read(source_manifest)
        assert manifest["complete"] and manifest["passed"]
        assert manifest["outputs"]["library"]["sha256"] == C.CORE_SHA
        assert manifest["outputs"]["library"]["path"] == C.CORE
        archive = source_manifest.parent / "source.tar.gz"
        assert C.sha(archive) == manifest["source_archive_sha256"]
        import tarfile
        import hashlib
        with tarfile.open(archive) as source:
            members = [m for m in source if m.isfile()]
            assert len({m.name for m in members}) == len(members)
            actual = {m.name: hashlib.sha256(source.extractfile(m).read()).hexdigest() for m in members}
        assert actual == manifest["sources"]
        report["core_source_archive_validation"] = {"files": len(actual), "sha256": C.sha(archive)}
''' + supervisor[z:]
    supervisor = supervisor.replace('<= 72', '<= 50').replace('<= 3168', '<= 2200').replace('<= 6', '<= 3').replace('<= 68', '<= 47')
    supervisor = supervisor.replace('"cold_calls_started"] <= 38', '"cold_calls_started"] <= 47').replace('"seeded_calls_started"] <= 4', '"seeded_calls_started"] <= 3')
    supervisor = supervisor.replace('import importlib.util\n', '')
    supervisor = supervisor.replace('from pathlib import Path\n', '')
    # Path is still used by LD_LIBRARY_PATH construction.
    supervisor = supervisor.replace('import traceback\n', 'import traceback\nfrom pathlib import Path\n')
    write("supervise.py", supervisor)
    profile = json.loads((PRIOR / "profile.json").read_bytes())
    profile["host_commit"] = "f9e05c2c446c2ea580e6aa3a49baf7d63caddb10"
    profile["library"] = {"path": "/home/angus/spacepdhcg-route-ephemeris-v630a/build/cuda/libspacepdhcg_cuda.so", "sha256": "4c4520abae50027df9ab5b7f4dbcb84f1e6780ae0ed567964b7764bede439548"}
    profile["runtime_flags"]["SPACEPDHCG_GTOC12_CUDA_LIBRARY"] = profile["library"]["path"]
    profile["native_manifest"] = {"path": "build/performance/gpu-route-ephemeris-v630/manifest.json", "sha256": "7435b392a5faceff50db4361bab287fb3ce98b1b37aa93d2d5d633c0a9e68a14"}
    profile["GPU_qualification"] = "PENDING_ROOT_RESULT_BINDING"
    write("profile.json", json.dumps(profile, indent=2) + "\n")
    write("harness-lineage.json", json.dumps(copied, indent=2) + "\n")
    # Copy exactly the already-built host tree, then only the two reviewed policy overlays.
    manifest = json.loads((ROOT / profile["native_manifest"]["path"]).read_bytes())
    source = Path(manifest["root"]) / "repo"
    (KIT / "host").mkdir()
    index = {}
    for name, expected in manifest["sources"].items():
        if not name.startswith("src/"):
            continue
        path = source / name
        assert sha(path) == expected, name
        destination = KIT / "host" / name.removeprefix("src/")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
        index[str(destination.relative_to(KIT / "host"))] = expected
    overlays = {}
    for name in ("bundles.py", "refinement_admission.py"):
        path = ROOT / "src/spacepdhcg/gtoc12" / name
        destination = KIT / "host/spacepdhcg/gtoc12" / name
        shutil.copyfile(path, destination)
        key = str(destination.relative_to(KIT / "host"))
        index[key] = sha(path)
        overlays[key] = sha(path)
    write("host-index.json", json.dumps(index, indent=2, sort_keys=True) + "\n")
    write("policy-overlays.json", json.dumps(overlays, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"prepared_only": True, "host_files": len(index), "native_profile": profile["library"], "worker_sha256": sha(KIT / "worker.py")}))


if __name__ == "__main__":
    main()
