"""CPU-only construction/provenance audit; no native load, solve, or new physics certificate."""

import ctypes
import json
import os
from unittest.mock import patch

import common

common.activate_source()
os.environ["SPACEPDHCG_GTOC12_DATA"] = common.read(common.ROOT / "profiles.json")["profiles"][
    "local"
]["data"]
from plan import make_plan  # noqa: E402

from spacepdhcg.gtoc12.data import load_bonus_table, load_catalogue  # noqa: E402

with patch.object(ctypes, "CDLL", side_effect=AssertionError("no native work in CPU audit")):
    summaries, audit, solution = common.load_inputs()
    catalogue, bonus = load_catalogue(), load_bonus_table()
    assert catalogue.source_sha256 == common.DATA_SHA and bonus.source_sha256 == common.BONUS_SHA
    weights = {int(body): float(bonus.for_asteroid(int(body))) for body in catalogue.ids}
    plan = make_plan(summaries, audit, weights)
    assert json.loads(json.dumps(plan)) == common.read(common.ROOT / "plan/plan.json")
    row = {
        "status": "CPU_prepared_not_GPU_executed",
        "native_loads": 0,
        "GPU_calls": 0,
        "physics_certificates_created": 0,
        "source_commit": plan["source_commit"],
        "source_manifest_sha256": common.sha(common.ROOT / "source-sha256.json"),
        "input_sha256": common.INCUMBENT_SHA,
        "retained_raw_kg": audit["independent"]["total_mass_kg"],
        "retained_weighted_kg": audit["independent"]["weighted_score_fixed_bonus_kg"],
        "ship_count": solution.ship_count,
        "raw_ship_count_floor_kg": common.FLEET_RAW_FLOOR,
        "maximum_whole_route_refinements": 4,
        "maximum_leg_calls": plan["maximum_leg_calls"],
        "cases": [
            {
                "id": case["id"],
                "ship": case["ship"],
                "kind": case["kind"],
                "legs": case["maximum_leg_calls"],
                "prescribed_raw_kg": case["prescribed_raw_kg"],
                "prescribed_weighted_kg": case["prescribed_weighted_kg"],
                "fleet_raw_gain_if_certified_kg": case["raw_gain_kg"],
                "fleet_weighted_gain_if_certified_kg": case["weighted_gain_kg"],
                "archived_certified_propellant_kg": case["original_certified_propellant_kg"],
                "original_route_final_dry_mass_kg": summaries[case["ship"]]["final_mass_kg"],
            }
            for case in plan["cases"]
        ],
        "acceptance": {
            "prescribed_epochs_and_cargo_unchanged": True,
            "actual_control_solves_mandatory": True,
            "matching_control_failure_skips_probe": True,
            "independent_leg_and_route_certification_required": True,
            "both_full_fleet_checkers_required": True,
            "weighted_score_gain_and_raw_ship_count_floor_required": True,
            "native_scvx_settings_identical_to_v595": True,
            "certification_tolerances_unchanged": True,
        },
        "limits": [
            (
                "A failed cold-start control blocks interpretation of its probe; "
                "no physical infeasibility claim."
            ),
            "Two selected probes cannot measure a population-wide surrogate false-negative rate.",
            (
                "Measured proxy propellant comparisons are available only after "
                "a route completes certification."
            ),
            (
                "Sequential route solving stops at the first uncertified leg; "
                "later initial masses are unknown."
            ),
            "Local/H100 profiles are alternatives; only one four-route campaign is authorized.",
        ],
    }
common.write(common.ROOT / "cpu-audit.json", row)
print(
    json.dumps(
        {
            key: row[key]
            for key in (
                "status",
                "GPU_calls",
                "maximum_whole_route_refinements",
                "maximum_leg_calls",
            )
        }
    )
)
