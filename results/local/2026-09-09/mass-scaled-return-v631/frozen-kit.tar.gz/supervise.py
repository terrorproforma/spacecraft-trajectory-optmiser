"""Single-use foreground owner: two returns, shared GPU lock, hard240-second wait."""

from __future__ import annotations

import fcntl
import json
import os
import signal
import subprocess
import time
import traceback
from pathlib import Path

import common as C
import process_guard


def finish_cleanup(report, child, profile, lock):
    """Keep the inherited lock until all owned descendants and inventory are checked."""
    try:
        report["owned_descendant_cleanup"] = process_guard.cleanup(child, 10, 30)
    except BaseException as error:
        report["failures"].append({"reaping_error": repr(error)})
    report["child_exit_after_cleanup"] = None if child is None else child.poll()
    empty_inventory = False
    if profile is not None and lock is not None:
        try:
            inventory = subprocess.check_output(
                [
                    profile["nvidia_smi"],
                    "--query-compute-apps=pid,process_name",
                    "--format=csv,noheader",
                ],
                text=True,
                timeout=15,
            ).strip()
            report["compute_processes_after_cleanup"] = inventory
            empty_inventory = not inventory or inventory == "No running processes found"
        except BaseException as error:
            report["failures"].append({"post_cleanup_inventory_error": repr(error)})
    report["passed"] = bool(
        report["passed"]
        and report.get("owned_descendant_cleanup", {}).get("verified_empty", False)
        and empty_inventory
        and not report["failures"]
    )


def run_owned(command, stream, env, lock):
    return subprocess.Popen(
        command,
        cwd=C.KIT,
        env=env,
        stdout=stream,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        pass_fds=(lock.fileno(),),
    )


def main():
    if not __debug__:
        raise RuntimeError("assertions required")
    C.write(
        C.KIT / "launch-marker.json",
        {"pid": os.getpid(), "started": time.time(), "launcher_sha256": C.sha(__file__)},
    )
    output = C.KIT / "output"
    output.mkdir()
    report = {"complete": False, "passed": False, "supervisor_pid": os.getpid(), "failures": []}
    child = lock = profile = None

    def interrupted(signum, frame):
        raise InterruptedError(f"Signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGHUP, interrupted)
    try:
        ready = C.read(C.KIT / "ready.json")
        for name, expected in ready["files"].items():
            assert C.sha(C.KIT / name) == expected, name
        for name, expected in ready["external_files"].items():
            assert C.sha(C.KIT / name) == expected, name
        profile = C.read(C.KIT / "profile.json")
        assert profile["scaled_zoh_supported"] and profile["GPU_qualification"]
        for qualification in profile["GPU_qualification"]:
            path = C.ROOT / qualification["path"]
            assert C.sha(path) == qualification["sha256"]
            checked = C.read(path)
            assert checked["complete"] and checked["passed"]
        assert C.sha(profile["library"]["path"]) == profile["library"]["sha256"] == C.CORE_SHA
        assert C.sha(profile["qoco"]["path"]) == profile["qoco"]["sha256"]
        assert C.sha(profile["python"]) == profile["python_sha256"]
        source_manifest = C.CORE_MANIFEST
        assert C.sha(source_manifest) == C.MANIFEST_SHA
        manifest = C.read(source_manifest)
        assert manifest["complete"] and manifest["passed"]
        assert manifest["outputs"]["library"]["sha256"] == C.CORE_SHA
        assert manifest["outputs"]["library"]["path"] == C.CORE
        archive = source_manifest.parent / "source.tar.gz"
        assert C.sha(archive) == manifest["source_archive_sha256"]
        import hashlib
        import tarfile

        with tarfile.open(archive) as source:
            members = [m for m in source if m.isfile()]
            assert len({m.name for m in members}) == len(members)
            actual = {
                m.name: hashlib.sha256(source.extractfile(m).read()).hexdigest() for m in members
            }
        assert actual == manifest["sources"]
        report["core_source_archive_validation"] = {"files": len(actual), "sha256": C.sha(archive)}
        (output / "core-manifest.json").write_bytes(source_manifest.read_bytes())
        lock = open(profile["lock"], "a+")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

        def query(flag):
            return subprocess.check_output(
                [profile["nvidia_smi"], flag, "--format=csv,noheader"], text=True, timeout=15
            ).strip()

        gpu = query("--query-gpu=uuid,name,driver_version")
        processes = query("--query-compute-apps=pid,process_name")
        assert profile["gpu_uuid"] in gpu and "RTX 5090" in gpu
        assert not processes or processes == "No running processes found"
        env = {
            k: v
            for k, v in os.environ.items()
            if not k.startswith(("SPACEPDHCG_", "QOCO_", "PDHCG_", "LD_", "PYTHON"))
        }
        env.update(
            SPACEPDHCG_GTOC12_CUDA_LIBRARY=C.CORE,
            SPACEPDHCG_QOCO_LIBRARY=profile["qoco"]["path"],
            SPACEPDHCG_TEST_GTOC12_CONDITIONING_RETRY="1",
            SPACEPDHCG_ROUTE_SUPERVISED=str(os.getpid()),
            SPACEPDHCG_GTOC12_DATA=C.DATA,
            CUDA_VISIBLE_DEVICES=profile["gpu_uuid"],
            PYTHONOPTIMIZE="0",
            PYTHONNOUSERSITE="1",
            PYTHONDONTWRITEBYTECODE="1",
            OPENBLAS_NUM_THREADS="1",
            OMP_NUM_THREADS="1",
            LD_LIBRARY_PATH=str(Path(C.CORE).parent) + ":" + profile["ld_library_path"],
        )
        command = [profile["python"], "-B", str(C.KIT / "worker.py")]
        report.update(
            command=command,
            gpu=gpu,
            compute_processes=processes,
            ready_sha256=C.sha(C.KIT / "ready.json"),
            hard_wait_seconds=240,
            term_grace_seconds=10,
            kill_reap_seconds=30,
        )
        C.write(output / "preflight.json", report)
        process_guard.enable_subreaper()
        with (output / "worker.log").open("x") as stream:
            child = run_owned(command, stream, env, lock)
            report["child_pid"] = child.pid
            C.write(
                output / "child-launch.json",
                {"pid": child.pid, "supervisor": os.getpid(), "hard_wait_seconds": 240},
            )
            print(json.dumps({"supervisor_pid": os.getpid(), "child_pid": child.pid}), flush=True)
            try:
                report["exit_code"] = child.wait(timeout=240)
            except subprocess.TimeoutExpired:
                report["timed_out"] = True
                raise
        assert report["exit_code"] == 0
        terminal = C.read(output / "report.json")
        assert terminal["complete"] and terminal["status"] != "execution_failed"
        assert terminal["native_solves_started"] <= 2 and terminal["native_iterations"] <= 88
        assert terminal["flight_certificate_calls"] <= 2 and terminal["wait_certificate_calls"] == 0
        assert (
            terminal["full_fleet_CPU_checks"] <= 1 and terminal["full_fleet_official_checks"] <= 1
        )
        assert terminal["standalone_inspection_calls"] == 0
        assert terminal["seeded_calls_started"] <= 2 and terminal["cold_calls_started"] == 0
        report["passed"] = True  # Accounted execution; trajectory outcome is in worker report.
    except BaseException as error:
        report["failures"].append({"error": repr(error), "traceback": traceback.format_exc()})
        raise
    finally:
        finish_cleanup(report, child, profile, lock)
        report.update(complete=True, ended=time.time())
        try:
            C.write(output / "launch-report.json", report)
        finally:
            if lock is not None:
                lock.close()
    if not report["passed"]:
        raise RuntimeError("Owned process cleanup or final compute inventory failed")


if __name__ == "__main__":
    main()
