from pathlib import Path
import subprocess,os,json,fcntl,time,signal
root=Path('/home/ubuntu/spacepdhcg-recovery-v157');out=root/'guard-initcheck-kernel';out.mkdir(exist_ok=False)
env=dict(os.environ,SPACEPDHCG_QOCO_LIBRARY=str(root/'final/libqoco.so'),LD_LIBRARY_PATH=str(root/'final')+':/home/ubuntu/spacepdhcg-recovery-v152/cudss/lib:/usr/local/cuda/lib64')
command=['/usr/local/cuda/bin/compute-sanitizer','--tool','initcheck','--check-api-memory-access','no','--error-exitcode','98',str(root/'core-build/cuda-tests/gtoc12_qoco_guard_test')]
with open('/home/ubuntu/.spacepdhcg-gpu.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 start=time.time();result=dict(command=command,start=start)
 with (out/'stdout.log').open('x') as stdout,(out/'stderr.log').open('x') as stderr:
  p=subprocess.Popen(command,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  result['pid']=p.pid;(out/'report.json').write_text(json.dumps(result,indent=2))
  try:result['returncode']=p.wait(timeout=240)
  except subprocess.TimeoutExpired:
   result['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 result.update(end=time.time(),seconds=time.time()-start);(out/'report.json').write_text(json.dumps(result,indent=2))
