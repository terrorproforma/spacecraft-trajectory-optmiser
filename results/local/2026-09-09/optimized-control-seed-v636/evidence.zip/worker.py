"""One original-horizon return from saved optimized physical thrust; no mass scaling."""
import os
import time
import traceback
from types import SimpleNamespace

import common as C
import numpy as np

COUNTERS = (
    "native_solves_started", "native_solves_returned", "native_iterations",
    "flight_certificate_calls", "wait_certificate_calls", "seeded_calls_started",
    "cold_calls_started", "full_fleet_CPU_checks", "full_fleet_official_checks",
)


def main():
    if not __debug__ or os.environ.get("SPACEPDHCG_ROUTE_SUPERVISED") != str(os.getppid()):
        raise RuntimeError("Use the reviewed foreground supervisor")
    C.activate()
    from check_fleet import check
    from observe import Observer, save_solution
    from runtime import emit_candidate, load_prefix
    from spacepdhcg.gtoc12.fixed_refinement import FrozenLegRunner
    from spacepdhcg.gtoc12.gpu_execution import using_gpu_execution
    from spacepdhcg.gtoc12.low_thrust import LegBoundary, ScvxSettings
    from spacepdhcg.gtoc12.search import RoutePlan
    from spacepdhcg.gtoc12.trajectory_seed import ZohTrajectorySeed

    protocol = C.read(C.KIT / "protocol.json")
    assert protocol["fleet_binding_status"] == C._FLEET["status"] == "reviewed"
    output = C.KIT / "output"
    report = dict.fromkeys(COUNTERS, 0) | {
        "complete": False, "status": "running", "cases": [],
        "standalone_inspection_calls": 0, "whole_route_reruns": 0,
        "Lambert_calls": 0, "fresh_prefix_propagations": 0,
        "ephemeris_batches": 0, "ephemeris_state_requests": 0,
        "CPU_boundary_ephemeris_calls": 0, "incumbent_promoted": False,
        "mass_scaling_requested": False,
        "initial_state_role": "canonical saved boundary, not raw propagated prefix endpoint",
    }
    started = time.perf_counter()
    deadline = started + 220

    def save():
        for key in COUNTERS[:7]:
            report[key] = sum(case[key] for case in report["cases"])
        C.current(output / "report.json", report)

    save()
    try:
        settings = ScvxSettings(**C.read(C.BASE / "settings.json"))
        assert settings.max_iterations == 40 and settings.polish_iterations == 4
        assert settings.hold == "zoh" and settings.seed_backend == "cuda"
        plan = RoutePlan.from_summary(C.read(C.BASE / "candidate-plan.json"))
        identity = plan.summary()
        last = plan.legs[-1]
        assert (last.from_id, last.to_id, last.departure_epoch, last.arrival_epoch) == (
            17126, 0, 69263.0, 69713.0,
        )
        assert sum(plan.collected_mass.values()) == protocol["cargo_kg"]
        prefix = load_prefix(plan)
        report.update(saved_prefix_flight_certificates=17, saved_prefix_wait_certificates=1)
        raw = C.read(C.BASE / "failed-boundary.json")
        for key in ("departure_position", "departure_velocity", "arrival_position", "arrival_velocity"):
            raw[key] = np.asarray(raw[key], dtype=np.float64)
        boundary = LegBoundary(**raw)
        assert boundary.initial_mass == protocol["initial_mass_kg"]
        assert boundary.minimum_final_mass == protocol["minimum_final_mass_kg"]
        assert not boundary.free_departure_vinf and boundary.free_arrival_vinf
        with np.load(C.BASE / "optimized-native-raw.npz", allow_pickle=False) as archive:
            # Deliberately do not read or upload any inconsistent returned state node.
            epochs = archive["epochs"].copy()
            thrust = archive["thrust_n"].copy()
        import hashlib
        review = C.read(C.KIT / "input-review.json")
        assert hashlib.sha256(epochs.tobytes()).hexdigest() == review["epochs_payload_sha256"]
        assert hashlib.sha256(thrust.tobytes()).hexdigest() == review["thrust_payload_sha256"]
        assert np.array_equal(epochs, 69263.0 + 2.0 * np.arange(226))
        assert thrust.shape == (226, 3) and np.isfinite(thrust).all()
        assert np.all(thrust[-1] == 0.0)
        initial = np.concatenate((boundary.departure_position, boundary.departure_velocity,
                                  np.array([boundary.initial_mass])))
        assert hashlib.sha256(initial.tobytes()).hexdigest() == review["canonical_initial_payload_sha256"]
        seed = ZohTrajectorySeed(epochs, initial, thrust, C.sha(C.BASE / "optimized-native-raw.npz"),
                                 target_initial_mass_kg=None)
        assert seed.target_initial_mass_kg is None and not seed.allow_mesh_refinement
        assert seed.thrust_n.tobytes() == thrust.tobytes()
        assert seed.initial_state.tobytes() == initial.tobytes()
        seed.validate_for(boundary, settings, epochs)
        directory = output / "optimized_control_return"
        (directory / "legs/00").mkdir(parents=True)
        C.write(directory / "prescribed-plan.json", identity)
        C.write(directory / "boundary.json", {"generated": boundary, "effective": boundary})
        np.savez_compressed(directory / "seed-upload.npz", initial_state=seed.initial_state,
                            thrust_n=seed.thrust_n, node_epochs_mjd=seed.node_epochs_mjd)
        C.write(directory / "initialization.json", {
            "kind": "optimized_v632_physical_thrust_GPU_ZOH_rollout",
            "source_npz_sha256": C.sha(C.BASE / "optimized-native-raw.npz"),
            "source_thrust_payload_sha256": review["thrust_payload_sha256"],
            "initial_state_role": report["initial_state_role"],
            "target_initial_mass_kg": None, "mass_ratio": 1.0,
            "Python_thrust_scaling_or_clipping": False,
            "GPU_mass_scaling_requested": False,
            "old_state_nodes_uploaded": 0,
            "old_vinf_outputs_uploaded": 0,
            "prefix_position_residual_km": review["prefix_certificate_position_error_km"],
        })
        row = dict.fromkeys(COUNTERS, 0) | {"case": directory.name, "certified": False}
        report["cases"].append(row)
        observer = Observer(directory, row, save, max_flights=1, max_waits=0)
        observer.index = 0
        runner = FrozenLegRunner(settings)
        try:
            if time.perf_counter() >= deadline:
                raise TimeoutError("Deadline before the sole native return")
            with using_gpu_execution(SimpleNamespace(gpu_execution="graph", outer_loop_backend="cuda", workers=1)):
                with observer:
                    item, details = runner.solve(last, boundary, 0, seed=seed)
            if item.solution is not None:
                save_solution(item.solution, directory / "legs/00", "post-clamp")
            C.write(directory / "leg-result.json", details)
            row.update(status=details["status"], certified=bool(item.certified and item.certificate is not None))
            if row["certified"]:
                margin = item.certificate.final_mass_kg - boundary.minimum_final_mass
                row.update(certified_final_mass_kg=item.certificate.final_mass_kg,
                           mass_margin_kg=margin, fixed_mass_passed=margin >= -1e-9,
                           certified=margin >= -1e-9)
            C.write(directory / "case-report.json", row)
        finally:
            runner.close()
            save()
        assert plan.summary() == identity
        assert seed.thrust_n.tobytes() == thrust.tobytes()
        if not row["certified"]:
            report["status"] = "optimized_control_return_uncertified"
            return
        section, provenance = emit_candidate(plan, prefix, item)
        destination = output / "candidate-fleet"
        destination.mkdir()
        baseline = (C.CURRENT / "Result.txt").read_bytes()
        payload = C.splice(baseline, {10: section})
        before, after = C.sections(baseline), C.sections(payload)
        assert set(before) == set(after) and all(before[s] == after[s] for s in before if s != 10)
        (destination / "ship10.txt").write_bytes(section)
        (destination / "Result.txt").write_bytes(payload)
        C.write(destination / "emission.json", provenance)
        C.write(destination / "section-proof.json", {
            "retained_ships": [s for s in before if s != 10],
            "retained_sections_byte_identical": True,
            "source_Result_sha256": C.RESULT_SHA, "candidate_Result_sha256": C.sha(destination / "Result.txt"),
        })
        catalogue, bonus = C.catalogue_and_bonus()
        report["fleet_acceptance"] = check(destination / "Result.txt", catalogue, bonus, report, save,
                                           deadline, protocol["prescribed_fleet_only_if_both_checkers_pass"])
        report["status"] = "verified_fixed_cargo_candidate" if report["fleet_acceptance"]["accepted_improvement"] else "full_fleet_check_failed"
    except BaseException as error:
        report.update(status="execution_failed", error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        report.update(complete=True, worker_seconds=time.perf_counter() - started)
        save()


if __name__ == "__main__":
    main()
