"""Install the already checked dataset without replacing an existing directory."""

import hashlib
import json
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = HERE / "dataset-b"
TARGET = ROOT / "results/lambda/2026-09-06/visualiser/data/gtoc12-fleet-v633"


def main():
    validation = json.loads((HERE / "schema-validation.json").read_bytes())
    if not validation["passed"]:
        raise RuntimeError("A passing schema audit is required")
    prior = json.loads((HERE / "installation.json").read_bytes())
    if (HERE / "installation-b.json").exists():
        raise RuntimeError("Corrected dataset was already installed")
    if {p.name for p in TARGET.iterdir()} != set(prior["files"]):
        raise RuntimeError("Unexpected target files; preserve concurrent changes")
    for name, pin in prior["files"].items():
        if hashlib.sha256((TARGET / name).read_bytes()).hexdigest() != pin["sha256"]:
            raise RuntimeError("Earlier installation changed; preserve concurrent changes")
    files = {}
    for source in sorted(SOURCE.iterdir()):
        if not source.is_file():
            raise RuntimeError("Only dataset files may be installed")
        destination = TARGET / source.name
        shutil.copyfile(source, destination)
        raw = source.read_bytes()
        if destination.read_bytes() != raw:
            raise RuntimeError("Installed bytes differ")
        files[source.name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    (HERE / "installation-b.json").write_text(json.dumps({"passed": True, "files": files,
        "directory": str(TARGET), "url": "http://127.0.0.1:4173/?dataset=gtoc12-fleet-v633"}, indent=2) + "\n")


if __name__ == "__main__":
    main()
