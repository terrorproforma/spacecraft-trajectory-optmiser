"""Freeze the finite protocol; new native runtime qualification is still pending."""

import json
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
prior = ROOT / "build/performance/fleet-budgeted-prefix-v630"
report = json.loads((KIT / "report.json").read_bytes())
profile = json.loads((prior / "profile.json").read_bytes())
profile["scaled_zoh_supported"] = False
profile["status"] = "pending_new_native_build_and_GPU_qualification_not_executable"
profile["source_head"] = "6c686cce48763a5ab34687a74d810f5ce693589b"
protocol = {
    "status": "prepared_pending_root_native_validation_and_review",
    "source_head": profile["source_head"],
    "changed_factor": "CUDA mass/thrust homothety of exact certified ZOH return seed",
    "baseline_Result_sha256": report["current_fleet"]["result_sha256"],
    "candidate_request_sha256": report["candidate"]["request_sha256"],
    "prescribed_weighted_gain_kg": report["candidate"]["weighted_delta_kg"],
    "prescribed_raw_gain_kg": report["candidate"]["raw_delta_kg"],
    "control": {
        "source_initial_mass_kg": 1472.1728669809,
        "cargo_kg": 671.4579055442,
        "minimum_final_mass_kg": 1171.4579055442,
        "target_initial_mass_kg": 1472.1728669809,
        "scaling_factor": 1.0,
        "can_promote": False,
        "failure_blocks_candidate": True,
    },
    "candidate": {
        "target_initial_mass_kg": 1438.8883038351994,
        "cargo_kg": 677.2073921971253,
        "minimum_final_mass_kg": 1177.2073921971253,
        "source_prefix": "v630 ship10 certified flights0..16 plus wait08",
        "remaining_seed_final_mass_shortfall_kg": 10.289981565280641,
    },
    "schedule": report["schedule"],
    "maximum_native_returns": 2,
    "maximum_SCvx_iterations_per_return": 44,
    "SCvx_main_iterations": 40,
    "SCvx_polish_iterations": 4,
    "maximum_SCvx_iterations_total": 88,
    "maximum_new_flight_certificates": 2,
    "maximum_new_wait_certificates": 0,
    "maximum_standalone_seed_inspections": 0,
    "maximum_Lambert_search_calls": 0,
    "maximum_whole_route_reruns": 0,
    "prefix_certificates_reused": {"flights": 17, "waits": 1},
    "maximum_original_CPU_fleet_checks": 1,
    "maximum_original_official_fleet_checks": 1,
    "worker_soft_deadline_seconds": 220,
    "supervisor_hard_deadline_seconds": 240,
    "TERM_cleanup_seconds": 10,
    "KILL_reap_seconds": 30,
    "native_inner_wall_seconds_unchanged": 900,
    "failure_policy": "Retain every outcome. No retry, cargo shrink, retiming or alternate seed.",
    "qualification": "The control is never a gain. New return and saved prefix form only a draft until both original full-fleet checks pass on identical Result bytes.",
    "promotion": "Retain the current fleet. A passing output is a candidate improvement for root to compare with the latest incumbent before publication.",
}
for name, value in (("protocol.json", protocol), ("profile-draft.json", profile)):
    with (KIT / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
