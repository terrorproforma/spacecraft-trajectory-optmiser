"""One unchanged original checker pair on the selected exact fleet bytes."""

from __future__ import annotations

import dataclasses
import math
import time

import common as C


def qualify(independent, official, expected, baseline):
    raw, weighted = (
        independent.get("total_mass_kg"),
        independent.get("weighted_score_fixed_bonus_kg"),
    )
    finite = all(isinstance(x, (int, float)) and math.isfinite(x) for x in (raw, weighted))
    prescribed = bool(
        finite
        and abs(raw - expected["raw_kg"]) <= 1e-8
        and abs(weighted - expected["weighted_kg"]) <= 1e-8
    )
    accepted = bool(
        independent.get("ok")
        and official.get("ok")
        and prescribed
        and independent.get("ships") == official.get("ships") == expected["ships"]
        and independent.get("mined_asteroids")
        == official.get("mined_asteroids")
        == expected["asteroids"]
        and independent.get("ship_limit", 0) >= expected["ships"]
        and weighted > baseline["weighted_score_fixed_bonus_kg"] + 1e-8
    )
    return {
        "accepted_improvement": accepted,
        "both_original_checkers_passed": bool(independent.get("ok") and official.get("ok")),
        "prescribed_score_matches": prescribed,
        "raw_kg": raw,
        "weighted_kg": weighted,
        "raw_delta_kg": raw - baseline["total_mass_kg"] if finite else None,
        "weighted_delta_kg": weighted - baseline["weighted_score_fixed_bonus_kg"]
        if finite
        else None,
        "raw_decrease_allowed_only_with_original_ship_rule": True,
        "reporting_bound_kg": 1e-8,
        "physics_tolerances_unchanged": True,
        "incumbent_promoted": False,
    }


def check(path, catalogue, bonus, report, save, deadline, expected):
    from spacepdhcg.gtoc12.official import run_official_verifier
    from spacepdhcg.gtoc12.verifier import Gtoc12Verifier

    digest = C.sha(path)
    assert report["full_fleet_CPU_checks"] == report["full_fleet_official_checks"] == 0
    if time.perf_counter() >= deadline:
        raise TimeoutError("Deadline before full-fleet check")
    report["full_fleet_CPU_checks"] += 1
    save()
    start = time.perf_counter()
    independent = Gtoc12Verifier(catalogue, bonus=bonus).verify_file(path)
    report["full_fleet_CPU_seconds"] = time.perf_counter() - start
    C.write(path.parent / "independent-full.json", dataclasses.asdict(independent))
    ind = independent.summary() | {"result_sha256": digest}
    C.write(path.parent / "independent.json", ind)
    assert C.sha(path) == digest
    remaining = deadline - time.perf_counter()
    if remaining <= 0:
        raise TimeoutError("Deadline before official checker")
    report["full_fleet_official_checks"] += 1
    save()
    official = run_official_verifier(
        path, timeout=remaining, keep_directory=path.parent / "official"
    )
    C.write(path.parent / "official-full.json", dataclasses.asdict(official))
    off = official.summary() | {"result_sha256": digest}
    C.write(path.parent / "official.json", off)
    assert C.sha(path) == C.sha(path.parent / "official/Result.txt") == digest
    C.write(
        path.parent / "checker-binding.json",
        {"result_sha256": digest, "independent": ind, "official": off},
    )
    acceptance = qualify(ind, off, expected, C.read(C.BASE / "checker-binding.json")["independent"])
    C.write(path.parent / "acceptance.json", acceptance)
    return acceptance
