"""Freeze exact current Python, verified fleet and demonstrated native provenance; no GPU."""

import hashlib
import io
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
COMMIT = "b08b1f5aa464659e558926713d29bcd364a3778f"
V595_COMMIT = "bd944af935e5b71e50ef7ff4d34ea7674602832a"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


source = ROOT / "source"
source.mkdir(exist_ok=False)
paths = ["src", "benchmarks/gtoc12", "pyproject.toml", "results/gtoc12/hop_inflation_fit.json"]
data = subprocess.check_output(["git", "archive", COMMIT, *paths], cwd=REPO)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive.getmembers():
        assert (source / member.name).resolve().is_relative_to(source)
        assert not member.issym() and not member.islnk()
    archive.extractall(source)
source_hashes = {
    p.relative_to(source).as_posix(): digest(p) for p in sorted(source.rglob("*")) if p.is_file()
}
write(ROOT / "source-sha256.json", source_hashes)
original_inputs = REPO / "build/performance/incident-window-substitution-v604/inputs"
inputs = ROOT / "inputs"
inputs.mkdir(exist_ok=False)
for name, expected in json.loads((original_inputs / "sha256.json").read_text()).items():
    assert digest(original_inputs / name) == expected
    shutil.copy2(original_inputs / name, inputs / name)
shutil.copy2(original_inputs / "sha256.json", inputs / "sha256.json")
reference = ROOT / "reference"
reference.mkdir(exist_ok=False)
copies = {
    "next-hypothesis.json": (
        "results/local/2026-09-09/incident-window-substitution-v604/audit/next-hypothesis.json"
    ),
    "v595-report.json": "results/local/2026-09-09/orphan-recovery-v595/report.json",
    "v595-validation.json": "results/local/2026-09-09/orphan-recovery-v595/audit/audit.json",
    "v590-native-source.tar.gz": (
        "results/local/2026-09-09/joint-candidates-v596/original-v590/native-source.tar.gz"
    ),
    "v590-native-source-manifest.json": (
        "results/local/2026-09-09/joint-candidates-v596/original-v590/native-source-manifest.json"
    ),
    "v590-build.json": (
        "results/local/2026-09-09/joint-candidates-v596/original-v590/joint-build-v590.json"
    ),
}
for name, origin in copies.items():
    shutil.copy2(REPO / origin, reference / name)
previous = json.loads((reference / "v595-report.json").read_text())
assert previous["complete"] and previous["best"]["ok"]
assert previous["best"]["independent"]["ok"] and previous["best"]["official"]["ok"]
relevant = [name for name in source_hashes if name.startswith("src/")]
changed = set(
    subprocess.check_output(
        ["git", "diff", "--name-only", V595_COMMIT, COMMIT, "--", "src"], cwd=REPO, text=True
    ).splitlines()
)
assert changed == {
    "src/spacepdhcg/gtoc12/gpu_lambert.py",
    "src/spacepdhcg/gtoc12/jointopt.py",
    "src/spacepdhcg/gtoc12/gpu_joint.py",
}, changed
checked = {}
for name in relevant:
    if name in changed:
        continue
    old = subprocess.check_output(["git", "show", f"{V595_COMMIT}:{name}"], cwd=REPO)
    assert hashlib.sha256(old).hexdigest() == source_hashes[name], name
    checked[name] = source_hashes[name]
native = {
    "SPACEPDHCG_GTOC12_CUDA_LIBRARY": (
        "/home/angus/build-spacepdhcg-joint-v590/build/cuda/libspacepdhcg_cuda.so"
    ),
    "SPACEPDHCG_QOCO_LIBRARY": "/home/angus/build-qoco-scaled-pool-v540/final/libqoco.so",
}
native_hashes = {name: digest(Path(path)) for name, path in native.items()}
assert native_hashes == previous["native_sha256"]
write(
    ROOT / "preparation.json",
    {
        "source_commit": COMMIT,
        "source_files": len(source_hashes),
        "source_paths": paths,
        "native_libraries": {
            name: {"path": path, "sha256": native_hashes[name]} for name, path in native.items()
        },
        "native_source_base_commit": "8a5dffee2826e37fe024f1c0be9c9b6d302e186b",
        "native_build_source": "/home/angus/build-spacepdhcg-joint-v590/source",
        "native_source_archive_sha256": digest(reference / "v590-native-source.tar.gz"),
        "demonstrated_full_route_run": copies["v595-report.json"],
        "demonstrated_full_route_source": V595_COMMIT,
        "identical_source_files": checked,
        "source_changes_since_validation": sorted(changed),
        "changes_used_in_fixed_refinement": False,
        "change_scope": (
            "Joint candidate evaluation/search and a GpuLambert joint-workspace lifecycle field; "
            "the fixed-refinement path instantiates none of those workspaces."
        ),
        "H100_exact_equivalent_proven": False,
        "H100_note": (
            "No exact v590-equivalent H100 binary is established by this local evidence. "
            "Rebuild/match source and architecture explicitly before remote use."
        ),
        "scvx_settings": previous["scvx_settings"],
        "gpu_execution": previous["configuration"]["gpu_execution"],
        "reference_files": {
            name: {"origin": origin, "sha256": digest(reference / name)}
            for name, origin in copies.items()
        },
        "preparation_GPU_calls": 0,
        "production_sources_modified": False,
    },
)
print(
    json.dumps(
        {
            "source_commit": COMMIT,
            "source_files": len(source_hashes),
            "identical_relevant_files": len(checked),
            "changed_since_v595": sorted(changed),
            "GPU_calls": 0,
        }
    )
)
