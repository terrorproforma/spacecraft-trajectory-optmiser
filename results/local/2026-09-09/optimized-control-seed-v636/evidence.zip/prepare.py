"""Freeze one-return inputs and reused guards using stdlib only; never load a solver."""
import ast
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import tarfile
import zipfile

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
OLD = KIT.parent / 'return-horizon-v634'
MASS = KIT.parent / 'mass-merit-return-v632'
PREFIX = KIT.parent / 'fleet-budgeted-prefix-v630/output/local-v794-ship10-rank0000'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write(name, value):
    with (KIT / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def decode_npy(value):
    assert value[:6] == b'\x93NUMPY' and value[6] in (1, 2)
    width = 2 if value[6] == 1 else 4
    length = int.from_bytes(value[8:8 + width], 'little')
    offset = 8 + width + length
    return ast.literal_eval(value[8 + width:offset].decode()), value[offset:]


def main():
    if not __debug__:
        raise RuntimeError('Assertions must remain enabled')
    assert not any((KIT / name).exists() for name in ('ready.json', 'inputs', 'output'))
    prior_ready = load(OLD / 'ready.json')
    prior_launch = load(OLD / 'output/launch-report.json')
    assert sha((OLD / 'ready.json').read_bytes()) == prior_launch['ready_sha256']
    assert prior_launch['complete'] and prior_launch['passed']
    assert load(OLD / 'output/report.json')['status'] == 'both_horizons_uncertified'
    source_map = {}

    def copy(source, name, replacements=()):
        data = source.read_bytes()
        if source.is_relative_to(OLD):
            assert sha(data) == prior_ready['files'][source.relative_to(OLD).as_posix()]
        original_sha = sha(data)
        if replacements:
            text = data.decode()
            for before, after in replacements:
                assert text.count(before) == 1, before
                text = text.replace(before, after)
            data = text.encode()
        destination = KIT / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(data)
        source_map[name] = {'path': source.relative_to(ROOT).as_posix(), 'source_sha256': original_sha,
                            'prepared_sha256': sha(data), 'exact_copy': not bool(replacements)}

    for name in ('runtime.py', 'check_fleet.py', 'process_guard.py', 'host-index.json', 'fleet-binding.json'):
        copy(OLD / name, name)
    copy(OLD / 'common.py', 'common.py', [
        ('Pinned scaled-seed runtime and current-fleet bindings for two fixed returns.',
         'Pinned unscaled optimized-control seed and current-fleet bindings for one return.')])
    copy(OLD / 'observe.py', 'observe.py', [
        ('assert result.seed_backend == "cuda_zoh_mass_scaled_replay"',
         'assert result.seed_backend == "cuda_zoh_replay"')])
    copy(OLD / 'supervise.py', 'supervise.py', [
        ('two returns, shared GPU lock', 'one return, shared GPU lock'),
        ('terminal["native_solves_started"] <= 2 and terminal["native_iterations"] <= 88',
         'terminal["native_solves_started"] == 1 and terminal["native_solves_returned"] == 1 and terminal["native_iterations"] <= 44'),
        ('terminal["flight_certificate_calls"] <= 2', 'terminal["flight_certificate_calls"] <= 1'),
        ('terminal["ephemeris_batches"] <= 1', 'terminal["ephemeris_batches"] == 0'),
        ('terminal["ephemeris_state_requests"] <= 2', 'terminal["ephemeris_state_requests"] == 0'),
        ('terminal["seeded_calls_started"] <= 2', 'terminal["seeded_calls_started"] == 1'),
    ])
    copy(MASS / 'profile.json', 'profile.json')
    for name in ('candidate-plan.json', 'failed-boundary.json', 'settings.json', 'checker-binding.json'):
        copy(OLD / 'inputs' / name, 'inputs/' + name)
    raw_path = MASS / 'output/candidate_mass_return/legs/00/native-raw.npz'
    copy(raw_path, 'inputs/optimized-native-raw.npz')
    copy(MASS / 'output/candidate_mass_return/legs/00/native-raw.json', 'inputs/prior-native-result.json')
    raw_saved_audit = load(MASS / 'saved-audit.json')
    expected_raw = raw_saved_audit['raw_output_files'][raw_path.relative_to(MASS / 'output').as_posix()]
    if isinstance(expected_raw, dict):
        expected_raw = expected_raw['sha256']
    assert sha(raw_path.read_bytes()) == expected_raw

    with zipfile.ZipFile(raw_path) as archive:
        arrays = {name: decode_npy(archive.read(name)) for name in ('epochs.npy', 'thrust_n.npy')}
    epochs_header, epochs_bytes = arrays['epochs.npy']
    thrust_header, thrust_bytes = arrays['thrust_n.npy']
    assert epochs_header == {'descr': '<f8', 'fortran_order': False, 'shape': (226,)}
    assert thrust_header == {'descr': '<f8', 'fortran_order': False, 'shape': (226, 3)}
    epochs = struct.unpack('<226d', epochs_bytes)
    thrust = struct.unpack('<678d', thrust_bytes)
    assert epochs == tuple(69263.0 + 2.0 * i for i in range(226))
    assert all(math.isfinite(x) for x in thrust) and thrust[-3:] == (0.0, 0.0, 0.0)
    boundary = load(KIT / 'inputs/failed-boundary.json')
    plan = load(KIT / 'inputs/candidate-plan.json')
    last_certificate = load(PREFIX / 'legs/16/leg-result.json')['certificate']
    assert last_certificate['final_mass_kg'] + plan['collected_mass_kg']['17126'] == boundary['initial_mass']
    initial = boundary['departure_position'] + boundary['departure_velocity'] + [boundary['initial_mass']]
    initial_bytes = struct.pack('<7d', *initial)
    zoh_fuel = math.fsum((epochs[i + 1] - epochs[i]) * 86400.0
                        * math.hypot(*thrust[3 * i:3 * i + 3]) / (4000.0 * 9.80665)
                        for i in range(225))
    with zipfile.ZipFile(PREFIX / 'propagation/flight-16.npz') as archive:
        header, value = decode_npy(archive.read('results.npy'))
    assert header['shape'] == (1,) and struct.unpack_from('<i', value, 64)[0] == 0
    actual_prefix = struct.unpack_from('<7d', value)
    assert actual_prefix[-1] == last_certificate['final_mass_kg']

    profile = load(KIT / 'profile.json')
    manifest_path = ROOT / profile['native_manifest']['path']
    assert sha(manifest_path.read_bytes()) == profile['native_manifest']['sha256']
    manifest = load(manifest_path)
    assert manifest['complete'] and manifest['passed']
    assert manifest['outputs']['library']['sha256'] == profile['library']['sha256']
    archive_path = manifest_path.parent / 'source.tar.gz'
    assert sha(archive_path.read_bytes()) == manifest['source_archive_sha256']
    reviewed_native = {}
    with tarfile.open(archive_path) as archive:
        for name in ('cpp/cuda/src/gtoc12_scvx.cu', 'cpp/cuda/src/gtoc12_verification.cu',
                     'cpp/cuda/include/spacepdhcg/cuda/gtoc12_scvx_c_api.h'):
            value = archive.extractfile(name).read()
            assert sha(value) == manifest['sources'][name]
            reviewed_native[name] = sha(value)
    write('input-review.json', {
        'passed': True, 'scope': 'saved arrays/source only; no propagation or solver',
        'source_npz_sha256': sha(raw_path.read_bytes()),
        'epochs_payload_sha256': sha(epochs_bytes), 'thrust_payload_sha256': sha(thrust_bytes),
        'canonical_initial_payload_sha256': sha(initial_bytes), 'canonical_initial_state': initial,
        'raw_prefix_certificate_endpoint': actual_prefix,
        'canonical_minus_raw_prefix_rv': [a - b for a, b in zip(initial[:6], actual_prefix[:6])],
        'prefix_certificate_position_error_km': last_certificate['position_error_km'],
        'prefix_certificate_velocity_error_km_s': last_certificate['velocity_error_km_s'],
        'prefix_certificate_final_mass_kg': last_certificate['final_mass_kg'],
        'pickup_kg': plan['collected_mass_kg']['17126'],
        'initial_mass_kg': boundary['initial_mass'], 'minimum_final_mass_kg': boundary['minimum_final_mass'],
        'saved_control_mass_only_prediction_kg': boundary['initial_mass'] - zoh_fuel,
        'mass_only_prediction_margin_kg': boundary['initial_mass'] - zoh_fuel - boundary['minimum_final_mass'],
        'mass_only_prediction_is_not_a_trajectory_certificate': True,
        'source_thrust_maximum_N': max(math.hypot(*thrust[i:i + 3]) for i in range(0, 678, 3)),
        'source_inactive_final_thrust_zero': True, 'old_state_nodes_selected': 0,
        'target_initial_mass_kg': None, 'mass_ratio': 1.0, 'thrust_clipped_or_scaled': False,
        'native_API': 'spacepdhcg_gtoc12_scvx_solve_zoh_seed_host',
        'library_sha256': profile['library']['sha256'],
        'native_source_sha256': reviewed_native,
        'runtime_binary_bytes_rechecked_during_this_preparation': False,
        'GPU_calls': 0, 'solver_calls': 0, 'ephemeris_calls': 0,
    })
    old_protocol = load(OLD / 'protocol.json')
    protocol = {
        'status': 'prepared_for_root_review_not_executed', 'fleet_binding_status': 'reviewed',
        'changed_factor': 'v632 optimized physical thrust replaces original archived thrust; regenerate all nodes on CUDA',
        'departure_MJD': 69263.0, 'arrival_MJD': 69713.0, 'nodes': 226,
        'initial_mass_kg': 1438.8883038351994, 'cargo_kg': 677.2073921971253,
        'minimum_final_mass_kg': 1177.2073921971253, 'target_initial_mass_kg': None,
        'maximum_native_returns': 1, 'maximum_SCvx_iterations': 44,
        'SCvx_main_per_return': 40, 'SCvx_polish_per_return': 4,
        'maximum_fresh_return_certificates': 1, 'maximum_fleet_checker_pairs': 1,
        'saved_prefix_flight_certificates': 17, 'saved_prefix_wait_certificates': 1,
        'new_prefix_solves': 0, 'new_wait_certificates': 0, 'Lambert_calls': 0,
        'standalone_seed_inspections': 0, 'ephemeris_requests': 0,
        'worker_soft_seconds': 220, 'supervisor_hard_seconds': 240, 'TERM_seconds': 10,
        'KILL_reap_seconds': 30, 'automatic_retries': False,
        'physical_gates_and_64eps_representation_guard_unchanged': True,
        'baseline_Result_sha256': old_protocol['baseline_Result_sha256'],
        'prescribed_fleet_only_if_both_checkers_pass': old_protocol['prescribed_fleet_only_if_both_checkers_pass'],
    }
    assert sum(plan['collected_mass_kg'].values()) == protocol['cargo_kg']
    write('protocol.json', protocol)
    write('source-map.json', source_map)
    external = {}

    def pin(path, expected=None):
        data = path.read_bytes()
        digest = sha(data)
        if expected is not None:
            assert digest == expected
        external[os.path.relpath(path, KIT).replace('\\', '/')] = digest

    host = MASS / 'host'
    for name, digest in load(KIT / 'host-index.json').items():
        pin(host / name, digest)
    for name in ('case-report.json', 'wait-summary.json'):
        pin(PREFIX / name)
    for i in range(17):
        for name in ('leg-result.json', 'boundary.json', 'post-clamp.npz'):
            pin(PREFIX / 'legs' / f'{i:02d}' / name)
    pin(PREFIX / 'propagation/flight-16.npz')
    pin(manifest_path, profile['native_manifest']['sha256'])
    pin(archive_path, manifest['source_archive_sha256'])
    for qualification in profile['GPU_qualification']:
        pin(ROOT / qualification['path'], qualification['sha256'])
        assert load(ROOT / qualification['path'])['passed']
    binding = load(KIT / 'fleet-binding.json')
    pin(ROOT / binding['result_directory'] / 'Result.txt', binding['result_sha256'])
    pin(MASS / 'saved-audit.json')
    for name, item in source_map.items():
        pin(ROOT / item['path'], item['source_sha256'])
    for name, digest in prior_ready['external_files'].items():
        if name.startswith('/home/angus/worktrees/spacepdhcg-release/benchmarks/gtoc12/data/'):
            external[name] = digest  # Actual runtime bytes are rechecked by supervisor, before child.
    for item in (profile['library'], profile['qoco'], {'path': profile['python'], 'sha256': profile['python_sha256']}):
        external[item['path']] = item['sha256']
    for path in KIT.glob('*.py'):
        compile(path.read_bytes(), str(path), 'exec')  # Syntax only; no imports or bytecode.
    files = {p.relative_to(KIT).as_posix(): sha(p.read_bytes()) for p in sorted(KIT.rglob('*')) if p.is_file()}
    ready = {'status': 'prepared_for_root_review; runtime hashes checked before child launch',
             'files': files, 'external_files': external, 'file_count': len(files),
             'bytes': sum((KIT / n).stat().st_size for n in files), 'external_count': len(external),
             'GPU_calls_during_preparation': 0, 'optimizer_calls_during_preparation': 0,
             'syntax_checked_files': len(list(KIT.glob('*.py'))), 'caps': protocol}
    write('ready.json', ready)
    print(json.dumps({'ready_sha256': sha((KIT / 'ready.json').read_bytes()), 'files': len(files),
                      'bytes': ready['bytes'], 'externals': len(external),
                      'worker_sha256': files['worker.py'], 'supervisor_sha256': files['supervise.py']}, indent=2))


if __name__ == '__main__':
    main()
