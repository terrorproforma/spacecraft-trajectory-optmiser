# Verified 24-ship fleet display

The installed `gtoc12-fleet-v633` dataset is the viewer default. It binds the final v633b Result SHA-256 `1f420928bbef8da91e3a6f8b74d3bf00039c78d4257215c103a484bc55bb22da`, which passed both original full-fleet checkers: **13,526.96124117307 weighted kg**, **14,915.0444900762 raw kg**, 24 ships and 208 asteroids.

Open <http://127.0.0.1:4173/?dataset=gtoc12-fleet-v633>. The existing server was already running; all nine fetched UI/data files matched their installed bytes. HTTP checking does not claim a rendered-browser inspection.

The first 23 ship JSON objects are byte-for-byte copies of `gtoc12-frontier-v629`. Their replay, transcription, event and provenance fields are unchanged. Ship 24 is archived `fleet_master_v10` ship 9, with only its ship identifier changed in the newly checked Result. Its 20 displayed positions are parsed directly from the serialized before-event rows; paired after-event positions have identical printed values. All 19 intervals between these positions are explicit display gaps. No flight path, moving ship marker or follow target is invented inside them. Its final mass field is 501.4432517332 kg after unloading; its arrival mass before unloading is 1125.4815816442 kg.

The nine additional asteroid element records were parsed from the hash-pinned official catalogue. The earlier 199 records are unchanged. No new orbital equations, trajectory propagation, optimizer, GPU call or checker campaign was run for this export. The viewer retains its normal browser-side Kepler context display. The inherited context cross-check covers earlier histories only; the nine appended catalogue records did not receive a new offline context propagation check.

`dataset-b/` is the final dataset (fleet SHA-256 `cb22ab847f6ce6b85b999cbb2d0073a4cc3261a1d40291d6eb65fb177c58ff51`). `source-display-map.json` records exact input hashes, original ship object hashes, all 20 event row payloads and the missing intervals. The installed JSON and `.gitattributes` match it exactly. `dataset/` and `pre-correction-display.zip` preserve the first display version, whose final-mass label used arrival-before-unload; that version is superseded and is not the default.

The final checker worker took 23.189 s and made one call to each checker. Both formatting attempts together made two calls to each checker and took 47.144631559 s; the earlier official failure was one trailing empty line, retained by the fleet-addition evidence package. These are checker timings, not search/refinement speedups. Existing historical optimization statistics are not attributed to this display export.

Validation retained here includes six replay/label tests, syntax checks, source/schema validation, exact installed-byte validation, and the HTTP audit. No new propagation was involved. `verify.py --index-sha256 <index SHA>` performs a portable saved-byte audit using only Python's standard library.

The installation is at `results/lambda/2026-09-06/visualiser/data/gtoc12-fleet-v633`. If the existing viewer later needs starting, use its established server command from the viewer directory:

```text
node scripts/serve.mjs --port=4173
```

`owned-files.json` lists the exact additive dataset and five narrowly modified viewer files. The old datasets remain available. No main documentation, production solver code or Git state was changed by this display task.
