/**
 * @file cuda_types.h
 * @author Govind M. Chari <govindchari1@gmail.com>
 *
 * @section LICENSE
 *
 * Copyright (c) 2025, Govind M. Chari
 * This source code is licensed under the BSD 3-Clause License
 *
 * @section DESCRIPTION
 *
 * Defines the vector and matrices for CUDA linear algebra.
 * On GPU, matrices are stored in CSR format (as required by cuDSS).
 */

#ifndef CUDA_TYPES_H
#define CUDA_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif
#include "common_linalg.h"
#include "definitions.h"
#include "qoco_linalg.h"
#ifdef __cplusplus
}
#endif
#include <cuda_runtime.h>

struct QOCOVectori_ {
  QOCOInt* data;   // Host pointer
  QOCOInt* d_data; // Device pointer
  QOCOInt len;
};

struct QOCOVectorf_ {
  QOCOFloat* data;   // Host pointer
  QOCOFloat* d_data; // Device pointer
  QOCOInt len;
};

struct QocoGpuGather;
#define SPACEPDHCG_QOCO_LAZY_HOST_MIRRORS 1
#define SPACEPDHCG_QOCO_DEFERRED_TRANSPOSES 1
struct QOCOMatrix_ {
  int reference_count;
  QOCOMatrix* transpose_source;
  QOCOInt* transpose_map;
  int transpose_values_pending;
  int lazy_host_mirror;
  mutable int host_values_pending;
  QocoGpuGather* gather;
  QOCOCscMatrix* csc;   // Host pointer
  QOCOCscMatrix* d_csc; // Device pointer with csc arrays on device.
  QOCOCscMatrix* d_csc_host; // Host pointer with device csc arrays. (Needed to free device csc arrays)
};

#endif /* ifndef CUDA_TYPES_H */
