from pathlib import Path
import os,sys,subprocess,shutil,json,hashlib,fcntl,time
root=Path('/home/ubuntu/spacepdhcg-diagnose-v174');repo=root/'repo';os.chdir(repo)
vendor=Path('/home/ubuntu/spacepdhcg-diagnose-v168');source=vendor/'qoco'
cmake='/home/ubuntu/spacepdhcg/v1/.venv/bin/cmake';runtime='/home/ubuntu/spacepdhcg-recovery-v152/cudss'
env=dict(os.environ,LD_LIBRARY_PATH=str(root/'final')+':'+runtime+'/lib:/usr/local/cuda/lib64',PYTHONPATH=str(repo/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
report=dict(start=time.time(),stages=[],source_manifest=json.loads((root/'source-manifest.json').read_text()))
def run(name,command,timeout=300):
 start=time.time();r=subprocess.run(command,cwd=repo,env=env,capture_output=True,text=True,timeout=timeout)
 (root/(name+'.log')).write_text(r.stdout);(root/(name+'.err')).write_text(r.stderr)
 report['stages'].append(dict(name=name,command=command,returncode=r.returncode,seconds=time.time()-start));(root/'report.json').write_text(json.dumps(report,indent=2));print(name,r.returncode,flush=True);return r
try:
 run('core-configure',[cmake,'-S',str(repo/'cpp'),'-B',str(root/'core-build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSPACEPDHCG_BUILD_CUDA=ON','-DSPACEPDHCG_BUILD_NATIVE_TESTS=OFF','-DBUILD_TESTING=ON','-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=90','-DSPACEPDHCG_PDHCG_SOURCE_ROOT=/home/ubuntu/spacepdhcg/v1/_upstream/pdhcg']).check_returncode()
 native=['gtoc12_outer_graph_test','gtoc12_graph_deadline_test','gtoc12_qoco_guard_test','qoco_gpu_audit_test','gtoc12_scvx_test']
 run('core-build',[cmake,'--build',str(root/'core-build'),'--target','spacepdhcg_cuda',*native,'-j','3'],600).check_returncode()
 final=root/'final';final.mkdir()
 for src in [vendor/'final/libqoco.so',root/'core-build/cuda/libspacepdhcg_cuda.so']:
  shutil.copy2(src,final/src.name);(final/src.name).chmod(0o555)
 report['libraries']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in final.iterdir()}
 run('replay-build',['/usr/local/cuda/bin/nvcc','--default-stream','per-thread','-arch=sm_90','-std=c++17',*['-I'+str(source/n) for n in ['include','algebra/cuda','lib/qdldl/include','lib/amd']],str(repo/'cpp/cuda/tests/qoco_snapshot_replay.cu'),'-L'+str(final),'-lqoco','-o',str(final/'qoco_snapshot_replay')]).check_returncode()
 env.update(SPACEPDHCG_GTOC12_CUDA_LIBRARY=str(final/'libspacepdhcg_cuda.so'),SPACEPDHCG_QOCO_LIBRARY=str(final/'libqoco.so'),SPACEPDHCG_GTOC12_GPU_TESTS='1',SPACEPDHCG_TEST_QOCO_IPM_GRAPH='1')
 with Path('/home/ubuntu/.spacepdhcg-gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
  py='/home/ubuntu/spacepdhcg/v1/.venv/bin/python'
  prefix="import sys;sys.meta_path=[f for f in sys.meta_path if f.__class__.__module__!='_editable_skbc_spacepdhcg'];"
  env['QOCO_REPLAY_REGULARIZATION']='1e-9'
  qps=sorted((repo/'build/performance/qp-capture-v169').glob('*/qp-*.txt'))
  for i,qp in enumerate(qps):run('qp-'+str(i),[str(final/'qoco_snapshot_replay'),str(qp),'16'],120)
  del env['QOCO_REPLAY_REGULARIZATION']
  for name in native:run(name,[str(root/'core-build/cuda-tests'/name)],120)
  run('gtoc12-integration',[py,'-c',prefix+"import pytest;sys.exit(pytest.main(sys.argv[1:]))",'tests/test_gtoc12_gpu_discretisation.py','tests/test_gtoc12_gpu_scvx.py','tests/test_gtoc12_gpu_qoco.py','tests/test_gtoc12_gpu_seed.py','tests/test_gtoc12_gpu_cli.py','-q'],300)
  for flag in ['GTOC12_DEVICE_SCHEDULING','GTOC12_DEFERRED_REPORTS','GTOC12_DEVICE_REFRESH','GTOC12_DEVICE_ASSEMBLY_VALIDATION','GTOC12_DEVICE_QUALIFICATION','QOCO_DEVICE_VALIDATION','QOCO_NATIVE_NUMERIC_REPLAY','QOCO_NATIVE_REPLAY','QOCO_IPM_GRAPH']:env['SPACEPDHCG_TEST_'+flag]='1'
  comparison=[]
  for ruiz in [0,5]:
   for origin in [False,True]:
    for mode in ['ordinary','deferred','device','graph']*4:
     graph=mode=='graph';device=mode in ['device','graph']
     env.update(TEST_RUIZ=str(ruiz),SPACEPDHCG_TEST_GTOC12_STATE_ORIGIN=str(int(origin)),SPACEPDHCG_TEST_GTOC12_OUTER_GRAPH=str(int(graph)))
     for flag in ['GTOC12_DEVICE_SCHEDULING','GTOC12_DEVICE_REFRESH','GTOC12_DEVICE_ASSEMBLY_VALIDATION','GTOC12_DEVICE_QUALIFICATION','QOCO_DEVICE_VALIDATION','QOCO_NATIVE_NUMERIC_REPLAY','QOCO_NATIVE_REPLAY']:
      env['SPACEPDHCG_TEST_'+flag]=str(int(device))
     env['SPACEPDHCG_TEST_GTOC12_DEFERRED_REPORTS']=str(int(mode!='ordinary'))
     name='leg-'+str(len(comparison));output=root/(name+'.json')
     run(name,[py,'-c',prefix+"import runpy;sys.argv=['build/performance/diagnose_outer_leg_v158.py',sys.argv[1]];runpy.run_path(sys.argv[0],run_name='__main__')",str(output)],90)
     comparison.append(dict(ruiz=ruiz,origin=origin,graph=graph,mode=mode,result=json.loads(output.read_text()) if output.exists() else None));(root/'comparison.json').write_text(json.dumps(comparison,indent=2))
  for name in ['gtoc12_outer_graph_test','gtoc12_qoco_guard_test']:
   run(name+'-memcheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','98',str(root/'core-build/cuda-tests'/name)],180)
 report['completed']=True
except Exception as e:report['error']=repr(e);report['completed']=False
report['end']=time.time();(root/'report.json').write_text(json.dumps(report,indent=2))
