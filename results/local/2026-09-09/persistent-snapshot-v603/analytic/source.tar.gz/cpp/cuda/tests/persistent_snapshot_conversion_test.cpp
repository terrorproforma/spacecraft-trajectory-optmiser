#include "persistent_snapshot.hpp"

#include <filesystem>
#include <iostream>

namespace s=spacepdhcg::snapshot;
namespace {
std::string fixture(bool shifted) {
    // min x'x + x0*x1 - 4*x0 - 4*x1, x1=0, x0<=1, (1,x0,x1) in SOC.
    // x=(1,0), y=3, z=(1;1,-1,0), objective=-3.
    std::ostringstream out;
    out<<"SPACEPDHCG_QOCO_QP_V1\n2 1 4 3 1 3 1 1 "<<shifted<<"\n"
       <<"200 0 20 0\n1e-12 1e-8 1e-8 1e-8 1e-13 1e-11 1e-11 1e-5 1e-5\n"
       <<"3 0 1 3\n3 0 0 1\n3 0 0 1\n1 0\n3 0 2 3\n3 0 2 3\n1 3\n"
       <<"14 2 1 2 1 1 -1 -1 -4 -4 0 1 1 0 0\n";
    auto bytes=out.str();
    bytes+=shifted?"14 2 1 2 1 1 -1 -1 -1 -4 1 -1 1 2 -1\n2 2 -1\n-1\n":"0\n0\n0\n";
    return bytes;
}
void equal(const std::vector<double>& a,const std::vector<double>& b) {s::require(a==b,"array mismatch");}
void near(long double a,long double b) {s::require(std::isfinite(a) && std::abs(a-b)<1e-15L,"analytic scalar mismatch");}
void reject(std::string bytes,const std::string& before,const std::string& after) {
    const auto position=bytes.find(before);s::require(position!=std::string::npos,"invalid mutation fixture");
    bytes.replace(position,before.size(),after);
    bool rejected=false;try {static_cast<void>(s::read(bytes));}catch(const std::exception&) {rejected=true;}
    s::require(rejected,"malformed snapshot was accepted");
}
void checks() {
    s::require(s::sha256("")=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","SHA empty");
    s::require(s::sha256("abc")=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA abc");
    s::require(s::sha256(std::string(1000000,'a'))=="cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0","SHA multiblock");
    for(bool shifted:{false,true}) {
        const auto q=s::read(fixture(shifted));const auto c=s::canonical(q);
        s::require(c.Q.offsets==std::vector<int>({0,2,4}) && c.Q.indices==std::vector<int>({0,1,0,1}),"symmetric P pattern");
        equal(c.Q.values,{2,1,1,2});
        s::require(c.A.offsets==std::vector<int>({0,1,2}) && c.A.indices==std::vector<int>({1,0}),"mixed scalar rows");
        equal(c.A.values,{1,1});equal(c.F.values,{1,1});
        s::require(c.F.indices==std::vector<int>({0,1}) && c.cones.size()==1
            && c.cones[0].start==0 && c.cones[0].vector_dimension==1,"SOC dimension/permutation");
        equal(c.c,shifted?std::vector<double>{-1,-4}:std::vector<double>{-4,-4});
        equal(c.upper,shifted?std::vector<double>{1,-1}:std::vector<double>{0,1});
        s::require(c.lower[0]==(shifted?1:0) && c.lower[1]==-INFINITY,"scalar lower bounds");
        equal(c.offset,shifted?std::vector<double>{2,-1,1}:std::vector<double>{0,0,1});
        const auto v=s::original_vectors(q,c,shifted?std::vector<double>{-1,1}:std::vector<double>{1,0},{3,1,1,0,-1});
        equal(v.x,{1,0});equal(v.y,{3});equal(v.z,{1,1,-1,0});equal(v.s,{0,1,1,0});
        const auto audit=s::audit(q,v,1e-9,1e-8);
        s::require(audit.qualified && audit.finite,"exact KKT fixture failed");near(audit.objective,-3);near(audit.dual_objective,-3);near(audit.complementarity,0);
        auto invalid=v;invalid.z[2]=1; s::require(!s::audit(q,invalid,1e-9,1e-8).qualified,"wrong SOC dual sign passed");
        invalid=v;invalid.y[0]=-3;s::require(!s::audit(q,invalid,1e-9,1e-8).qualified,"wrong equality dual sign passed");
        invalid=v;invalid.x[0]=2;s::require(!s::audit(q,invalid,1e-9,1e-8).qualified,"infeasible primal passed");
        invalid=v;invalid.s[0]=0.1;s::require(!s::audit(q,invalid,1e-9,1e-8).qualified,"inconsistent supplied slack passed");
        invalid=v;invalid.x[0]=std::numeric_limits<double>::quiet_NaN();s::require(!s::audit(q,invalid,1e-9,1e-8).finite,"nonfinite output passed");
        invalid=v;invalid.z[0]=-1;s::require(!s::audit(q,invalid,1e-9,1e-8).qualified,"negative cone dual passed");
    }
    const auto q=fixture(false);
    reject(q,"SPACEPDHCG_QOCO_QP_V1","SPACEPDHCG_QOCO_QP_V2");
    reject(q,"2 1 4 3 1 3 1 1 0","1000000000 1 4 3 1 3 1 1 0");
    reject(q,"3 0 1 3","3 0 4 3");
    reject(q,"3 0 0 1\n3 0 0 1","3 1 0 1\n3 0 0 1"); // lower P
    reject(q,"3 0 0 1\n3 0 0 1","3 0 0 0\n3 0 0 1"); // duplicate P
    reject(q,"1 3\n14","1 2\n14");
    reject(q,"14 2 1 2","14 nan 1 2");
    reject(q,"14 2 1 2","14 -2 1 2");
    reject(q,"14 2 1 2","15 2 1 2");
    reject(q,"0\n0\n0\n","0\n0\n1\n");
    reject(q,"0\n0\n0\n","0\n0\n");
    reject(q,"0\n0\n0\n","0\n0\n0\ntrailing\n");
    reject(fixture(true),"14 2 1 2 1 1 -1 -1 -1 -4","14 2 1 2 1 1 -1 -1 -2 -4");
    reject(fixture(true),"2 2 -1\n-1\n","2 2 -1\n0\n");
    reject(fixture(true),"14 2 1 2 1 1 -1 -1 -1 -4","14 2 2 2 1 1 -1 -1 -1 -4");
    // A finite, zero-Hessian unconstrained LP is legal; zero and empty arrays survive.
    const auto empty=s::read("SPACEPDHCG_QOCO_QP_V1\n1 0 0 1 0 0 0 0 0\n200 0 20 0\n1e-12 1e-8 1e-8 1e-8 1e-13 1e-11 1e-11 1e-5 1e-5\n2 0 1\n1 0\n2 0 0\n0\n2 0 0\n0\n0\n2 0 0\n0\n0\n0\n");
    const auto ce=s::canonical(empty);s::require(ce.Q.values==std::vector<double>({0}) && ce.A.values.empty() && ce.F.values.empty(),"structural zero/empty rows lost");
    s::require(s::audit(empty,s::original_vectors(empty,ce,{0},{}),1e-9,1e-8).qualified,"zero LP failed");
    auto psd_bytes=fixture(false);
    psd_bytes.replace(psd_bytes.find("14 2 1 2"),8,"14 1 2 4");
    s::require(s::canonical(s::read(psd_bytes)).convexity_evidence=="assumed_from_capture_not_proved",
        "valid non-diagonally-dominant PSD was rejected or incorrectly proved");
    // Adjacent SOCs of different sizes exercise nonzero descriptor starts.
    const auto two=s::read("SPACEPDHCG_QOCO_QP_V1\n2 0 7 0 0 0 0 2 0\n200 0 20 0\n1e-12 1e-8 1e-8 1e-8 1e-13 1e-11 1e-11 1e-5 1e-5\n3 0 0 0\n0\n3 0 0 0\n0\n3 0 0 0\n0\n2 3 4\n9 0 0 1 0 0 2 0 0 0\n0\n0\n0\n");
    const auto ct=s::canonical(two);
    s::require(ct.soc_to_affine==std::vector<int>({2,0,1,6,3,4,5}) && ct.cones.size()==2
        && ct.cones[1].start==3 && ct.cones[1].vector_dimension==2,"adjacent SOC mapping");
    equal(ct.offset,{0,0,1,0,0,0,2});
    equal(s::original_vectors(two,ct,{0,0},{1,2,3,4,5,6,7}).z,{-3,-1,-2,-7,-4,-5,-6});
    // Small permitted cone violations plus huge duals must not hide cancellation
    // between nonzero block complementarity products in the global duality gap.
    const auto cancellation=s::read("SPACEPDHCG_QOCO_QP_V1\n1 0 2 0 0 0 2 0 0\n200 0 20 0\n1e-12 1e-8 1e-8 1e-8 1e-13 1e-11 1e-11 1e-5 1e-5\n2 0 0\n0\n2 0 0\n0\n2 0 0\n0\n0\n3 0 -1e-8 1\n0\n0\n0\n");
    const auto cancelled=s::audit(cancellation,{{0},{},{1e12,1e4},{-1e-8,1}},1e-9,1e-8);
    s::require(cancelled.gap<1e-9 && cancelled.global_complementarity_normalized<1e-9
        && cancelled.block_complementarity_normalized>=1e4 && !cancelled.qualified,"complementarity cancellation passed");
}
} // namespace
int main(int argc,char** argv) try {
    checks();
    if(argc==3 && std::string(argv[1])=="--write-fixtures") {
        const std::filesystem::path root(argv[2]);
        s::require(!std::filesystem::exists(root),"fixture output already exists");
        std::filesystem::create_directories(root);
        for(bool shifted:{false,true}) {
            std::ofstream out(root/(shifted?"mixed-shifted.txt":"mixed.txt"));out<<fixture(shifted);s::require(bool(out),"fixture write failed");
        }
    } else s::require(argc==1,"usage: persistent_snapshot_conversion_test [--write-fixtures NEW_DIRECTORY]");
    std::cout<<"persistent snapshot conversion and independent analytic KKT checks passed (CPU only)\n";return 0;
} catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
