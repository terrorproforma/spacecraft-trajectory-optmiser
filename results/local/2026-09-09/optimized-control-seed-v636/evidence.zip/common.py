"""Pinned unscaled optimized-control seed and current-fleet bindings for one return."""

from __future__ import annotations

import dataclasses
import hashlib
import json
import math
import os
from pathlib import Path

import numpy as np

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[2]
BASE = KIT / "inputs"
HOST = KIT.parent / "mass-merit-return-v632/host"
PRIOR = ROOT / "build/performance/fleet-budgeted-prefix-v630"
_FLEET_PATH = KIT / "fleet-binding.json"
_FLEET = (
    json.loads(_FLEET_PATH.read_text())
    if _FLEET_PATH.exists()
    else {
        "result_directory": "results/local/2026-09-09/mass-budgeted-frontier-v629",
        "result_sha256": "765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da",
        "ships": 23,
        "status": "pending_root_current_incumbent",
    }
)
CURRENT = ROOT / _FLEET["result_directory"]
DATA = "/home/angus/worktrees/spacepdhcg-release/benchmarks/gtoc12/data"
SOURCE_RESULT_SHA = "765cb7ef97d38926317dbbf4ae8700626dffec06c48af3d6f68dae47c154f3da"
RESULT_SHA = _FLEET["result_sha256"]
_PROFILE = json.loads((KIT / "profile.json").read_text())
CORE, CORE_SHA = _PROFILE["library"]["path"], _PROFILE["library"]["sha256"]
CORE_MANIFEST = ROOT / _PROFILE["native_manifest"]["path"]
MANIFEST_SHA = _PROFILE["native_manifest"]["sha256"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def safe(value):
    if dataclasses.is_dataclass(value):
        return safe(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return safe(value.tolist())
    if isinstance(value, np.generic):
        return safe(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return value


def write(path, value):
    with Path(path).open("x") as stream:
        json.dump(safe(value), stream, indent=2, allow_nan=False)
        stream.write("\n")


def current(path, value):
    path = Path(path)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(safe(value), indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


def activate():
    import sys

    if not __debug__:
        raise RuntimeError("Assertions must be enabled")
    assert sha(CURRENT / "Result.txt") == RESULT_SHA
    for name, expected in read(KIT / "host-index.json").items():
        assert sha(HOST / name) == expected, name
    sys.meta_path = [
        f for f in sys.meta_path if f.__class__.__module__ != "_editable_skbc_spacepdhcg"
    ]
    sys.path.insert(0, str(HOST))
    return sys.modules[__name__]


def catalogue_and_bonus():
    from spacepdhcg.gtoc12.data import load_bonus_table, load_catalogue

    os.environ["SPACEPDHCG_GTOC12_DATA"] = DATA
    catalogue, bonus = load_catalogue(), load_bonus_table()
    assert (
        catalogue.source_sha256
        == "99a42cc30d4498d99b8acf507790ab74f040ff2e202ef6c8e90bbb39b6c46675"
    )
    assert bonus.source_sha256 == "e8a3795e599556ed5b66713ab1fa176de93ef37f93cb2a4a87d561539b1caa21"
    return catalogue, bonus


def sections(payload):
    result = {}
    for line in payload.splitlines(keepends=True):
        row = line.split()
        if row:
            ship = int(row[0])
            result[ship] = result.get(ship, b"") + line
    return result


def splice(payload, replacements):
    original = sections(payload)
    assert len(original) == _FLEET["ships"]
    output = []
    for ship, data in original.items():
        if ship not in replacements:
            output.append(data)
            continue
        candidate = replacements[ship]
        parsed = sections(candidate)
        assert set(parsed) == {ship} and candidate and not candidate.endswith(b"\n")
        output.append(candidate + (b"\n" if data.endswith(b"\n") else b""))
    result = b"".join(output)
    chosen = sections(result)
    assert set(chosen) == set(original)
    for ship in original:
        expected = replacements.get(ship)
        assert (
            chosen[ship] == original[ship]
            if expected is None
            else chosen[ship].rstrip(b"\n") == expected
        )
    return result
