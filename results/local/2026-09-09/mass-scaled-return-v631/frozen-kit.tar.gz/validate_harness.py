"""Retain CPU-only final host/orchestration checks and source identities."""

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

KIT = Path(__file__).resolve().parent
assert __debug__ and os.environ.get("CUDA_VISIBLE_DEVICES") == ""
output = KIT / sys.argv[1]
output.mkdir()
files = [
    p
    for p in KIT.glob("*.py")
    if p.name not in ("build_harness.py", "process_guard.py", "prepare_protocol.py")
]
stages = []
for name, args in (
    (
        "tests",
        [
            "-m",
            "pytest",
            "-q",
            str(KIT / "test_prepare.py"),
            str(KIT / "test_runtime.py"),
            "--tb=short",
        ],
    ),
    ("ruff", ["-m", "ruff", "check", *map(str, files)]),
):
    begin = time.perf_counter()
    child = subprocess.run([sys.executable, "-B", *args], cwd=KIT, capture_output=True, timeout=90)
    payload = child.stdout + child.stderr
    (output / f"{name}.log").write_bytes(payload)
    stages.append(
        {
            "name": name,
            "exit_code": child.returncode,
            "seconds": time.perf_counter() - begin,
            "command": [sys.executable, "-B", *args],
            "log_sha256": hashlib.sha256(payload).hexdigest(),
        }
    )
report = {
    "passed": all(x["exit_code"] == 0 for x in stages),
    "GPU_calls": 0,
    "new_trajectory_propagations": 0,
    "mock_new_return_only": True,
    "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    "host_index_sha256": hashlib.sha256((KIT / "host-index.json").read_bytes()).hexdigest(),
    "stages": stages,
}
(output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "source_sha256"}, indent=2))
raise SystemExit(0 if report["passed"] else 1)
