// Exercise the actual device controller independently of QOCO's convergence.
#include "../src/gtoc12_scvx.cu"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

#define REQUIRE(x) do { if (!(x)) { std::fprintf(stderr,"line %d: %s\n",__LINE__,#x); std::exit(1); } } while (0)
#define CUDA(x) REQUIRE((x)==cudaSuccess)

Settings fixture() {
    Settings p{};
    p.substeps=8; p.polish_substeps=16; p.polish_iterations=4; p.max_iterations=40;
    p.virtual_weight=1e4; p.initial_trust_state=.2; p.initial_trust_control=1;
    p.minimum_trust=1e-6; p.maximum_trust=2; p.ratio_shrink=.25; p.ratio_grow=.7;
    p.shrink_factor=.5; p.grow_factor=1.6; p.defect_tolerance=5e-9;
    p.step_tolerance=1e-7; p.objective_tolerance=1e-6; p.conic_tolerance=1e-9;
    p.minimum_mass=.3; p.radius_floor=.05; p.vinf_max=.2; p.time_limit_s=30;
    return p;
}

void controller() {
    State* ds; Metrics* dm; double *dx,*states,*controls;
    Record* records; spacepdhcg_gtoc12_conic_parameters* parameters;
    spacepdhcg_gtoc12_qoco_report* device_report;
    CUDA(cudaMalloc(&device_report,sizeof(*device_report)));
    CUDA(cudaMalloc(&ds,sizeof(State))); CUDA(cudaMalloc(&dm,sizeof(Metrics)));
    CUDA(cudaMalloc(&dx,100*sizeof(double))); CUDA(cudaMalloc(&states,28*sizeof(double)));
    CUDA(cudaMalloc(&controls,16*sizeof(double))); CUDA(cudaMalloc(&records,44*sizeof(Record)));
    CUDA(cudaMalloc(&parameters,sizeof(*parameters)));
    std::vector<double> x(100,2.0), got(28), zeros(28,0.0);
    CUDA(cudaMemcpy(dx,x.data(),800,cudaMemcpyHostToDevice));
    for (bool device:{false,true}) for (int test=0;test<22;++test) {
        auto p=fixture();
        State host{}; host.command.substeps=8; host.merit=10; host.trust_state=.2;
        host.trust_control=1; host.polish_left=4; host.result.virtual_inf=INFINITY;
        Metrics metrics{1,0,0,0,0,1,0};
        int qualified=1;
        if (test==0) qualified=0;
        if (test==1) { qualified=0; host.trust_state=1e-6; }
        if (test==2) metrics.penalty=.002; // actual negative, predicted positive: reject
        if (test==3) metrics.penalty=.00085; // ratio 1/18: shrink accepted
        if (test==4) metrics.step=0; // enter polish
        if (test==5) { metrics.step=0; p.polish_iterations=0; }
        if (test==6) { metrics.step=0; host.polishing=1; }
        if (test==7) metrics.invalid=1;
        if (test==8) { metrics.fuel=10; metrics.penalty=0; } // zero prediction, ratio=1
        if (test==9) { metrics.fuel=10; metrics.penalty=.001; } // zero prediction, ratio=-1
        if (test==10) { host.result.iterations=39; metrics.defect=1e-4; }
        if (test==11) { host.polishing=1; host.polish_left=1; metrics.penalty=.002; }
        if (test==12) { host.trust_state=host.trust_control=1e-6; metrics.penalty=.002; }
        if (test==13) { metrics.virtual_sum=NAN; }
        if (test==14) {
            metrics.fuel=10; metrics.virtual_sum=1e-8; metrics.virtual_inf=1e-9;
            // Feasible and improving nonlinear merit, but a negative model
            // prediction larger than the objective tolerance is not convergence.
        }
        if (test>=15) {
            // H100 capture v172: accurate QPs were rejected for a ~1e-13
            // merit increase until the trust region collapsed.
            host.merit=0.021875559685678503;
            metrics={0.021875559685914866,0,0,1.965094753586527e-14,
                8.534828883796292e-19,2.4184484914702153e-08,0};
            if(test==16) metrics.fuel=host.merit+2*p.objective_tolerance;
            if(test==17) metrics.virtual_sum=2*p.objective_tolerance/p.virtual_weight;
            if(test==18) metrics.defect=2*p.defect_tolerance;
            if(test==19) metrics.virtual_inf=20*p.defect_tolerance;
            if(test==20) qualified=0;
            if(test==21) metrics.invalid=1;
        }
        const int prior=host.result.iterations;
        CUDA(cudaMemcpy(ds,&host,sizeof(host),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(dm,&metrics,sizeof(metrics),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(states,zeros.data(),28*sizeof(double),cudaMemcpyHostToDevice));
        CUDA(cudaMemset(controls,0,16*sizeof(double)));
        spacepdhcg_gtoc12_qoco_report report{};
        report.qualified=qualified; report.qoco_status=2;
        CUDA(cudaMemcpy(device_report,&report,sizeof(report),cudaMemcpyHostToDevice));
        // Opposite host qualification and status prove the device packet wins.
        decide<<<1,1>>>(ds,p,dm,dx,4,1,1,device ? !qualified : qualified,1,records,parameters,
            device ? device_report : nullptr);
        accept_candidate<<<2,256>>>(ds,4,dx,states,controls);
        CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
        CUDA(cudaMemcpy(&host,ds,sizeof(host),cudaMemcpyDeviceToHost));
        Record record{}; CUDA(cudaMemcpy(&record,records+prior,sizeof(record),cudaMemcpyDeviceToHost));
        CUDA(cudaMemcpy(got.data(),states,28*sizeof(double),cudaMemcpyDeviceToHost));
        const bool accepted=test==3 || test==4 || test==5 || test==6 || test==8 || test==10 || test==14 || test==15;
        REQUIRE(record.accepted==accepted); REQUIRE(host.result.iterations==prior+1);
        REQUIRE(record.qoco_status==(device ? 2 : 1));
        for (double value:got) REQUIRE(value==(accepted ? 2.0 : 0.0));
        const bool retry=device && (test==0 || test==1 || test==20);
        if (retry) REQUIRE(record.conic_rejected==2 && !host.command.done
            && host.trust_state==(test==1 ? 1e-6 : .2) && host.inaccurate_retries==1);
        if (!retry && (test==0 || test==7 || test==13)) REQUIRE(record.conic_rejected==1 && host.trust_state==.1);
        if (test==1 && !retry) REQUIRE(host.command.done && host.result.status==2);
        if (test==2 || test==3) REQUIRE(host.trust_state==.1);
        if (test==4) REQUIRE(host.command.refresh && host.command.substeps==16 && host.polishing);
        if (test==5 || test==6) REQUIRE(host.command.done && host.result.status==1);
        if (test==8) REQUIRE(record.ratio==1 && std::abs(host.trust_state-.32)<1e-15);
        if (test==9) REQUIRE(record.ratio==-1);
        if (test==10 || test==11) REQUIRE(host.command.done && host.result.status==0);
        if (test==12) REQUIRE(host.command.done && host.result.diagnostic==2);
        if (test==14) REQUIRE(!host.command.done && !host.polishing && host.result.status==0);
        if (test==15) REQUIRE(record.ratio==-1 && host.command.refresh && host.polishing
            && host.command.substeps==16 && !host.command.done);
        if (test>=16 && !retry) REQUIRE(!host.polishing && !host.command.done && host.trust_state==.1);
        if (accepted) for (int j=0;j<3;++j) REQUIRE(host.result.departure_vinf[j]==2 && host.result.arrival_vinf[j]==2);
    }
    // Repeated inaccurate exits must neither accept a trajectory nor shrink its
    // trust region until the bounded retry allowance is exhausted. Exercise the
    // actual kernels and verify copied trajectories, recorded attempts and reset
    // after a qualified candidate; these checks do not depend on cuDSS luck.
    for(bool device:{false,true}) {
        auto p=fixture();State host{};host.merit=10;host.trust_state=.2;host.trust_control=1;
        host.polish_left=4;Metrics metrics{1,0,0,1e-4,0,1,0};
        spacepdhcg_gtoc12_conic_parameters initial{};
        initial.trust_state=host.trust_state;initial.trust_control=host.trust_control;
        CUDA(cudaMemcpy(parameters,&initial,sizeof(initial),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(ds,&host,sizeof(host),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(dm,&metrics,sizeof(metrics),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(states,zeros.data(),28*sizeof(double),cudaMemcpyHostToDevice));
        for(int attempt=0;attempt<9;++attempt) {
            const int qualified=attempt==7;
            spacepdhcg_gtoc12_qoco_report report{};report.qualified=qualified;report.qoco_status=2;
            CUDA(cudaMemcpy(device_report,&report,sizeof(report),cudaMemcpyHostToDevice));
            const double prior_trust=host.trust_state;
            decide<<<1,1>>>(ds,p,dm,dx,4,1,1,device ? !qualified : qualified,
                device ? 3 : 2,records,parameters,device ? device_report : nullptr);
            accept_candidate<<<2,256>>>(ds,4,dx,states,controls);
            CUDA(cudaGetLastError());
            CUDA(cudaMemcpy(&host,ds,sizeof(host),cudaMemcpyDeviceToHost));
            Record record{};CUDA(cudaMemcpy(&record,records+attempt,sizeof(record),cudaMemcpyDeviceToHost));
            CUDA(cudaMemcpy(got.data(),states,28*sizeof(double),cudaMemcpyDeviceToHost));
            REQUIRE(host.result.iterations==attempt+1 && !host.command.done);
            REQUIRE(host.result.accepted_iterations==(attempt>=7));
            for(double value:got) REQUIRE(value==(attempt>=7 ? 2.0 : 0.0));
            const bool shrunk=attempt==2 || attempt==5;
            REQUIRE(record.conic_rejected==(qualified ? 0 : shrunk ? 1 : 2));
            REQUIRE(record.trust_state==prior_trust);
            REQUIRE(host.trust_state==prior_trust*(qualified ? p.grow_factor : shrunk ? p.shrink_factor : 1.0));
            if(attempt==7) REQUIRE(host.inaccurate_retries==0);
            if(attempt==8) REQUIRE(host.inaccurate_retries==1);
            spacepdhcg_gtoc12_conic_parameters conic{};
            CUDA(cudaMemcpy(&conic,parameters,sizeof(conic),cudaMemcpyDeviceToHost));
            REQUIRE(conic.trust_state==host.trust_state && conic.trust_control==host.trust_control);
        }
    }
    // A local stationary failure needs two consecutive qualified witnesses.
    // Exercise both qualification sources, guard exclusions, and the real
    // finalizer so this diagnostic cannot turn into an infeasibility claim.
    for (bool device:{false,true}) for (int test=0;test<8;++test) {
        auto p=fixture(); p.polish_iterations=0;
        State host{}; host.merit=10; host.trust_state=.2; host.trust_control=1;
        host.result.virtual_inf=1;
        CUDA(cudaMemcpy(ds,&host,sizeof(host),cudaMemcpyHostToDevice));
        for (int attempt=0;attempt<3;++attempt) {
            // Stable model/nonlinear offset must not mask stationarity.
            Metrics metrics{10,0,1e-5,1e-3,1e-3,0,0};
            int qualified=1;
            if (attempt==2) {
                if(test==2) metrics.step=2*p.step_tolerance;
                if(test==3) metrics.virtual_sum+=2*p.objective_tolerance/p.virtual_weight;
                if(test==4) metrics.penalty=2*p.objective_tolerance/p.virtual_weight;
                if(test==5) qualified=0;
                if(test==6) metrics.invalid=1;
                if(test==7) metrics.defect=metrics.virtual_inf=metrics.virtual_sum=0;
            }
            CUDA(cudaMemcpy(dm,&metrics,sizeof(metrics),cudaMemcpyHostToDevice));
            spacepdhcg_gtoc12_qoco_report report{}; report.qualified=qualified; report.qoco_status=2;
            CUDA(cudaMemcpy(device_report,&report,sizeof(report),cudaMemcpyHostToDevice));
            decide<<<1,1>>>(ds,p,dm,dx,4,1,1,device ? !qualified : qualified,2,
                records,parameters,device ? device_report : nullptr,test!=1);
            CUDA(cudaGetLastError());
            CUDA(cudaMemcpy(&host,ds,sizeof(host),cudaMemcpyDeviceToHost));
            REQUIRE(host.stationary_failures==(test==1 ? 0 : attempt<2 ? attempt : test==0 ? 2 : 0));
            REQUIRE(host.command.done==(attempt==2 && (test==0 || test==7)));
            if(attempt==2 && test==0) {
                REQUIRE(host.result.status==2 && host.result.diagnostic==7 && !host.copy_candidate);
                Record record{}; CUDA(cudaMemcpy(&record,records+2,sizeof(record),cudaMemcpyDeviceToHost));
                REQUIRE(!record.accepted);
                finalize<<<1,1>>>(ds,p,0);
                CUDA(cudaMemcpy(&host,ds,sizeof(host),cudaMemcpyDeviceToHost));
                REQUIRE(host.result.status==2 && host.result.diagnostic==7);
            }
            if(attempt==2 && test==7) REQUIRE(host.result.status==1 && host.copy_candidate);
        }
    }
    for (int status=0;status<5;++status) for (int feasible=0;feasible<2;++feasible) {
        State host{}; host.result.status=status; host.result.virtual_inf=feasible ? 0 : 1;
        CUDA(cudaMemcpy(ds,&host,sizeof(host),cudaMemcpyHostToDevice));
        finalize<<<1,1>>>(ds,fixture(),0);
        CUDA(cudaMemcpy(&host,ds,sizeof(host),cudaMemcpyDeviceToHost));
        const int expected=(status==0 || status==2) && !feasible ? 3 : status;
        REQUIRE(host.result.status==expected);
    }
    for (int test=0;test<5;++test) {
        auto p=fixture();State host{};host.command.refresh=1;host.polishing=1;host.merit=1;
        Metrics metrics{1,0,0,0,0,0,0};
        if(test==1) metrics.defect=2*p.defect_tolerance;
        if(test==2) metrics.fuel+=2*p.objective_tolerance;
        if(test==3) host.polishing=0; // no preceding convergence witness
        if(test==4) host.result.virtual_inf=20*p.defect_tolerance;
        CUDA(cudaMemcpy(ds,&host,sizeof(host),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(dm,&metrics,sizeof(metrics),cudaMemcpyHostToDevice));
        set_reference<<<1,1>>>(ds,dm,p,true);
        CUDA(cudaMemcpy(&host,ds,sizeof(host),cudaMemcpyDeviceToHost));
        REQUIRE(host.result.status==(test==0 ? 1 : 0));
        REQUIRE(host.command.done==(test==0));
    }
    CUDA(cudaFree(ds)); CUDA(cudaFree(dm)); CUDA(cudaFree(dx)); CUDA(cudaFree(states));
    CUDA(cudaFree(controls)); CUDA(cudaFree(records)); CUDA(cudaFree(parameters));
    CUDA(cudaFree(device_report));
}

void reductions(int nodes,bool poison) {
    const int variables=25*nodes-14, blocks=std::min(256,(variables+255)/256);
    std::vector<double> x(variables,0),ref(7*nodes,0),u(4*nodes,0),weights(nodes,.001),prop(7*(nodes-1),0);
    Metrics expected{};
    for (int i=0;i<7*nodes;++i) x[i]=.01*(i%17-8);
    for (int i=0;i<4*nodes;++i) x[7*nodes+i]=.02*(i%7);
    for (int i=0;i<7*(nodes-1);++i) x[11*nodes+i]=.003*(i%11-5);
    for (int i=0;i<nodes;++i) expected.fuel+=weights[i]*x[7*nodes+4*i+3];
    for (int i=0;i<7*(nodes-1);++i) {
        const double defect=std::abs(x[7+i]);
        expected.penalty+=std::max(defect-1e-9,0.0); expected.defect=std::max(expected.defect,defect);
        expected.virtual_sum+=std::abs(x[11*nodes+i]); expected.virtual_inf=std::max(expected.virtual_inf,std::abs(x[11*nodes+i]));
    }
    for (int i=0;i<11*nodes;++i) expected.step=std::max(expected.step,std::abs(x[i]));
    if (poison) x.back()=NAN; // nonfinite slack outside the state/control/virtual slices
    double *dx,*dr,*du,*df,*dp; int* invalid; Metrics *partial,*out;
    CUDA(cudaMalloc(&dx,x.size()*8)); CUDA(cudaMalloc(&dr,ref.size()*8)); CUDA(cudaMalloc(&du,u.size()*8));
    CUDA(cudaMalloc(&df,weights.size()*8)); CUDA(cudaMalloc(&dp,prop.size()*8));
    CUDA(cudaMalloc(&invalid,4)); CUDA(cudaMalloc(&partial,blocks*sizeof(Metrics))); CUDA(cudaMalloc(&out,sizeof(Metrics)));
    CUDA(cudaMemcpy(dx,x.data(),x.size()*8,cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(dr,ref.data(),ref.size()*8,cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(du,u.data(),u.size()*8,cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(df,weights.data(),weights.size()*8,cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(dp,prop.data(),prop.size()*8,cudaMemcpyHostToDevice)); CUDA(cudaMemset(invalid,0,4));
    reduce_metrics<<<blocks,256>>>(nodes,variables,dx,dx+7*nodes,dx+11*nodes,dr,du,dp,invalid,df,1e-9,0.0,nodes,partial);
    finish_metrics<<<1,256>>>(blocks,partial,out);
    Metrics got{}; CUDA(cudaMemcpy(&got,out,sizeof(got),cudaMemcpyDeviceToHost));
    REQUIRE(std::abs(got.fuel-expected.fuel)<1e-11*std::max(1.0,expected.fuel));
    REQUIRE(std::abs(got.penalty-expected.penalty)<1e-11*std::max(1.0,expected.penalty));
    REQUIRE(std::abs(got.virtual_sum-expected.virtual_sum)<1e-11*std::max(1.0,expected.virtual_sum));
    REQUIRE(got.defect==expected.defect && got.virtual_inf==expected.virtual_inf && got.step==expected.step);
    REQUIRE(got.invalid==double(poison));
    if (!poison) for (int test=0;test<6;++test) {
        auto input=x;
        const int node=test>=3 ? nodes-1 : 0;
        const double thrust=test==0 ? .6 : test==1 ? .6000000005 : .6000000038;
        input[7*nodes+4*node]=thrust/.6;
        input[7*nodes+4*node+1]=input[7*nodes+4*node+2]=0;
        CUDA(cudaMemcpy(dx,input.data(),input.size()*8,cudaMemcpyHostToDevice));
        // Inactive ZOH endpoint and infeasible initial references are allowed;
        // active violating candidate nodes are rejected even with a finite CQP.
        const int active=test==3 ? nodes-1 : nodes;
        reduce_metrics<<<blocks,256>>>(nodes,variables,dx,dx+7*nodes,dx+11*nodes,dr,
            test==5 ? nullptr : du,dp,invalid,df,1e-9,0.0,active,partial);
        finish_metrics<<<1,256>>>(blocks,partial,out);
        CUDA(cudaMemcpy(&got,out,sizeof(got),cudaMemcpyDeviceToHost));
        REQUIRE(got.invalid==double(test==2 || test==4));
    }
    CUDA(cudaFree(dx)); CUDA(cudaFree(dr)); CUDA(cudaFree(du)); CUDA(cudaFree(df)); CUDA(cudaFree(dp));
    CUDA(cudaFree(invalid)); CUDA(cudaFree(partial)); CUDA(cudaFree(out));
}

void initial_velocity_outputs() {
    // Invalid model scaling must be rejected before allocation or GPU access.
    double tiny_initial[7]={1.49597870691e8,0,0,0,0,0,1e-320};
    double dummy[12]={};
    REQUIRE(spacepdhcg_gtoc12_scvx_solve_zoh_seed_host(1,0,1,0,1,1,dummy,dummy,dummy,
        tiny_initial,dummy,0,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr)==1);
    State* state{}; double* states{};
    spacepdhcg_gtoc12_conic_parameters* parameters{};
    CUDA(cudaMalloc(&state,sizeof(State))); CUDA(cudaMalloc(&states,14*sizeof(double)));
    CUDA(cudaMalloc(&parameters,sizeof(*parameters)));
    double values[14]={1,0,0,.1,.2,.3,1, 1,0,0,.4,.5,.6,.9};
    CUDA(cudaMemcpy(states,values,sizeof(values),cudaMemcpyHostToDevice));
    BoundaryVelocities body{{.01,.02,.03},{.04,.05,.06}};
    for(int departure=0;departure<2;++departure) for(int arrival=0;arrival<2;++arrival) {
        const auto p=fixture();
        initialize<<<1,1>>>(state,p,parameters);
        initialize_vinf<<<1,1>>>(state,states,2,departure,arrival,body);
        finalize<<<1,1>>>(state,p,1); // no candidate accepted before the deadline
        State out{}; CUDA(cudaMemcpy(&out,state,sizeof(out),cudaMemcpyDeviceToHost));
        REQUIRE(out.result.accepted_iterations==0 && out.result.status==4);
        for(int j=0;j<3;++j) {
            REQUIRE(out.result.departure_vinf[j]==(departure ? values[3+j]-body.departure[j] : 0.0));
            REQUIRE(out.result.arrival_vinf[j]==(arrival ? values[10+j]-body.arrival[j] : 0.0));
        }
    }
    CUDA(cudaFree(state)); CUDA(cudaFree(states)); CUDA(cudaFree(parameters));
}

void boundary_merit() {
    State* ds{};Metrics* dm{};double* dx{};Record* records{};
    spacepdhcg_gtoc12_conic_parameters* parameters{};
    CUDA(cudaMalloc(&ds,sizeof(State)));CUDA(cudaMalloc(&dm,sizeof(Metrics)));
    CUDA(cudaMalloc(&dx,100*sizeof(double)));CUDA(cudaMalloc(&records,44*sizeof(Record)));
    CUDA(cudaMalloc(&parameters,sizeof(*parameters)));
    const auto p=fixture();
    BoundaryTargets body{};body.values[0]=1.0;body.values[6]=2.0;body.vinf_max=p.vinf_max;
    std::vector<double> x(100,0.0);for(int i=0;i<4;++i)x[7*i+6]=1.0;
    x[0]=1.0;x[21]=1.9; // Dynamics-consistent reference misses its rendezvous.
    CUDA(cudaMemcpy(dx,x.data(),x.size()*sizeof(double),cudaMemcpyHostToDevice));
    initialize<<<1,1>>>(ds,p,parameters);
    Metrics m{.1,0,0,0,0,.01,0};
    CUDA(cudaMemcpy(dm,&m,sizeof(m),cudaMemcpyHostToDevice));
    add_boundary_metrics<<<1,32>>>(dm,dx,4,body,ds,false,p.conic_tolerance);
    set_reference<<<1,1>>>(ds,dm,p);
    State reference{};CUDA(cudaMemcpy(&reference,ds,sizeof(reference),cudaMemcpyDeviceToHost));
    REQUIRE(std::abs(reference.merit-(.1+1e4*(.1-p.conic_tolerance)))<1e-10);
    // A higher-fuel, boundary-corrected candidate must improve that reference.
    x[21]=2.0;CUDA(cudaMemcpy(dx,x.data(),x.size()*sizeof(double),cudaMemcpyHostToDevice));
    m.fuel=.2;CUDA(cudaMemcpy(dm,&m,sizeof(m),cudaMemcpyHostToDevice));
    add_boundary_metrics<<<1,32>>>(dm,dx,4,body,ds,true,p.conic_tolerance);
    decide<<<1,1>>>(ds,p,dm,dx,4,0,0,1,1,records,parameters);
    State accepted{};CUDA(cudaMemcpy(&accepted,ds,sizeof(accepted),cudaMemcpyDeviceToHost));
    REQUIRE(accepted.copy_candidate==1 && accepted.result.accepted_iterations==1);

    // Every endpoint mode uses its literal equality and auxiliary cone rows.
    for(int free_dep=0;free_dep<2;++free_dep)for(int free_arr=0;free_arr<2;++free_arr) {
        body.free_dep=free_dep;body.free_arr=free_arr;
        const int ivd=11*4+14*3,iva=ivd+3*free_dep;
        std::fill(x.begin(),x.end(),0.0);for(int i=0;i<4;++i)x[7*i+6]=1.0;
        x[0]=1.0;x[21]=2.0;
        if(free_dep) {x[3]=.1;x[ivd]=.1;}
        if(free_arr) {x[24]=.1;x[iva]=.1;}
        State ref{};ref.result.departure_vinf[0]=free_dep?.1:0;
        ref.result.arrival_vinf[0]=free_arr?.1:0;
        for(int test=0;test<8;++test) {
            auto input=x;auto state=ref;
            if(test==1)input[6]=.9; // Initial mass equality; final mass stays free.
            if(test==2)input[27]=.7;
            if(test==3)input[24]+=.03; // State/auxiliary mismatch must not hide in free mode.
            if(test==4)input[21]=INFINITY;
            if(test==5 && free_dep) {input[3]=.3;input[ivd]=.3;state.result.departure_vinf[0]=.3;}
            if(test==6 && free_arr) {input[24]=.3;input[iva]=.3;state.result.arrival_vinf[0]=.3;}
            if(test==7)input[21]+=p.conic_tolerance/2;
            CUDA(cudaMemcpy(ds,&state,sizeof(state),cudaMemcpyHostToDevice));
            CUDA(cudaMemcpy(dx,input.data(),input.size()*sizeof(double),cudaMemcpyHostToDevice));
            for(bool candidate:{false,true}) {
                Metrics zero{};CUDA(cudaMemcpy(dm,&zero,sizeof(zero),cudaMemcpyHostToDevice));
                add_boundary_metrics<<<1,32>>>(dm,dx,4,body,ds,candidate,p.conic_tolerance);
                Metrics got{};CUDA(cudaMemcpy(&got,dm,sizeof(got),cudaMemcpyDeviceToHost));
                if(test==4) {REQUIRE(got.invalid==1);continue;}
                double expected=test==1?.1:test==3?.03:
                    (test==5&&free_dep)||(test==6&&free_arr)?.1:0.0;
                REQUIRE(got.invalid==0);
                REQUIRE(std::abs(got.boundary_penalty-std::max(expected-p.conic_tolerance,0.0))<1e-14);
                REQUIRE(test==7 ? got.boundary_defect>0 && got.boundary_defect<p.conic_tolerance
                    : std::abs(got.boundary_defect-expected)<1e-14);
            }
        }
    }
    // A boundary-infeasible stationary candidate and polish refresh cannot qualify.
    for(bool polish:{false,true}) {
        State state{};state.merit=1;state.trust_state=.2;state.trust_control=1;
        state.polishing=polish;state.polish_left=4;state.command.refresh=polish;
        state.result.virtual_inf=0;
        Metrics bad{1,0,0,0,0,0,0};bad.boundary_defect=2*p.defect_tolerance;
        CUDA(cudaMemcpy(ds,&state,sizeof(state),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(dm,&bad,sizeof(bad),cudaMemcpyHostToDevice));
        if(polish)set_reference<<<1,1>>>(ds,dm,p,true);
        else decide<<<1,1>>>(ds,p,dm,dx,4,0,0,1,1,records,parameters);
        State out{};CUDA(cudaMemcpy(&out,ds,sizeof(out),cudaMemcpyDeviceToHost));
        REQUIRE(out.result.status!=1 && !out.command.done);
    }
    CUDA(cudaFree(ds));CUDA(cudaFree(dm));CUDA(cudaFree(dx));CUDA(cudaFree(records));CUDA(cudaFree(parameters));
}

void mass_reductions(int nodes) {
    // Independent host sum/max over every original mass row. Include inputs
    // with a feasible endpoint and an infeasible interior, and grids larger
    // than the capped reduction launch. No trajectory solver is involved.
    const int variables=25*nodes-14,blocks=std::min(256,(variables+255)/256);
    const auto p=fixture();
    std::vector<double> input(variables,0.0),weights(nodes,0.0),propagated(7*(nodes-1),0.0);
    double *dx{},*df{},*dp{};int *invalid{},*enabled{};Metrics *partial{},*output{};
    CUDA(cudaMalloc(&dx,input.size()*sizeof(double)));
    CUDA(cudaMalloc(&df,weights.size()*sizeof(double)));
    CUDA(cudaMalloc(&dp,propagated.size()*sizeof(double)));
    CUDA(cudaMalloc(&invalid,sizeof(int)));CUDA(cudaMalloc(&enabled,sizeof(int)));
    CUDA(cudaMalloc(&partial,blocks*sizeof(Metrics)));CUDA(cudaMalloc(&output,sizeof(Metrics)));
    CUDA(cudaMemcpy(df,weights.data(),weights.size()*sizeof(double),cudaMemcpyHostToDevice));
    CUDA(cudaMemset(invalid,0,sizeof(int)));
    for(int test=0;test<8;++test) {
        std::fill(input.begin(),input.end(),0.0);
        double floor=.5;
        for(int node=0;node<nodes;++node) input[7*node+6]=.75;
        input[6]=1.0;
        if(test==1) input[7*(nodes/2)+6]=.25; // Interior-only deficit.
        if(test==2) {input[7*(nodes/2)+6]=.375;input[7*nodes-1]=.125;}
        if(test==3) for(int node=1;node<nodes;++node)
            input[7*node+6]=.5+.03125*(node%7-3);
        if(test==4) {
            // Zero floor represents the deadband and its adjacent doubles
            // exactly, avoiding a rounded floor-minus-tolerance construction.
            floor=0.0;
            const double edge[]={0.0,-p.conic_tolerance,
                std::nextafter(-p.conic_tolerance,INFINITY),
                std::nextafter(-p.conic_tolerance,-INFINITY)};
            for(int node=0;node<nodes;++node) input[7*node+6]=edge[node%4];
        }
        if(test==5) input[7*(nodes/2)+6]=NAN;
        if(test==6) input[7*(nodes/2)+6]=INFINITY;
        if(test==7) input[7*nodes-1]=-INFINITY;
        long double sum=0.0L;double maximum=0.0;
        if(test<5) for(int node=0;node<nodes;++node) {
            const double deficit=std::max(floor-input[7*node+6],0.0);
            sum+=static_cast<long double>(std::max(deficit-p.conic_tolerance,0.0));
            maximum=std::max(maximum,deficit);
        }
        std::copy(input.begin()+7,input.begin()+7*nodes,propagated.begin());
        CUDA(cudaMemcpy(dx,input.data(),input.size()*sizeof(double),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(dp,propagated.data(),propagated.size()*sizeof(double),cudaMemcpyHostToDevice));
        reduce_metrics<<<blocks,256>>>(nodes,variables,dx,dx+7*nodes,nullptr,nullptr,nullptr,
            dp,invalid,df,p.conic_tolerance,floor,nodes-1,partial);
        finish_metrics<<<1,256>>>(blocks,partial,output);
        CUDA(cudaGetLastError());
        Metrics got{};CUDA(cudaMemcpy(&got,output,sizeof(got),cudaMemcpyDeviceToHost));
        REQUIRE(got.invalid==double(test>=5));
        if(test<5) {
            const double expected=static_cast<double>(sum);
            // Scale by the actual penalty: nextafter-sized hinges must survive.
            REQUIRE(std::abs(got.mass_penalty-expected)<=1e-11*expected);
            REQUIRE(got.mass_defect==maximum);
            REQUIRE(got.fuel==0.0 && got.penalty==0.0 && got.defect==0.0);
            REQUIRE(got.virtual_sum==0.0 && got.virtual_inf==0.0);
            REQUIRE(got.boundary_penalty==0.0 && got.boundary_defect==0.0);
            if(test==0) REQUIRE(got.mass_penalty==0.0 && got.mass_defect==0.0);
            if(test==1) REQUIRE(input[7*nodes-1]>floor && got.mass_defect==.25);
            if(test==4) REQUIRE(got.mass_penalty>0.0 && got.mass_defect>p.conic_tolerance);
        }
    }
    // Both phases must preserve every field and every partial when disabled,
    // even though the retained input still contains a nonfinite final mass.
    std::vector<Metrics> before(blocks),after(blocks);
    for(int i=0;i<blocks;++i) {
        before[i]={1.0+i,2,3,4,5,6,7};
        before[i].boundary_penalty=8;before[i].boundary_defect=9;
        before[i].mass_penalty=10;before[i].mass_defect=11;
    }
    Metrics sentinel=before[0],untouched{};
    CUDA(cudaMemcpy(partial,before.data(),blocks*sizeof(Metrics),cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(output,&sentinel,sizeof(sentinel),cudaMemcpyHostToDevice));
    CUDA(cudaMemset(enabled,0,sizeof(int)));
    reduce_metrics<<<blocks,256>>>(nodes,variables,dx,dx+7*nodes,nullptr,nullptr,nullptr,
        dp,invalid,df,p.conic_tolerance,.5,nodes-1,partial,enabled);
    finish_metrics<<<1,256>>>(blocks,partial,output,enabled);
    CUDA(cudaGetLastError());
    CUDA(cudaMemcpy(after.data(),partial,blocks*sizeof(Metrics),cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&untouched,output,sizeof(untouched),cudaMemcpyDeviceToHost));
    REQUIRE(std::memcmp(before.data(),after.data(),blocks*sizeof(Metrics))==0);
    REQUIRE(std::memcmp(&sentinel,&untouched,sizeof(Metrics))==0);
    CUDA(cudaFree(dx));CUDA(cudaFree(df));CUDA(cudaFree(dp));CUDA(cudaFree(invalid));
    CUDA(cudaFree(enabled));CUDA(cudaFree(partial));CUDA(cudaFree(output));
}

void mass_merit() {
    State* ds{};Metrics* dm{};double* dx{};Record* records{};
    spacepdhcg_gtoc12_conic_parameters* parameters{};
    CUDA(cudaMalloc(&ds,sizeof(State)));CUDA(cudaMalloc(&dm,sizeof(Metrics)));
    CUDA(cudaMalloc(&dx,100*sizeof(double)));CUDA(cudaMalloc(&records,44*sizeof(Record)));
    CUDA(cudaMalloc(&parameters,sizeof(*parameters)));
    auto p=fixture();
    std::vector<double> x(100,0.0);for(int i=0;i<4;++i)x[7*i+6]=1.0;
    CUDA(cudaMemcpy(dx,x.data(),x.size()*sizeof(double),cudaMemcpyHostToDevice));
    initialize<<<1,1>>>(ds,p,parameters);
    // Saved-failure pattern: a small fuel cost and zero dynamics/boundary
    // residual still has an original mass inequality violation.
    Metrics reference{.1,0,0,0,0,.01,0};
    reference.mass_defect=.1;reference.mass_penalty=.1-p.conic_tolerance;
    CUDA(cudaMemcpy(dm,&reference,sizeof(reference),cudaMemcpyHostToDevice));
    set_reference<<<1,1>>>(ds,dm,p);
    State state{};CUDA(cudaMemcpy(&state,ds,sizeof(state),cudaMemcpyDeviceToHost));
    REQUIRE(std::abs(state.merit-(.1+1e4*(.1-p.conic_tolerance)))<1e-10);
    Metrics candidate{.2,0,0,0,0,.01,0};
    CUDA(cudaMemcpy(dm,&candidate,sizeof(candidate),cudaMemcpyHostToDevice));
    decide<<<1,1>>>(ds,p,dm,dx,4,0,0,1,1,records,parameters);
    CUDA(cudaMemcpy(&state,ds,sizeof(state),cudaMemcpyDeviceToHost));
    Record record{};CUDA(cudaMemcpy(&record,records,sizeof(record),cudaMemcpyDeviceToHost));
    REQUIRE(record.accepted==1 && record.ratio==1.0 && record.merit==.2);
    REQUIRE(state.copy_candidate==1 && state.result.accepted_iterations==1);
    REQUIRE(state.result.status!=1); // An accepted finite step alone is not convergence.

    // Price the same affine hinge in both candidate merits. A nonzero virtual
    // term makes the ratio detect a missing MODEL contribution independently.
    state={};state.merit=20;state.trust_state=.2;state.trust_control=1;state.polish_left=4;
    candidate={1,0,.0002,0,0,1,0};
    candidate.mass_penalty=.001;candidate.mass_defect=.001+p.conic_tolerance;
    CUDA(cudaMemcpy(ds,&state,sizeof(state),cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(dm,&candidate,sizeof(candidate),cudaMemcpyHostToDevice));
    decide<<<1,1>>>(ds,p,dm,dx,4,0,0,1,1,records,parameters);
    CUDA(cudaMemcpy(&record,records,sizeof(record),cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&state,ds,sizeof(state),cudaMemcpyDeviceToHost));
    REQUIRE(record.accepted==1 && std::abs(record.merit-11.0)<1e-14);
    REQUIRE(std::abs(record.ratio-9.0/7.0)<1e-14);
    REQUIRE(!state.command.done && !state.polishing && state.result.status!=1);

    // The merit deadband and raw feasibility threshold are different. Exact
    // p.defect_tolerance passes; its next representable larger value fails,
    // even with unchanged zero prediction/actual reduction and zero step.
    // The separate physical/fixed-mass certificate is not replaced by this test.
    const double deficits[]={0.0,.5*p.conic_tolerance,p.conic_tolerance,p.defect_tolerance,
        std::nextafter(p.defect_tolerance,INFINITY),2*p.defect_tolerance};
    for(bool polish:{false,true})for(double deficit:deficits) {
        auto settings=p;settings.polish_iterations=0;
        Metrics metrics{1,0,0,0,0,0,0};
        metrics.mass_defect=deficit;
        metrics.mass_penalty=std::max(deficit-p.conic_tolerance,0.0);
        State initial{};initial.merit=1+p.virtual_weight*metrics.mass_penalty;
        initial.trust_state=.2;initial.trust_control=1;initial.polish_left=4;
        initial.polishing=polish;initial.command.refresh=polish;initial.result.virtual_inf=0;
        CUDA(cudaMemcpy(ds,&initial,sizeof(initial),cudaMemcpyHostToDevice));
        CUDA(cudaMemcpy(dm,&metrics,sizeof(metrics),cudaMemcpyHostToDevice));
        if(polish)set_reference<<<1,1>>>(ds,dm,settings,true);
        else decide<<<1,1>>>(ds,settings,dm,dx,4,0,0,1,1,records,parameters);
        CUDA(cudaGetLastError());
        CUDA(cudaMemcpy(&state,ds,sizeof(state),cudaMemcpyDeviceToHost));
        const bool feasible=deficit<=p.defect_tolerance;
        REQUIRE((state.result.status==1)==feasible && bool(state.command.done)==feasible);
        if(!polish && !feasible) REQUIRE(!state.polishing);
    }
    CUDA(cudaFree(ds));CUDA(cudaFree(dm));CUDA(cudaFree(dx));CUDA(cudaFree(records));CUDA(cudaFree(parameters));
}

int main() {
    mass_merit();
    boundary_merit();
    initial_velocity_outputs();
    controller();
    for (int n:{4,37,4097,10001}) for (bool poison:{false,true}) reductions(n,poison);
    for(int n:{4,37,4097,10001}) mass_reductions(n);
    std::puts("PASS: mass-corrective acceptance and candidate/model pricing, 12 raw-mass convergence/polish guards, 32 all-node mass reductions, 4 disabled mass reductions, boundary-corrective acceptance, 64 endpoint/auxiliary checks, 2 boundary convergence guards, 22 controller branches, 18 bounded-retry transitions, 48 stationary-failure transitions, 10 final states, 5 polish confirmations, 8 multi-block reductions, 24 physical thrust gates");
}
